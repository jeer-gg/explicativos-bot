"""Montaje por tomas: cada escena se corta en tomas cortas, como los Reels que más retienen.

Medido en videos virales de referencia:
- comedia / historia cotidiana: tomas de 0,5 a 1,5 s (mediana 0,75 s)
- historia / documental: tomas de 2,5 a 5 s (mediana ~4 s), con algo nuevo cada 1-2 s

El guionista propone las tomas (en qué palabra empieza cada una y qué se ve). Aquí se ponen
en el tiempo real de la voz y se corrige el ritmo: si una toma queda muy larga se parte en
otra toma con distinto encuadre; si queda muy corta se une a la anterior.
"""
from __future__ import annotations

import re
import unicodedata

TIPOS_3D = ("lugar", "personaje", "reaccion", "detalle", "accion")
TIPOS_INSERTO = ("documento", "pantalla", "mapa", "calendario", "contador", "reloj")
TIPOS = TIPOS_3D + TIPOS_INSERTO
ENCUADRES = ("general", "medio", "cerca", "detalle", "picado", "contrapicado", "lateral")
LUCES = ("normal", "calida", "fria", "noche", "peligro", "dorada", "misterio")

# Qué encuadre le va a cada tipo de toma cuando el guion no lo dice
_ENCUADRE_DE = {"lugar": "general", "personaje": "medio", "reaccion": "cerca", "detalle": "detalle",
                "accion": "medio"}
# Para partir una toma larga se alterna el encuadre (nunca dos iguales seguidos)
_ALTERNAR = {"general": "medio", "medio": "cerca", "cerca": "medio", "detalle": "medio",
             "picado": "cerca", "contrapicado": "medio", "lateral": "cerca"}


def _norm(p: str) -> str:
    p = unicodedata.normalize("NFD", str(p).lower())
    return re.sub(r"[^a-z0-9ñ]", "", "".join(c for c in p if unicodedata.category(c) != "Mn"))


def ritmo(cfg: dict) -> dict:
    m = cfg["produccion"].get("montaje") or {}
    return {"activo": bool(m.get("activo", True)), "min": float(m.get("toma_min", 1.2)),
            "max": float(m.get("toma_max", 4.0)), "objetivo": float(m.get("toma_objetivo", 2.5))}


def _limpiar_inserto(t: dict) -> dict | None:
    ins = t.get("inserto")
    if not isinstance(ins, dict):
        return None
    limpio = {}
    for k, v in ins.items():
        if isinstance(v, (str, int, float, bool)):
            limpio[k] = v if not isinstance(v, str) else v[:140]
        elif isinstance(v, list):
            limpio[k] = [x if not isinstance(x, str) else x[:90] for x in v[:8]
                         if isinstance(x, (str, int, float, dict))]
    return limpio


def _toma_limpia(t: dict) -> dict:
    tipo = str(t.get("tipo") or "personaje").strip().lower()
    tipo = tipo if tipo in TIPOS else "personaje"
    enc = str(t.get("encuadre") or _ENCUADRE_DE.get(tipo, "medio")).strip().lower()
    luz = str(t.get("luz") or "normal").strip().lower()
    toma = {"tipo": tipo, "encuadre": enc if enc in ENCUADRES else "medio",
            "luz": luz if luz in LUCES else "normal", "ve": str(t.get("ve") or t.get("que_se_ve") or "")[:200]}
    if tipo in TIPOS_INSERTO:
        toma["inserto"] = _limpiar_inserto(t) or {}
    ficha = t.get("ficha")
    if isinstance(ficha, dict) and ficha.get("titulo"):
        toma["ficha"] = {"titulo": str(ficha["titulo"])[:40], "sub": str(ficha.get("sub") or "")[:50]}
    if t.get("sello"):
        toma["sello"] = str(t["sello"])[:16].upper()
    if t.get("3d") is True or str(t.get("3d")).lower() == "true":
        toma["3d"] = True
    if t.get("resalta"):
        toma["resalta"] = str(t["resalta"])[:40]
    return toma


def tomas_automaticas(n_palabras: int, dur: float, r: dict) -> list[dict]:
    """Si el guion no trae tomas: cortes cada ~objetivo segundos alternando encuadres."""
    n = max(1, round(dur / max(0.5, r["objetivo"])))
    ciclo = ["general", "medio", "cerca", "detalle", "medio", "picado", "cerca"]
    return [{"tipo": "personaje" if k else "lugar", "encuadre": ciclo[k % len(ciclo)], "luz": "normal",
             "_palabra": round(k * n_palabras / n)} for k in range(n)]


def poner_en_tiempo(escena_guion: dict, palabras: list[dict], dur: float, cfg: dict) -> list[dict]:
    """Devuelve las tomas de una escena con su inicio (segundos, relativo a la escena)."""
    r = ritmo(cfg)
    if not r["activo"]:
        return []
    propuestas = [t for t in (escena_guion.get("tomas") or []) if isinstance(t, dict)]
    textos = [_norm(p.get("w") or "") for p in palabras]
    tomas: list[dict] = []
    if propuestas:
        cursor = 0
        for k, t in enumerate(propuestas):
            toma = _toma_limpia(t)
            if k == 0:
                toma["_palabra"] = 0
            else:
                objetivo = [w for w in (_norm(x) for x in str(t.get("desde") or "").split()) if w]
                idx = None
                for i in range(cursor + 1, len(textos)):
                    if objetivo and textos[i] == objetivo[0] and all(
                            i + j < len(textos) and textos[i + j] == objetivo[j] for j in range(min(len(objetivo), 3))):
                        idx = i
                        break
                if idx is None:  # no se encontró la palabra: se reparte en proporción
                    idx = min(len(textos) - 1, max(cursor + 1, round(k * len(textos) / len(propuestas))))
                if idx >= len(textos):
                    break
                toma["_palabra"] = idx
                cursor = idx
            tomas.append(toma)
    else:
        tomas = tomas_automaticas(len(palabras), dur, r)

    def inicio_de(t):
        i = t["_palabra"]
        if i <= 0 or not palabras:
            return 0.0
        # se corta unas décimas antes de la palabra, para que la imagen llegue con la voz
        return max(0.0, float(palabras[min(i, len(palabras) - 1)].get("t", 0)) - 0.08)

    for t in tomas:
        t["inicio"] = round(inicio_de(t), 3)
    tomas.sort(key=lambda t: t["inicio"])

    # Unir las demasiado cortas (salvo la primera) a la anterior
    unidas: list[dict] = []
    for t in tomas:
        if unidas and t["inicio"] - unidas[-1]["inicio"] < r["min"] * 0.8:
            if t["tipo"] in TIPOS_INSERTO and unidas[-1]["tipo"] not in TIPOS_INSERTO and len(unidas) > 1:
                t["inicio"] = unidas[-1]["inicio"]  # el inserto pesa más: reemplaza
                unidas[-1] = t
            continue
        unidas.append(t)
    if unidas and dur - unidas[-1]["inicio"] < r["min"] * 0.6 and len(unidas) > 1:
        unidas.pop()

    # Partir las demasiado largas en tomas nuevas, cortando justo antes de una palabra
    final: list[dict] = []
    for k, t in enumerate(unidas):
        fin = unidas[k + 1]["inicio"] if k + 1 < len(unidas) else dur
        final.append(t)
        actual = t
        while fin - actual["inicio"] > r["max"]:
            meta = actual["inicio"] + r["objetivo"]
            corte = next((max(0.0, float(p.get("t", 0)) - 0.08) for p in palabras
                          if float(p.get("t", 0)) - 0.08 >= meta), None)
            if corte is None or fin - corte < r["min"] * 0.8:
                corte = actual["inicio"] + r["objetivo"]
                if fin - corte < r["min"] * 0.8:
                    break
            if actual["tipo"] in TIPOS_INSERTO:  # tras un inserto, se vuelve a la escena
                nueva = {"tipo": "reaccion", "encuadre": "cerca", "luz": actual.get("luz", "normal")}
            else:
                nueva = {k2: v for k2, v in actual.items() if k2 not in ("ficha", "sello", "inicio", "_palabra")}
                nueva["encuadre"] = _ALTERNAR.get(actual["encuadre"], "medio")
            nueva["inicio"] = round(corte, 3)
            final.append(nueva)
            actual = nueva
    for t in final:
        t.pop("_palabra", None)
    # nunca dos tomas 3D seguidas con el mismo encuadre
    for a, b in zip(final, final[1:]):
        if a["tipo"] not in TIPOS_INSERTO and b["tipo"] not in TIPOS_INSERTO and a["encuadre"] == b["encuadre"]:
            b["encuadre"] = _ALTERNAR.get(b["encuadre"], "medio")
    return final
