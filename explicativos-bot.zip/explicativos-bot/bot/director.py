"""El director: sortea el estilo y elige un tema nuevo con ayuda de los datos."""
import random
from datetime import datetime, timedelta, timezone

from .claude import Claude
from . import aprendizaje
from .memoria import guardar_recuento, memoria, recuento, resumen_para_director
from .equipo import profesional


def sortear_estilo(cfg: dict) -> dict:
    """Elige paleta, gancho y estructura sin repetir combinaciones recientes."""
    recientes = {
        (m.get("paleta"), m.get("tipo_gancho"), m.get("estructura")) for m in memoria()[-12:]
    }
    grupo = "paletas_3d" if cfg["produccion"].get("motor") in ("3d", "lienzo") else "paletas"
    paletas = list(cfg["estilo"][grupo].keys())
    tipos = cfg["ganchos"]["tipos"]
    estructuras = [e for e in cfg["ganchos"]["estructuras"] if permitir_estructura(cfg, e)]
    # Lo que mejor ha funcionado en esta página sale más seguido (sin dejar de probar lo demás).
    peso_tipos = aprendizaje.pesos(tipos, "tipo_gancho")
    peso_estr = aprendizaje.pesos(estructuras, "estructura")
    for _ in range(50):
        combo = (
            random.choice(paletas),
            random.choices(tipos, weights=peso_tipos)[0],
            random.choices(estructuras, weights=peso_estr)[0],
        )
        if combo not in recientes:
            break
    nombre, gancho, estructura = combo
    colores = cfg["estilo"][grupo][nombre]
    return {
        "tendencia": toca_tendencia(cfg),
        "paleta": nombre,
        "colores": {"fondo": colores[0], "tinta": colores[1], "acentos": colores[2:]},
        "tipo_gancho": gancho,
        "estructura": estructura,
    }


REGLAS_TENDENCIAS = """Nunca: tragedias con víctimas, muertes, crímenes, política, religión, salud o dosis,
rumores sin confirmar ni nada que se aproveche del dolor ajeno.
Facebook NO recomienda a gente nueva contenido con afirmaciones de salud o de dinero: nada de lo que es bueno o malo para el cuerpo, comida y bacterias, dietas, enfermedades, riesgos para la salud, precios, ofertas, compras, inflación, inversiones, bolsa ni criptomonedas. Si una tendencia es de eso (por ejemplo, el Black Friday o una empresa que sale a bolsa),
úsala solo si hay detrás un porqué cotidiano que NO hable de salud ni de dinero (cómo funciona
la máquina, el objeto o el fenómeno); si no, descártala."""


def _hoy(cfg: dict) -> str:
    from .horarios import _zona
    from datetime import datetime
    return datetime.now(_zona(cfg)).strftime("%Y-%m-%d")


def permitir_estructura(cfg: dict, estructura: str) -> bool:
    """Las historias en partes no deben dominar: como mucho una serie nueva cada pocos días y
    nunca mientras haya otra a medias."""
    if "HISTORIA EN PARTES" not in estructura:
        return True
    from . import series
    if series.datos()["pendientes"]:
        return False
    dias = cfg.get("series", {}).get("dias_entre_series", 4)
    limite = datetime.now(timezone.utc) - timedelta(days=dias)
    for m in memoria():
        if (m.get("serie") or {}).get("parte") == 1 and m.get("publicado_en") and \
                datetime.fromisoformat(m["publicado_en"]) > limite:
            return False
    return True


def toca_tendencia(cfg: dict) -> bool:
    """Reparto fijo por día: N de actualidad por cada clásico (por defecto 2 y 1).
    Con 3 videos al día: actualidad, actualidad, clásico."""
    t = cfg["canal"].get("tendencias", {})
    if not t.get("activo"):
        return False
    datos = recuento()
    if datos.get("fecha") != _hoy(cfg):
        return True
    actualidad = len(datos.get("usadas", []))
    clasicos = datos.get("clasicos", 0)
    return actualidad < t.get("por_cada_clasico", 2) * (clasicos + 1)


def _contar_clasico(cfg: dict):
    hoy = _hoy(cfg)
    datos = recuento()
    if datos.get("fecha") != hoy:
        datos = {"fecha": hoy, "tendencias": [], "usadas": [], "clasicos": 0}
    datos["clasicos"] = datos.get("clasicos", 0) + 1
    guardar_recuento(datos)


def recuento_del_dia(claude: Claude, cfg: dict) -> dict:
    """Una vez al día: investiga los temas del momento y saca las preguntas que la gente se hace.

    Los videos del día salen de esa lista (no del tema en sí, sino de cosas relacionadas que
    la gente se pregunta). Se guarda en data/tendencias.json para no repetir la investigación.
    """
    hoy = _hoy(cfg)
    datos = recuento()
    if datos.get("fecha") == hoy and datos.get("tendencias"):
        return datos
    t = cfg["canal"]["tendencias"]
    rol = cfg["canal"].get("rol", "videos explicativos de la vida cotidiana")
    system = (profesional("investigador") + f"Eres investigador de tendencias para una página de {rol} "
              f"en {cfg['canal']['idioma']}. Encuentras de qué habla la gente HOY y lo "
              "conviertes en preguntas curiosas del nicho de la página que se pueden contar con datos verificables.")
    usuario = f"""Fecha de hoy: {hoy}.
1) INVESTIGA con la búsqueda web lo que está pasando y lo que la gente busca y comenta hoy o en
los últimos 3 días en {", ".join(t.get("paises", []))}: tendencias de Google, noticias más
leídas, lo viral en TikTok, Facebook e Instagram, deportes, lanzamientos, clima y fenómenos
naturales, fiestas y fechas de la temporada.
2) Elige las 6 tendencias con más conversación que encajen con las reglas. Prefiere lo que
interesa a todo el mundo o a toda Latinoamérica (ciencia, tecnología, clima, fenómenos
naturales, lanzamientos, eventos mundiales, fechas y temporadas compartidas). Evita lo que
solo importa en un país (trámites, instituciones, precios o noticias locales): un video tiene
que poder interesarle igual a alguien de México, Argentina, República Dominicana o España.
3) Para cada una, escribe 4 preguntas RELACIONADAS que la gente se hace o se haría al ver esa
noticia, que no son la noticia en sí sino lo cotidiano que hay detrás. Ejemplo: tendencia «ola
de calor en el Caribe» → «¿por qué el ventilador no enfría el aire?», «¿por qué el asfalto
quema más que la arena?», «¿por qué sudamos más con humedad?». Deben poder explicarse con
datos verificables y verse bien en animación (objetos, cortes, comparaciones).
NICHO: todas las preguntas tienen que ser del nicho del canal ("{rol}") y caer en uno de estos subtemas: {"; ".join(cfg["canal"]["subtemas"])}.
La tendencia es solo la excusa: el video nunca es sobre el famoso, el partido o la noticia,
sino sobre el objeto, el fenómeno o el porqué cotidiano que hay detrás. Si una tendencia no
da para eso, descártala.
{REGLAS_TENDENCIAS}

Devuelve JSON:
{{"tendencias": [{{"tendencia": "qué está pasando, en una frase", "fuente": "url o medio",
   "preguntas": [{{"pregunta": "...", "angulo": "lo sorprendente de la respuesta", "subtema": "..."}}]}}]}}"""
    try:
        nuevos = claude.json(system, usuario, max_tokens=5000, web=True)
        tendencias = [x for x in nuevos.get("tendencias", []) if x.get("preguntas")]
    except Exception as e:  # noqa: BLE001
        print("No se pudo hacer el recuento de tendencias:", e)
        return {}
    previo = datos if datos.get("fecha") == hoy else {}
    datos = {"fecha": hoy, "tendencias": tendencias, "usadas": previo.get("usadas", []),
             "clasicos": previo.get("clasicos", 0)}
    guardar_recuento(datos)
    try:
        from . import telegram
        lineas = [f"- {x['tendencia']}" for x in tendencias]
        telegram.aviso_seguro("Recuento de temas de hoy:\n" + "\n".join(lineas))
    except Exception:  # noqa: BLE001
        pass
    return datos


def _bloque_tendencias(datos: dict) -> str:
    usadas = set(datos.get("usadas", []))
    opciones = [f"- [{x['tendencia']}] {q['pregunta']} (ángulo: {q.get('angulo', '')}; subtema: {q.get('subtema', '')})"
                for x in datos.get("tendencias", []) for q in x.get("preguntas", [])
                if q.get("pregunta") not in usadas]
    if not opciones:
        return ""
    return f"""MODO ACTUALIDAD (este video): elige el tema de esta lista de preguntas que la gente se
hace por lo que está pasando hoy (entre corchetes, la tendencia que la inspira). Puedes
afinar la pregunta, pero el video debe salir de una de ellas. En "pregunta_origen" copia
la pregunta exacta de la lista y en "tendencia" la tendencia entre corchetes.
{chr(10).join(opciones)}
"""


# ---------- banco de temas: investigación semanal del nicho ----------
DIAS_BANCO = 7


def banco_de_temas(claude: Claude, cfg: dict, forzar: bool = False) -> dict:
    """Una vez por semana (o cuando quedan pocos): investiga qué funciona AHORA en el nicho y
    guarda ~30 temas concretos con su gancho, el dato que sorprende, la fuente y la evidencia
    de que ese tipo de tema rinde. El director elige de aquí en vez de inventar en frío."""
    from .memoria import banco, guardar_banco
    datos = banco()
    libres = [x for x in datos.get("temas", []) if not x.get("usado")]
    hoy = datetime.now(timezone.utc)
    fecha = datos.get("fecha")
    viejo = not fecha or (hoy - datetime.fromisoformat(fecha)).days >= DIAS_BANCO
    if not forzar and libres and len(libres) >= 8 and not viejo:
        return datos
    canal = cfg["canal"]
    usados = [m.get("tema", "") for m in memoria()][-120:]
    system = (profesional("investigador") + f"Eres el investigador de contenido de una página de {canal.get('rol', '')} "
              f"en {canal['idioma']} para {canal['publico']}. Tu trabajo es encontrar los temas con más "
              "potencial de hacerse virales en ESTE nicho, con evidencia, no por intuición.")
    usuario = f"""Fecha de hoy: {hoy.strftime('%Y-%m-%d')}.
INVESTIGA con la búsqueda web (varias búsquedas, en español y en inglés):
1) Qué videos cortos de este nicho están teniendo más vistas en los últimos meses en TikTok, Reels y
   YouTube Shorts: de qué tratan, con qué ángulo y qué gancho usan (no copies el video: aprende el tipo
   de tema que funciona).
2) Qué se pregunta la gente de verdad sobre estos subtemas (Reddit, foros, «la gente también pregunta»,
   comentarios virales).
3) Aniversarios y fechas de los próximos 30 días que den para una historia o explicación del nicho,
   y descubrimientos o noticias recientes del nicho que la gente aún no conoce.

Subtemas del nicho: {"; ".join(canal['subtemas'])}
Prohibido: {", ".join(canal['prohibidos'])}
{REGLAS_TENDENCIAS}
Ya publicados (no repitas ni hagas variantes cercanas): {"; ".join(usados) or "ninguno"}

Devuelve 30 temas CONCRETOS (un caso, un objeto, una persona, un experimento; nunca «5 curiosidades de...»),
repartidos entre los subtemas, cada uno con:
- "tema": la pregunta o el caso en una frase
- "gancho": la frase de apertura (máximo 12 palabras, se entiende en 3 segundos)
- "dato_sorpresa": el dato exacto que hace decir «no puede ser»
- "fuente": url seria que lo confirma
- "evidencia": por qué creemos que funcionará (videos parecidos con muchas vistas, pregunta muy repetida...)
- "subtema": uno de los subtemas
- "fecha_clave": "AAAA-MM-DD" si es un aniversario o fecha en los próximos 30 días, si no ""

JSON: {{"temas": [{{"tema": "...", "gancho": "...", "dato_sorpresa": "...", "fuente": "...", "evidencia": "...",
"subtema": "...", "fecha_clave": ""}}]}}"""
    try:
        nuevos = claude.json(system, usuario, max_tokens=9000, web=True)
    except Exception as e:  # noqa: BLE001
        print("No se pudo investigar el banco de temas:", e)
        return datos
    temas = [t for t in nuevos.get("temas", []) if isinstance(t, dict) and t.get("tema") and t.get("fuente")]
    if not temas:
        return datos
    datos = {"fecha": hoy.isoformat(timespec="seconds"), "temas": temas + libres[:10]}
    guardar_banco(datos)
    return datos


def pilar_del_turno(cfg: dict) -> str:
    """El subtema de este video: rota para que haya variedad y sale más el que mejor rinde."""
    subtemas = list(cfg["canal"]["subtemas"])
    recientes = [m.get("subtema", "") for m in memoria()[-2:]]
    opciones = [s for s in subtemas if s not in recientes] or subtemas
    pesos = aprendizaje.pesos(opciones, "subtema")
    return random.choices(opciones, weights=pesos)[0]


def _opciones_banco(datos: dict, pilar: str, cfg: dict, n: int = 12) -> list:
    hoy = datetime.now(timezone.utc).date()

    def prioridad(t):
        p = 0.0
        if t.get("subtema") == pilar:
            p += 2
        try:
            dias = abs((datetime.fromisoformat(t["fecha_clave"]).date() - hoy).days) if t.get("fecha_clave") else 99
        except ValueError:
            dias = 99
        if dias <= 3:
            p += 4  # un aniversario de esta semana va primero
        return p + random.random()

    libres = [t for t in datos.get("temas", []) if not t.get("usado")]
    return sorted(libres, key=prioridad, reverse=True)[:n]


def _palabras(texto: str) -> set:
    import re as _re
    return {w for w in _re.findall(r"[a-záéíóúñü0-9]+", (texto or "").lower()) if len(w) > 3}


def marcar_usado(tema: str):
    """Marca como usado el tema del banco que más se parece al elegido (el director suele afinarlo)."""
    from .memoria import banco, guardar_banco
    datos = banco()
    elegido = _palabras(tema)
    mejor, parecido = None, 0.0
    for t in datos.get("temas", []):
        propias = _palabras(t.get("tema", ""))
        if propias and elegido:
            k = len(propias & elegido) / min(len(propias), len(elegido))
            if k > parecido:
                mejor, parecido = t, k
    if mejor is not None and parecido >= 0.5:
        mejor["usado"] = True
        guardar_banco(datos)


def jurado(claude: Claude, cfg: dict, candidatos: list) -> dict:
    """Prueba del dedo: tres espectadores típicos de la página ven SOLO el gancho de cada candidato
    mientras hacen scroll. Puntúa si se detienen, si lo verían hasta el final y si lo compartirían.
    Es otra mirada (no la del que propuso los temas), para no enamorarse de las propias ideas."""
    canal = cfg["canal"]
    lista = "\n".join(f"{i + 1}. gancho: «{c.get('gancho', '')}» | tema: {c.get('tema', '')} | dato: {c.get('dato_sorpresa', '')}"
                      for i, c in enumerate(candidatos))
    system = ("Simulas a tres espectadores reales de una página de Facebook de " + canal.get("rol", "") +
              f" ({canal['publico']}): uno distraído que hace scroll rápido, uno curioso que ve todo y uno "
              "exigente que ya vio muchos videos del tema. Eres honesto y duro: casi nada es un 10.")
    usuario = f"""Estos son ganchos de videos candidatos. Para cada uno, cada espectador dice del 1 al 10:
- para: ¿dejaría de hacer scroll en los primeros 2 segundos?
- final: ¿lo vería hasta el final?
- comparte: ¿lo mandaría a alguien o comentaría?
Y "visto": true si el tema está muy repetido en redes (ya cansa).
{lista}
JSON: {{"votos": [{{"n": 1, "para": [7, 5, 4], "final": [6, 5, 3], "comparte": [5, 4, 2], "visto": false}}]}}"""
    try:
        return claude.json(system, usuario, max_tokens=2500)
    except Exception as e:  # noqa: BLE001
        print("El jurado no pudo votar:", e)
        return {}


def puntaje_jurado(votos: dict, n: int) -> float | None:
    for v in votos.get("votos") or []:
        if v.get("n") == n:
            try:
                media = lambda xs: sum(float(x) for x in xs) / max(1, len(xs))  # noqa: E731
                total = 0.45 * media(v.get("para") or [0]) + 0.3 * media(v.get("final") or [0]) + 0.25 * media(v.get("comparte") or [0])
                return total * (0.7 if v.get("visto") else 1.0)
            except (TypeError, ValueError):
                return None
    return None


CRITERIOS_VIRALES = ("curiosidad", "emocion", "compartir", "utilidad", "universal", "visual", "verificable")


def _lista(items) -> str:
    return "".join(f"- {x}\n" for x in (items or []))


def puntaje_viral(candidato: dict, pesos: dict) -> float:
    """Suma ponderada de los puntos del candidato (los pesos dependen del nicho)."""
    puntos = candidato.get("puntos") or {}
    total = 0.0
    for c in CRITERIOS_VIRALES:
        try:
            v = max(0.0, min(5.0, float(puntos.get(c, 0))))
        except (TypeError, ValueError):
            v = 0.0
        total += v * float(pesos.get(c, 1))
    return total


def mejor_candidato(datos: dict, canal: dict) -> dict:
    """Elige el candidato con más potencial viral según los pesos del nicho. Los que no se pueden
    verificar (menos de 3) quedan fuera salvo que no haya otro."""
    candidatos = [c for c in (datos.get("candidatos") or []) if isinstance(c, dict) and c.get("tema")]
    if not candidatos:
        return datos["elegido"]  # formato viejo
    pesos = canal.get("pesos_virales") or {}
    seguros = [c for c in candidatos if float((c.get("puntos") or {}).get("verificable", 0) or 0) >= 3] or candidatos
    # Sin dato concreto ni fuente no hay video que sorprenda
    con_dato = [c for c in seguros if str(c.get("dato_sorpresa", "")).strip() and str(c.get("fuente", "")).strip()]
    seguros = con_dato or seguros
    maximo = 5.0 * sum(float(pesos.get(c, 1)) for c in CRITERIOS_VIRALES) or 1.0
    votos = datos.get("_jurado") or {}

    def final(c):
        propio = puntaje_viral(c, pesos) / maximo * 10  # 0 a 10
        j = puntaje_jurado(votos, candidatos.index(c) + 1)
        return propio if j is None else 0.4 * propio + 0.6 * j  # pesa más la mirada de afuera

    elegido = max(seguros, key=final)
    elegido = dict(elegido)
    elegido["puntaje_viral"] = round(final(elegido), 1)
    elegido.setdefault("angulo", "")
    elegido.setdefault("subtema", "")
    elegido.setdefault("tendencia", "")
    return elegido


def elegir_tema(claude: Claude, cfg: dict, estilo: dict) -> dict:
    canal = cfg["canal"]
    guia = canal.get("guia") or {}
    datos_tendencias = recuento_del_dia(claude, cfg) if estilo.get("tendencia") else {}
    bloque = _bloque_tendencias(datos_tendencias) if datos_tendencias else ""
    pilar = pilar_del_turno(cfg)
    bloque_banco = ""
    if not bloque and cfg["produccion"].get("banco_temas", True):
        opciones = _opciones_banco(banco_de_temas(claude, cfg), pilar, cfg)
        if opciones:
            bloque_banco = ("TEMAS INVESTIGADOS PARA ESTE NICHO (con evidencia de que este tipo de tema funciona; "
                            "toma de aquí al menos 4 de tus candidatos, puedes afinarlos):\n" + "".join(
                                f"- {t['tema']} | gancho: {t.get('gancho', '')} | dato: {t.get('dato_sorpresa', '')} | "
                                f"fuente: {t.get('fuente', '')} | por qué: {t.get('evidencia', '')}"
                                + (f" | fecha clave: {t['fecha_clave']}" if t.get("fecha_clave") else "") + "\n"
                                for t in opciones))
    usados = [m.get("tema", "") for m in memoria()]
    system = (
        profesional("director_creativo") + f"Eres el director creativo de una página de Facebook de {canal.get('rol', 'videos explicativos animados')} "
        f"en {canal['idioma']}. Público: {canal['publico']}. Tu trabajo es elegir el próximo "
        "tema con más potencial de hacerse viral: que retenga hasta el final, que se comparta y que sea verificable y nuevo."
    )
    usuario = f"""Canal: {canal['nombre']}
Subtemas posibles: {", ".join(canal['subtemas'])}
Temas prohibidos: {", ".join(canal['prohibidos'])}
Facebook NO recomienda a gente nueva contenido con afirmaciones de salud o de dinero: nada de lo que es bueno o malo para el cuerpo, comida y bacterias, dietas, enfermedades, riesgos para la salud, precios, ofertas, compras, inflación, inversiones, bolsa ni criptomonedas. Esos temas se quedan sin alcance aunque el video sea bueno.

Videos publicados y su rendimiento (usa esto para aprender qué funciona):
{resumen_para_director()}
{aprendizaje.texto_lecciones()}

Temas ya usados (no los repitas ni hagas variantes cercanas):
{"; ".join(usados[-150:]) or "ninguno"}

{bloque}{bloque_banco}
Subtema preferido para este video (para que haya variedad; úsalo salvo que haya algo mucho mejor): {pilar}
Para este video ya se sorteó:
- Tipo de gancho: {estilo['tipo_gancho']}
- Formato ganador (el tema DEBE encajar en él): {estilo['estructura']}

Qué temas tienen más potencial en ESTE nicho (investigación):
{_lista(guia.get('temas_virales'))}Temas que rinden poco aquí (evítalos): {", ".join(guia.get('temas_flojos') or []) or "ninguno"}
Emoción que buscamos: {guia.get('emocion_objetivo', 'asombro y curiosidad')}

Propón 8 temas candidatos concretos (no genéricos: {canal.get('ejemplo_tema', '"por qué el pan se pone duro y no blando como las galletas" en vez de "la ciencia del pan"')}), cada uno con su ángulo sorprendente
y la frase gancho exacta con la que abriría el video (máximo 12 palabras, que se entienda en 3 segundos).
Puntúa cada candidato del 1 al 5, con honestidad (casi nada merece 5 en todo):
- curiosidad: ¿abre una pregunta que el espectador NECESITA ver resuelta?
- emocion: ¿provoca asombro, sorpresa, intriga o diversión (emociones que se comparten), no algo neutro?
- compartir: ¿dan ganas de mandárselo a alguien o decir «eso me pasa»? (lo que más reparte Facebook)
- utilidad: ¿sirve para algo en la vida real, dan ganas de guardarlo?
- universal: ¿le pasa o le interesa a casi todo el público latino, no a un grupo pequeño?
- visual: ¿se puede MOSTRAR con animación (algo que se mueve, se abre o cambia), no solo decir?
- verificable: ¿los datos se pueden confirmar con fuentes serias?

Devuelve JSON:
{{"candidatos": [{{"tema": "...", "angulo": "...", "subtema": "...", "tendencia": "de qué se está hablando o vacío",
  "pregunta_origen": "...", "gancho": "frase de apertura", "dato_sorpresa": "el dato exacto que sorprende",
  "fuente": "url que lo confirma", "tono_visual": "uno de: {", ".join((guia.get('estilos_por_tema') or {}).keys()) or "libre"}",
  "puntos": {{"curiosidad": 1, "emocion": 1, "compartir": 1, "utilidad": 1, "universal": 1, "visual": 1, "verificable": 1}},
  "por_que": "..."}}]}}"""
    # Con lista de tendencias no hace falta buscar en internet otra vez (ahorra uso de Claude).
    datos = claude.json(system, usuario, max_tokens=5000, web=not (bloque or bloque_banco))
    candidatos = [c for c in (datos.get("candidatos") or []) if isinstance(c, dict) and c.get("tema")]
    if len(candidatos) >= 2 and cfg["produccion"].get("jurado_temas", True):
        datos["_jurado"] = jurado(claude, cfg, candidatos)
    elegido = mejor_candidato(datos, canal)
    if bloque_banco:
        marcar_usado(elegido.get("tema", ""))
    if bloque and elegido.get("pregunta_origen"):
        datos_tendencias.setdefault("usadas", []).append(elegido["pregunta_origen"])
        guardar_recuento(datos_tendencias)
    if not bloque:
        elegido["tendencia"] = ""
        _contar_clasico(cfg)
    return elegido
