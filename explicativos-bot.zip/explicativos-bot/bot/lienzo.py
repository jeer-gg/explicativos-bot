"""Motor de lienzo: el video completo se dibuja en un canvas 2D, toma por toma.

Así se hicieron los videos de muestra que más gustaron. Claude escribe UN archivo JavaScript por
video (con el ejemplo de su página como guía), el bot lo prueba en Chrome sin pantalla, graba los
cuadros a 30 fps y los une con la voz de Gemini, los sonidos de cada corte y la música.

Ventajas frente al 3D: un solo pedido a Claude por video (gasta mucho menos), no hay errores de
compilación de escenas, y los personajes, insertos y cortes salen siempre con la misma calidad.
"""
from __future__ import annotations

import base64
import functools
import http.server
import json
import re
import shutil
import subprocess
import threading
from pathlib import Path

from .claude import Claude, extraer_codigo
from .config import PUBLICO, RAIZ, prompt
from .equipo import profesional

CARPETA = RAIZ / "lienzo"
FPS = 30


# ---------- datos para el motor ----------
def datos_voz(tiempos: dict) -> dict:
    """Palabras de la voz real con su segundo exacto (el motor corta y subtitula con esto)."""
    palabras = []
    for k, e in enumerate(tiempos["escenas"]):
        for p in e["palabras"]:
            palabras.append({"w": p["w"], "t": round(e["inicio"] + float(p["t"]), 3),
                             "d": round(float(p.get("d", 0.3)), 3), "frase": k})
    return {"palabras": palabras, "duracion": float(tiempos["total"])}


def _plan_tomas(plan: dict, guion: dict) -> str:
    """El plan de tomas (del montaje del bot) en texto, para que Claude lo siga."""
    lineas = []
    for i, (e, g) in enumerate(zip(plan["escenas"], guion["escenas"])):
        lineas.append(f"\nESCENA {i + 1} — voz: «{g['voz']}»\n  qué se ve: {g.get('visual', '')}")
        palabras = e.get("palabras") or []
        for k, t in enumerate(e.get("tomas") or [{"inicio": 0, "tipo": "personaje", "encuadre": "medio", "luz": "normal"}]):
            # la palabra donde corta (la primera cuyo tiempo llega al corte)
            desde = next((p["w"] for p in palabras if float(p["t"]) >= t["inicio"] - 0.1), palabras[0]["w"] if palabras else "")
            extra = []
            if t.get("ve"):
                extra.append(f"se ve: {t['ve']}")
            if t.get("inserto"):
                extra.append(f"inserto: {json.dumps(t['inserto'], ensure_ascii=False)}")
            if t.get("ficha"):
                extra.append(f"ficha: {t['ficha'].get('titulo', '')} / {t['ficha'].get('sub', '')}")
            if t.get("sello"):
                extra.append(f"sello: {t['sello']}")
            if t.get("3d"):
                extra.insert(0, "EN 3D")
            lineas.append(f"  - toma desde «{desde}» ({e['inicio'] + t['inicio']:.1f} s): {t['tipo']}, encuadre "
                          f"{t.get('encuadre', 'medio')}, luz {t.get('luz', 'normal')}" + ("; " + "; ".join(extra) if extra else ""))
    return "\n".join(lineas)


def pedido(cfg: dict, guion: dict, plan: dict, estilo: dict) -> str:
    colores = estilo.get("colores") or {}
    reparto = json.dumps(guion.get("personajes") or [], ensure_ascii=False)
    fondos = json.dumps(guion.get("fondos") or [], ensure_ascii=False)
    frases = json.dumps([e["voz"] for e in guion["escenas"]], ensure_ascii=False)
    return (f"VIDEO: «{guion['titulo']}» ({plan.get('duracion', 0) or ''})\n"
            f"Paleta de la página: {json.dumps(colores, ensure_ascii=False)}\n"
            f"Color de contorno: {cfg['estilo'].get('color_contorno', '#1B1B1F')}\n"
            f"Estilo de la página: {cfg['estilo'].get('descripcion_3d', '').strip()[:700]}\n"
            f"Dirección de arte: {json.dumps(guion.get('direccion_arte') or {}, ensure_ascii=False)}\n"
            f"REPARTO (personajes fijos): {reparto}\n"
            f"FONDOS (lugares de este video): {fondos}\n"
            f"Objeto que se repite: {guion.get('objeto_recurrente', '')}\n"
            f"frases (pásalas tal cual a armar): {frases}\n"
            f"\nPLAN DE TOMAS (una toma por línea, en este orden):{_plan_tomas(plan, guion)}\n")


def _ejemplo(cfg: dict) -> str:
    pagina = (cfg.get("canal") or {}).get("id", "explicativos")
    ruta = CARPETA / "ejemplos" / f"{pagina}.js"
    if not ruta.exists():
        ruta = CARPETA / "ejemplos" / "explicativos.js"
    return ruta.read_text(encoding="utf-8")


def escribir(claude: Claude, cfg: dict, guion: dict, plan: dict, estilo: dict, error: str = "",
             previo: str = "") -> str:
    system = profesional("director_arte") + prompt("lienzo.md").replace("{ejemplo}", _ejemplo(cfg))
    texto = pedido(cfg, guion, plan, estilo)
    if error:
        texto += (f"\n\nEsta versión falló al dibujarse:\n```js\n{previo}\n```\nError:\n{error[-2500:]}\n"
                  "Corrígela y devuelve el archivo completo.")
    salida = claude.texto(system, texto, modelo=claude.modelo_escenas, max_tokens=20000)
    codigo = extraer_codigo(salida)
    # siempre importa del motor del estudio
    return re.sub(r"from\s+['\"]\.?/?engine(\.js)?['\"]", "from './engine.js'", codigo)


# ---------- Chrome sin pantalla ----------
class _Servidor:
    def __enter__(self):
        manejador = functools.partial(_Silencioso, directory=str(CARPETA))
        self.s = http.server.ThreadingHTTPServer(("127.0.0.1", 0), manejador)
        threading.Thread(target=self.s.serve_forever, daemon=True).start()
        self.url = f"http://127.0.0.1:{self.s.server_address[1]}"
        return self

    def __exit__(self, *a):
        self.s.shutdown()


class _Silencioso(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass


def _chrome():
    for nombre in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
        ruta = shutil.which(nombre)
        if ruta:
            return ruta
    return None


def _con_pagina(datos: dict, codigo: str, fn):
    from playwright.sync_api import sync_playwright
    (CARPETA / "datos.json").write_text(json.dumps(datos, ensure_ascii=False), encoding="utf-8")
    (CARPETA / "video.js").write_text(codigo, encoding="utf-8")
    with _Servidor() as srv, sync_playwright() as p:
        ruta = _chrome()
        navegador = p.chromium.launch(executable_path=ruta, args=["--no-sandbox"]) if ruta else \
            p.chromium.launch(args=["--no-sandbox"])
        try:
            pg = navegador.new_page(viewport={"width": 1080, "height": 1920})
            errores = []
            pg.on("pageerror", lambda e: errores.append(str(e)))
            pg.goto(f"{srv.url}/pagina.html?v=video")
            pg.wait_for_function("window.listo === true || window.fallo", timeout=30000)
            fallo = pg.evaluate("window.fallo || ''")
            if fallo:
                raise RuntimeError("El archivo del video no carga: " + fallo[:1500])
            return fn(pg, errores)
        finally:
            navegador.close()


def probar(datos: dict, codigo: str) -> str:
    """Dibuja cuadros repartidos por todo el video. Devuelve el error, o '' si todo funciona."""
    total = datos["duracion"]
    muestras = [round(total * k / 23, 2) for k in range(24)]

    def revisar(pg, errores):
        for t in muestras:
            pg.evaluate(f"window.cuadro({t})")
        propios = pg.evaluate("window.ERRORES || []")
        return "\n".join((errores + list(propios))[:8])

    try:
        return _con_pagina(datos, codigo, revisar)
    except Exception as e:  # noqa: BLE001
        return str(e)[:2500]


def grabar(datos: dict, codigo: str, carpeta: Path) -> tuple[list, list]:
    """Graba todos los cuadros (30 fps). Devuelve (tomas, errores)."""
    carpeta.mkdir(parents=True, exist_ok=True)
    for f in carpeta.glob("*.jpg"):
        f.unlink()
    n = int(datos["duracion"] * FPS) + 1

    def todo(pg, errores):
        for i in range(n):
            url = pg.evaluate(f"window.cuadro({i / FPS})")
            (carpeta / f"f{i:05d}.jpg").write_bytes(base64.b64decode(url.split(",", 1)[1]))
        return pg.evaluate("window.tomas || []"), list(pg.evaluate("window.ERRORES || []"))

    return _con_pagina(datos, codigo, todo)


# ---------- sonido y video ----------
def _sonidos(carpeta: Path) -> tuple[Path, Path]:
    whoosh, golpe = carpeta / "whoosh.wav", carpeta / "golpe.wav"
    if not whoosh.exists():
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "anoisesrc=d=0.4:c=pink:a=0.9",
                        "-af", "bandpass=f=1400:width_type=o:w=2,afade=t=in:d=0.18,afade=t=out:st=0.2:d=0.2,volume=0.5",
                        str(whoosh)], check=True)
    if not golpe.exists():
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "sine=f=70:d=0.35",
                        "-f", "lavfi", "-i", "anoisesrc=d=0.06:c=white:a=0.6", "-filter_complex",
                        "[0]afade=t=out:st=0.02:d=0.3,volume=1.6[a];[1]lowpass=f=2500[b];[a][b]amix=inputs=2:normalize=0,volume=0.8",
                        str(golpe)], check=True)
    return whoosh, golpe


def unir(cuadros: Path, voz: Path, tomas: list, destino: Path, duracion: float, trabajo: Path) -> Path:
    """Cuadros + voz + un 'whoosh' suave en cada corte y un golpe en cada sello."""
    whoosh, golpe = _sonidos(trabajo)
    entradas = ["-framerate", str(FPS), "-i", str(cuadros / "f%05d.jpg"), "-i", str(voz)]
    filtros, etiquetas, n = [], ["[1]"], 1
    for i, tm in enumerate(tomas[:40]):
        for archivo, retraso, usar in ((whoosh, tm["t"] - 0.12, i > 0), (golpe, tm["t"] + 0.4, tm.get("sello"))):
            if not usar:
                continue
            n += 1
            ms = max(0, int(retraso * 1000))
            entradas += ["-i", str(archivo)]
            filtros.append(f"[{n}]volume=0.6,adelay={ms}|{ms}[s{n}]")
            etiquetas.append(f"[s{n}]")
    filtros.append("".join(etiquetas) + f"amix=inputs={len(etiquetas)}:normalize=0:duration=first[a]")
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", *entradas, "-filter_complex", ";".join(filtros),
                    "-map", "0:v", "-map", "[a]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "19",
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-t", f"{duracion:.2f}",
                    str(destino)], check=True)
    return destino


# ---------- todo el paso ----------
def hacer_codigo(claude: Claude, cfg: dict, guion: dict, plan: dict, estilo: dict, datos: dict,
                 guardado: str = "") -> str:
    """Pide el archivo del video y lo prueba; si falla, Claude lo corrige (máximo 2 veces)."""
    codigo = guardado or escribir(claude, cfg, guion, plan, estilo)
    error = probar(datos, codigo)
    intentos = int(cfg["produccion"].get("lienzo_correcciones", 2))
    for _ in range(intentos):
        if not error:
            break
        print("El video no se dibuja bien; lo corrijo:", error[:300])
        codigo = escribir(claude, cfg, guion, plan, estilo, error=error, previo=codigo)
        error = probar(datos, codigo)
    if error:
        raise RuntimeError("El video no se pudo dibujar: " + error[:500])
    return codigo


def renderizar(codigo: str, tiempos: dict, trabajo: Path, destino: Path) -> tuple[Path, list]:
    datos = datos_voz(tiempos)
    tomas, errores = grabar(datos, codigo, trabajo / "cuadros")
    if errores:
        print(f"Aviso: {len(errores)} cuadro(s) usaron la toma anterior:", errores[:3])
    unir(trabajo / "cuadros", PUBLICO / tiempos["audio"], tomas, destino, datos["duracion"], trabajo)
    return destino, errores
