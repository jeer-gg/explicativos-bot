## Manual de animación del estudio (nivel profesional; cúmplelo entero)

### Composición para el teléfono
- La pantalla es vertical. Arriba (el 22 % superior) van los conceptos grandes del video y abajo
  (el 15 % inferior) Facebook pone el nombre, la descripción y los botones: lo importante vive en
  la franja del medio. Ningún detalle clave abajo a la derecha (ahí están los botones).
- Un solo centro de atención a la vez (como mucho dos). Lo que no es el centro se queda quieto o
  se mueve muy poco: si todo se mueve, nada se ve.
- Siluetas claras: cada objeto se reconoce por su forma aunque fuera una sombra negra. Objetos
  grandes, pocos y bien separados, mejor que muchos pequeños.
- Separación figura-fondo: el fondo siempre más apagado, menos saturado y de valor distinto que el
  protagonista. El color más fuerte de la pantalla es el del protagonista o la parte que se nombra.
- La luz viene siempre del mismo lado (arriba a la izquierda) y todo lo apoyado lleva sombra.

### Fondos que se sienten como un lugar (nunca un degradado vacío)
- Cada lugar tiene tres capas: lejos (el `Decorado` del ambiente: paredes, edificios, montañas,
  estantes, estrellas), medio (el objeto y la acción) y cerca (uno o dos elementos que enmarcan
  por un borde: una hoja, el canto de una mesa, una pared, más oscuros).
- Vida en el fondo, lenta y suave: polvo en la luz, burbujas, nubes que se mueven, vapor, luces que
  parpadean despacio. Nunca más rápida que la acción principal.
- La temperatura de la luz cuenta la emoción: cálida para lo cotidiano y lo histórico, fría para el
  laboratorio y el espacio, oscura con un foco para el misterio, verdosa o roja para lo que falla.

### Planos explicativos (cómo se dibuja cada "plano" que pide el guion)
- general: el lugar completo con el protagonista grande en el centro.
- detalle: la parte que se nombra llena la pantalla; lo demás se intuye alrededor.
- por_dentro: el objeto partido en corte limpio (el frente quitado), el interior con colores
  distintos al exterior y `Flecha`/`Linea` mostrando qué se mueve adentro.
- microscopico: escala de moléculas, células o cristales: esferas 3D unidas por barras, o
  formas 2D blandas para células, flotando y vibrando un poco; el `Decorado` "micro" de fondo.
  Lo que se explica (la molécula que se suelta, el cristal que crece) de color fuerte.
- comparacion: dos cosas lado a lado a la misma escala con `Medida`; la pequeña aparece primero y
  la grande entra después para el efecto «¡qué diferencia!».
- historia: diorama de época (el lugar de la historia real, como maqueta) con `Persona2D` y el
  objeto clave grande e iluminado; luz cálida de atardecer.
- linea_tiempo: un camino o riel con 2 a 4 hitos que se encienden uno a uno al decir cada fecha.
- diagrama: el proceso como flujo, con partículas que corren por el camino y flechas que crecen.
- antes_despues: la misma cosa en sus dos estados, uno se transforma en el otro (no aparecen juntos
  de golpe).
- Para un acercamiento dentro del mundo sin salir del plano, usa `Lupa`: un círculo de aumento junto
  a la parte, con el detalle ampliado dentro.

### Movimiento con oficio (los principios de la animación)
- Anticipación: antes de un movimiento grande, un pequeño gesto al revés (se agacha antes de saltar,
  retrocede antes de lanzarse) de 4 a 6 fotogramas.
- Nada lineal: todo arranca y frena suave (`Easing.inOut`, `spring`). Lo que llega, se pasa un poco
  y vuelve (`spring` con poca amortiguación) para que tenga peso.
- Acción secundaria: lo que cuelga, el agua, el humo y el pelo siguen moviéndose cuando lo principal
  se detiene.
- Arcos: lo que vuela o cae va en curva, no en línea recta.
- A tiempo con la voz: el golpe llega justo en la palabra (unas décimas ANTES de su tiempo, para que se
  vea cuando se oye), y la imagen clave se sostiene quieta 0,4 s para que se lea.
- Estirar y encoger suave en lo blando (gotas, gelatina, personajes al saltar), nunca en lo rígido.
- Vida en reposo: lo que está quieto respira (1 a 2 % de escala) o flota un poco; nunca congelado.
- Una cosa a la vez: escalona los movimientos (cada pieza 3 a 5 fotogramas después de la anterior),
  como una cascada, en lugar de mover todo junto.

### Coherencia
- El protagonista tiene siempre los mismos colores, forma y tamaño en todo el video.
- Los textos 3D son pocos, cortos y siempre al lado de lo que señalan.

### Personajes que actúan
- Usa `<Personaje>` (con cara) para la gente; cada personaje del REPARTO con sus rasgos exactos en todas
  las escenas. La expresión cuenta la emoción de la toma: feliz, serio, sorprendido, triste, enojado,
  pensativo, asustado, aburrido, picaro. Cambia la expresión justo en la palabra que la provoca.
- `habla` en true solo mientras ese personaje dice algo; `mira` hacia el otro personaje o el objeto.
- Pose con intención: celular cuando lo usa, brazos_cruzados si está molesto, piensa si duda,
  senala para mostrar, manos_cadera para retar, camina solo mientras se desplaza.
- Dos personajes en cuadro: uno a cada lado, mirándose, a la misma escala, con el objeto entre ellos.

### Montaje por tomas
- El video corta la cámara en cada toma. Construye el lugar completo alrededor del centro, con fondo
  por los cuatro lados (`Decorado` detrás y objetos a los lados), porque la cámara mira desde
  distintos ángulos: general, medio, cerca, detalle, picado, contrapicado y lateral.
- Lo que la toma de "detalle" o "cerca" debe mostrar va a la altura de 0,6 a 1,2 y en el centro.
