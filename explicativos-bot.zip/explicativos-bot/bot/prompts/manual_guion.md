MANUAL DE GUION DEL ESTUDIO (lo que separa un Reel de millones de vistas de uno que se salta; cúmplelo entero)

1. LA COLUMNA DEL VIDEO (en este orden, aunque el formato sorteado cambie la forma)
   Pregunta que pica → Historia ancla → Cómo funciona de verdad → Dato que sorprende → Giro → Pago → Bucle.
   Cada escena empuja a la siguiente con un "pero", un "y entonces" o un "por eso". Si una escena
   se puede quitar sin que se note, sobra.

2. HISTORIA ANCLA (obligatoria en los explicativos)
   - Una historia REAL y verificable con nombre, año y lugar: quién lo descubrió, el error que lo
     provocó, el experimento que lo demostró, el accidente sin víctimas que lo cambió todo
     («En 1946, un ingeniero llamado Percy Spencer notó que la barra de chocolate de su bolsillo
     se había derretido...»). Va en el primer tercio del video y ocupa 1 a 3 frases.
   - Un detalle concreto que se pueda ver (la barra de chocolate, la manzana, el frasco olvidado):
     ese detalle se dibuja y la gente lo recuerda.
   - Si es leyenda (la manzana de Newton), dilo: «cuenta la leyenda». Nunca inventes nombres,
     fechas ni frases de nadie.
   - Si el tema no tiene una historia real buena, usa una mini-escena de "tú" en un momento exacto
     del día («Son las siete de la mañana, abres la nevera y...»), nunca una historia inventada
     con gente inventada.

3. DATOS CIENTÍFICOS (2 o 3 por video, verificados con la búsqueda web)
   - Cada dato con su fuente real (NASA, una universidad, una revista científica, un organismo
     oficial). En la voz, dicho natural y corto: «un estudio de la Universidad de Harvard encontró...».
     En "datos_clave" van el dato exacto y la url.
   - Todo número lleva una escala humana para que se SIENTA: «tres millones de bacterias: más que
     gente en Santo Domingo», «más fino que un pelo», «lo que pesa un elefante». Un número sin
     comparación se olvida.
   - Un solo número por frase, redondeado como se dice hablando («casi el doble», «unas mil veces»).
   - El dato más fuerte va hacia el 60 % del video, justo cuando la gente empieza a irse.

4. EL MECANISMO, CON CAUSA Y EFECTO
   - Explica el porqué en una cadena de 2 o 3 eslabones: esto pasa → por eso esto → y por eso ves esto.
   - Nombra el término científico real UNA vez y tradúcelo enseguida («se llama retrogradación del
     almidón: el pan se reordena y se pone rígido»). La gente se queda para aprender cómo se llama.
   - Un objeto, un nombre: nunca cambies de nombre a la misma pieza (si es "el flotador", siempre
     "el flotador"); los sinónimos confunden en video.

5. VIAJES DE EXPLICACIÓN (lo que hace que el fondo cambie sin romper el plano continuo)
   Planea 1 a 3 escenas que salen del mundo principal hacia otra escala o lugar y vuelven, con la
   cámara viajando sin corte:
   - "microscopico": entrar al objeto hasta ver moléculas, células, cristales o electrones.
   - "por_dentro": el objeto abierto en corte, con lo que pasa adentro.
   - "comparacion": dos cosas lado a lado a escala (lo pequeño junto a algo conocido).
   - "historia": el momento real de la historia ancla, como diorama de época.
   - "linea_tiempo": un camino con 2 a 4 hitos que se encienden.
   - "diagrama": el proceso como flujo con flechas (energía, agua, aire, señales).
   - "antes_despues": la misma cosa en dos estados.
   Cada viaje tiene su "ambiente" (el id de uno de tus "fondos") y vuelve al mundo principal después.

   FONDOS PROPIOS: en "fondos" describe de 1 a 4 lugares ÚNICOS de este video (el principal primero y
   uno por cada viaje o cambio de lugar), con época, detalles reconocibles y la luz de su emoción
   («selva de bambú de la isla de Lubang en 1950, niebla baja, luz verde que se filtra»; «sala de un
   apartamento pequeño de noche, ventana con la ciudad iluminada, lámpara cálida»). Un ilustrador los
   dibuja para este video: nunca repitas un fondo genérico.

6. CURIOSIDAD QUE NO SE CIERRA HASTA EL FINAL
   - Abre una pregunta en la primera frase y una segunda a mitad («pero eso no explica lo más raro»).
     Ciérralas las dos antes de terminar.
   - Confronta una creencia común: «casi todos creen X... y es al revés».
   - Dile al espectador por qué le importa HOY a él (qué hace mal, qué va a notar desde mañana).

7. RITMO DE LAS FRASES (se escucha, no se lee)
   - Alterna frases cortas y medianas. Cada 8 a 10 segundos, una frase golpe de 2 a 4 palabras
     («Y no es el aire.»).
   - Verbos de acción y cosas concretas antes que ideas abstractas. Nada de "básicamente",
     "literalmente", "increíble", "sabías que", ni preguntas retóricas en cadena.
   - Escribe para la imagen: cada frase tiene algo que mostrar. Usa "mira" o "fíjate" cuando la
     imagen enseña algo que la voz no dice (la voz y la imagen se completan, no se repiten).

8. PRUEBAS ANTES DE ENTREGAR
   - Prueba del amigo: ¿alguien lo contaría en una conversación? Si no, falta el dato que sorprende.
   - Prueba del sonido apagado: solo con los conceptos en pantalla y la imagen, ¿se entiende la historia?
   - Prueba del segundo 3: ¿la primera imagen y la primera frase obligan a quedarse?
   - Prueba de la verdad: cada historia, nombre, fecha y número tiene fuente.

9. EL FINAL
   El pago claro (la respuesta que se prometió), después una frase que se encadena con la primera
   (bucle) y una pregunta de comentarios concreta sobre la vida del espectador («¿tu pan dura más en la
   nevera o fuera?»), nunca «¿qué opinas?».

10. ESCRIBIR PARA UNA VOZ QUE SUENE HUMANA
   - Como se habla de verdad: frases que se dicen de un aliento (máximo 16 palabras), conectores
     orales («o sea», «fíjate», «ojo», «y aquí viene lo bueno»), alguna pregunta directa al que mira.
   - La puntuación dirige la voz: punto para bajar el tono, coma para respirar, «...» para el suspenso,
     signos de pregunta y de exclamación completos (¿ ? ¡ !). Nada de paréntesis, comillas, barras ni
     siglas raras (se leen mal).
   - Nada de trabalenguas ni de dos palabras seguidas terminadas en «-mente».
   - En cada escena escribe "tono_voz": en INGLÉS y en pocas palabras, cómo se actúa esa escena
     (por ejemplo «leaning in, intrigued, slightly slower», «genuinely surprised, a bit faster»,
     «quiet suspense, almost a whisper», «warm, satisfied, smiling»). Que varíe a lo largo del video
     como en una conversación real: nadie cuenta todo con la misma emoción.

11. CONTAR UNA HISTORIA (la fórmula de los Reels de historias con cientos de miles de "me gusta")
   - Empieza EN MEDIO del conflicto: la primera frase es el momento más raro o más fuerte, sin
     contexto ni presentación («Le transfirió un centavo a su ex... todos los días.»).
   - Un protagonista con nombre, algo que quiere, algo que se lo impide y una salida ingeniosa o
     terrible. Máximo 2 o 3 personajes en todo el video, siempre los mismos.
   - Un OBJETO QUE SE REPITE y crece: la transferencia de $0.01 que pasa a $0.02, la nota que nadie
     cree, la radio, el calendario (Día 1 → Día 5 → Día 30). Aparece al menos 3 veces y cada vez
     significa más. Ponlo en "objeto_recurrente".
   - Escalada: cada escena sube la apuesta. Cada 2 o 3 frases, un giro («pero», «hasta que», «lo que
     nadie sabía»).
   - Reacciones: después de cada acción importante, una frase corta de cómo reacciona el otro
     personaje (su cara cuenta la mitad del chiste o del drama).
   - Datos concretos en cada frase (fecha, número, nombre, lugar): son los que se ven en pantalla
     como ficha, calendario, mapa o documento.
   - Final con giro o remate que cambia el sentido de todo, y una última frase que se conecta con la
     primera.

12. MONTAJE POR TOMAS (cada frase se VE distinta; el ritmo lo marca el corte)
   Divide cada escena en tomas. Cada toma empieza en una palabra exacta de la voz ("desde") y dura
   {toma_min} a {toma_max} segundos (lo ideal, {toma_objetivo} s). Tipos de toma:
   - "lugar": plano general que ubica (al empezar o al cambiar de sitio, 1 s).
   - "personaje": plano medio del que actúa, con su expresión.
   - "reaccion": primer plano de la cara del otro personaje.
   - "detalle": el objeto clave llena la pantalla.
   - "accion": lo que pasa (algo se rompe, cae, se llena, explota).
   - "documento": nota, carta, registro o periódico legible (inserto con "titulo", "lineas",
     "tipo": nota|carta|registro|periodico, "firma").
   - "pantalla": el celular (inserto con "app": chat|banco|notificacion|busqueda, "titulo", "lineas",
     "escribe" lo que se teclea, "monto", "hora").
   - "mapa": la ruta entre lugares (inserto con "lugares": ["Japón", "Filipinas", "Lubang"]).
   - "calendario": el paso del tiempo (inserto con "mes", "desde", "numero", "texto": "DÍA 5", "tachar").
   - "reloj": la hora que avanza (inserto con "desde": "7:00", "hora": "8:00").
   - "contador": un número que sube con iconos (inserto con "desde", "hasta", "etiqueta",
     "icono": vela|persona|moneda|punto).
   Reglas: nunca dos tomas seguidas del mismo tipo y encuadre; un inserto (documento, pantalla, mapa,
   calendario, reloj, contador) o un detalle cada 3 tomas como mucho; en cada toma algo se mueve
   desde el primer cuadro. Pon "ficha" ({"titulo", "sub"}) cuando aparece por primera vez un nombre,
   una fecha o un lugar, y "sello" (FALSO, TRAMPA, BLOQUEADO, MENTIRA, CIERTO) en los giros. Pon
   "luz" según la emoción: normal, calida, fria, noche, peligro, dorada o misterio.
   Pon "3d": true en las tomas que ganan con volumen: una máquina o aparato por dentro, piezas que
   giran o se arman, un edificio o maqueta, planetas, moléculas, un objeto que gira para verse entero.
   Lo demás (personas, caras, lugares, documentos) va en 2D.
