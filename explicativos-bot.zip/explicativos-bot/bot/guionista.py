"""Guion con investigación y verificación de datos."""
import json

from . import aprendizaje
from .claude import Claude
from .equipo import profesional


def _reglas_guion() -> str:
    from .autocontrol import texto_reglas
    return texto_reglas("guion")


def _bloque_serie(tema: dict, estilo: dict) -> str:
    """Instrucciones extra para historias en partes y continuaciones."""
    parte = tema.get("serie")
    if parte:
        ultima = parte["parte"] >= parte["total"]
        return f"""
SERIE: este video es la PARTE {parte['parte']} de {parte['total']} de «{parte['serie']}».
Lo que ya se contó antes: {parte.get('anterior', '')}
- La primera frase engancha por sí sola a quien no vio lo anterior, y en una frase corta recuerda
  lo esencial ("en la parte anterior viste que..."), sin repetir la explicación.
- Este video responde por completo SU propia pregunta (nadie debe sentirse engañado).
- {"Es la ÚLTIMA parte: cierra la historia con un remate satisfactorio." if ultima else
   "NO es la última: la última frase deja una intriga concreta y verdadera sobre lo que viene en la parte " + str(parte['parte'] + 1) + " (por ejemplo «pero lo más raro pasó después... en la parte " + str(parte['parte'] + 1) + "»). En vez de final en bucle, final con intriga."}
- "portada" empieza con "PARTE {parte['parte']}:".
"""
    if "HISTORIA EN PARTES" in estilo.get("estructura", ""):
        return """
SERIE NUEVA: este video es la PARTE 1 de una historia en 2 o 3 partes.
- Responde por completo su propia pregunta (nadie debe sentirse engañado), pero la historia
  continúa: la última frase deja una intriga concreta y verdadera sobre la parte 2 («y lo que
  pasó después es aún más raro... en la parte 2»). En vez de final en bucle, final con intriga.
- "portada" empieza con "PARTE 1:".
- Añade al JSON el plan de las siguientes partes:
  "serie": {"titulo": "nombre corto de la serie", "total": 2 o 3,
            "siguientes": [{"parte": 2, "tema": "qué cuenta", "angulo": "lo sorprendente"}]}
"""
    return ""


REGLAS_MUNDO_EXPLICATIVO = """- UN SOLO MUNDO QUE EVOLUCIONA (así son los Reels 3D con millones de vistas): todo el video pasa
  en el mismo lugar con el mismo protagonista (un objeto, una máquina, un sistema), y cada
  escena le cambia UNA cosa: se agrega una pieza, se llena, se abre, falla, se arregla. No saltes
  a otro lugar u otro objeto sin motivo; si el tema lo pide, usa un corte ("corte": true) y vuelve
  luego al mundo. En cada escena escribe en "mundo" cómo queda al terminarla.
  · Empieza muchas veces por la versión más simple o rota del objeto («ya tienes un avión: una
    tabla y un palo») y cada frase le agrega la pieza que resuelve el siguiente problema.
  · Muestra qué pasa SIN la pieza (se cae, se desborda, no sube, se rompe) justo antes de
    ponerla: el fallo exagerado es lo que más retiene.
  · Nombra cada parte con su nombre real («el flotador», «el estabilizador horizontal»): la
    gente se queda para aprender cómo se llama.
"""

REGLAS_VISUAL_EXPLICATIVO = """- Lo visual es protagonista: casi siempre un OBJETO o lugar cotidiano grande y detallado que se
  arma, se abre en corte, se compara o se transforma (no gente hablando). Cada escena dice
  qué pieza aparece, qué parte se señala con una etiqueta corta, qué se mide o qué flecha se ve.
"""

REGLAS_MUNDO_HISTORIA = """- HECHOS REALES: la historia pasó de verdad (fechas, lugares y nombres verificables con la
  búsqueda web; pon las fuentes en "datos"). Si un detalle no se sabe, no lo inventes: dilo
  («nadie sabe qué pasó en esos veinte minutos»), porque eso también da suspenso.
- SIN VÍCTIMAS: nada de muertes, tragedias, crímenes con víctimas ni accidentes con heridos.
  El suspenso sale de misterios, enigmas científicos, rescates sin muertos, experimentos,
  inventos, errores famosos, casualidades increíbles y secretos que se descubrieron.
- ESTRUCTURA DE SUSPENSO:
  · Arranca en el momento de máxima tensión o con el dato imposible («En 1977, un
    radiotelescopio captó una señal de 72 segundos… y nunca más volvió a sonar»).
  · Vuelve atrás solo lo necesario para entender, y sube la tensión con 2 o 3 giros.
  · Antes del desenlace, una pausa de intriga («pero lo que encontraron después…»).
  · El desenlace SIEMPRE llega: la respuesta, lo que se descubrió o la mejor explicación que
    hay hoy. Si sigue sin resolverse, dilo y cierra con la pregunta abierta.
  · Remate que deje pensando o que invite a comentar qué habrían hecho.
- Narra como un narrador de misterio: frases cortas, presente narrativo en los momentos de
  tensión («la puerta se abre… y no hay nadie»), sin exagerar lo que pasó.
- UN SOLO ESCENARIO QUE EVOLUCIONA: toda la historia pasa en un escenario de teatro en miniatura
  (el lugar que va con ESTA historia: un barco, un laboratorio, un pueblo, el espacio), con luz de
  cine y un foco cálido sobre el protagonista, donde la escena va cambiando (si la historia salta de
  lugar o de época, usa un corte con "corte": true): entran y salen figuras, aparece
  el objeto clave, cambia la luz. En cada escena escribe en "mundo" cómo queda el escenario al
  terminarla (quién está, qué objeto hay, qué cambió).
"""

REGLAS_VISUAL_HISTORIA = """- Lo visual cuenta la historia como una obra de teatro en miniatura: figuras estilizadas tipo
  maniquí, sin caras ni rasgos (el protagonista de un color fuerte, los demás grises), objetos
  clave grandes y detallados (la carta, el reloj, la antena, la puerta), lugares como maquetas
  de época, y cambios de luz para el suspenso (el foco se apaga, una luz roja, una sombra que
  crece). Nada de personas realistas ni retratos de gente real. Cada escena dice qué figura u
  objeto aparece, qué hace y qué se ilumina. Fechas y cifras clave como tarjeta ("grafico").
"""



def _estilos(cfg: dict) -> dict:
    return ((cfg["canal"].get("guia") or {}).get("estilos_por_tema") or {})


def guia_del_nicho(cfg: dict) -> str:
    """Lo que la investigación dice que funciona en este nicho y para cualquier Reel."""
    g = cfg["canal"].get("guia") or {}
    general = cfg.get("guia_general") or []
    if not g and not general:
        return ""
    partes = ["GUÍA DE CALIDAD (investigación de los videos que más funcionan; cúmplela):"]
    if g.get("emocion_objetivo"):
        partes.append(f"- Emoción que debe dejar el video: {g['emocion_objetivo']}.")
    for titulo, clave in (("Gancho", "gancho"), ("Retención", "retencion"), ("Evitar", "evitar")):
        for x in g.get(clave) or []:
            partes.append(f"- {titulo}: {x}")
    if g.get("ritmo"):
        partes.append(f"- Ritmo: {g['ritmo']}")
    partes += [f"- {x}" for x in general]
    return "\n".join(partes) + "\n\n"

def escribir_guion(claude: Claude, cfg: dict, tema: dict, estilo: dict) -> dict:
    p = cfg["produccion"]
    canal = cfg["canal"]
    historia = canal.get("formato") == "historia"
    if historia:
        system = (
            profesional("guionista_historias") + "Eres guionista de historias reales de suspenso para Facebook Reels en "
            f"{canal['idioma']}. Cuentas como un gran narrador de misterio: frases cortas, tensión "
            "que sube, giros y un desenlace que se paga. Todo lo que cuentas pasó de verdad y tiene "
            "fuente confiable: investiga con la búsqueda web antes de escribir y nunca inventes.")
        reglas_mundo, reglas_visual = REGLAS_MUNDO_HISTORIA, REGLAS_VISUAL_HISTORIA
        cierre_salud = "Cuenta lo que pasó, sin dar consejos."
    else:
        system = (
            profesional("guionista") + "Eres guionista de videos explicativos animados cortos para Facebook Reels en "
            f"{canal['idioma']}. Escribes como se habla, con frases cortas, ritmo ágil y natural y humor ligero. "
            "Cada dato que afirmas debe ser cierto y tener fuente confiable. Investiga antes de escribir."
        )
        reglas_mundo, reglas_visual = REGLAS_MUNDO_EXPLICATIVO, REGLAS_VISUAL_EXPLICATIVO
        cierre_salud = "Explica cómo funcionan las cosas, no qué le conviene a la gente."
    ritmo = float(p.get("palabras_por_segundo", 2.5))
    palabras_max = int(p["duracion_max"] * (ritmo + 0.1))
    palabras_min = int(p["duracion_min"] * (ritmo - 0.1))
    receta = canal.get("receta") or []
    bloque_receta = ("RECETA DEL NICHO (sacada de los videos que más vistas tienen hoy en este nicho; "
                     "en forma, orden y ritmo manda sobre las reglas generales de abajo, pero nunca sobre "
                     "las prohibiciones ni la verdad de los datos):\n"
                     + "".join(f"- {x.strip()}\n" for x in receta) + "\n") if receta else ""
    bloque_guia = guia_del_nicho(cfg)
    usuario = f"""Tema: {tema['tema']}
Ángulo: {tema['angulo']}{(chr(10) + "Gancho propuesto por el director (úsalo o mejóralo, sin perder la idea): «" + tema['gancho'] + "»") if tema.get('gancho') else ""}{(chr(10) + "Tendencia del momento que lo inspira: " + tema['tendencia'] + " (menciónala en la primera frase para enganchar, sin inventar detalles: verifica con la búsqueda web)") if tema.get('tendencia') else ""}
Tipo de gancho: {estilo['tipo_gancho']}
Formato ganador: {estilo['estructura']}
{_bloque_serie(tema, estilo)}{aprendizaje.texto_lecciones()}{_reglas_guion()}
{bloque_receta}{bloque_guia}Reglas:
- La voz arranca en el segundo 0: la primera frase ES el gancho, de 6 a 12 palabras.
- Entre {palabras_min} y {palabras_max} palabras en total, en {p['escenas_min']} a {p['escenas_max']} escenas.
- En "visual" pide UNA acción principal por escena, con el mundo que ya existe y como mucho
  un objeto nuevo (nada de listas de utilería: lupa, globo, sello, moneda...).
- Cada escena dura entre 3 y 5 segundos de voz y muestra UNA idea visual clara (en los videos
  ganadores cambia algo cada 3 a 4 segundos). Muchas escenas
  cortas mantienen la atención mejor que pocas largas.
- Ritmo NATURAL, como alguien que te cuenta algo fascinante en persona: ágil pero sin
  atropellarse. Usa puntuación normal: punto al terminar cada idea y coma donde se respira,
  porque esas pausas son las que hacen que se entienda. Calcula unas {str(ritmo).replace(".", ",")} palabras por segundo
  de video (40 segundos ≈ {int(40 * ritmo)} palabras). Nada de frases de relleno.
- Retención: en los primeros 5 segundos promete algo concreto que se revela al final ("y lo
  más raro es lo que pasa al final"), mete una vuelta de tuerca o dato inesperado cada 2 o 3
  escenas, y termina con un remate que haga querer verlo otra vez o comentar.
- Lo que más premia Facebook es que lo vean COMPLETO, lo vuelvan a ver y lo ENVÍEN a alguien:
  · Una sola idea, bien contada. Nada de listas de cinco cosas.
  · Dura lo que la explicación necesita: sin relleno ni frases de más para alargar, y sin
    cortar información importante para acortar. El rango de palabras es orientativo.
  · El gancho promete algo que solo se cobra viendo: nunca da la respuesta en la primera frase.
  · Háblale al espectador de "tú" (lo que TÚ haces, lo que te pasa a TI), no "yo".
  · La respuesta prometida SIEMPRE se entrega antes del final: un gancho que no cumple hace
    que la gente oculte el video, y eso castiga a la página.
  · Pon al menos un dato o consejo que den ganas de enviárselo a alguien ("tengo que
    decirle esto a mi mamá").
  · Final en bucle: la última frase se encadena con la primera, para que al repetirse el
    video suene continuo y mucha gente lo vea dos veces.
- Nada de "hola", "en este video" ni "suscríbete". Termina con un remate curioso o una
  pregunta que invite a comentar.
- La descripción visual de cada escena debe ser concreta y dibujable: qué personajes u objetos
  hay, qué hacen, qué se mueve, qué metáfora visual explica la idea. Sin texto largo en pantalla
  (máximo 3 palabras de rótulo por escena).
{reglas_mundo}- "concepto" en cada escena: de 1 a 4 palabras que se DICEN TAL CUAL en la voz de esa escena y
  resumen el momento («LA BOLA SUBE», «EL FLOTADOR», «NO SUBE SOLA», «POCA FUERZA»). Es el texto
  grande que aparece arriba de la pantalla; si hay negación, que empiece por ella.
- Nada de afirmaciones de salud ni de dinero (qué es bueno o malo para el cuerpo, riesgos,
  enfermedades, precios, ahorrar o gastar): Facebook no recomienda esos videos a gente nueva.
  {cierre_salud}
- Escribe números como se pronuncian si pueden leerse mal ("dos mil" en vez de "2.000").
- Formato: sigue al pie de la letra la estructura sorteada; es un formato probado con cientos
  de miles de vistas.
{reglas_visual}- "portada": el título grande que aparece al inicio y en la miniatura, de 3 a 6 palabras en
  mayúsculas, que dé ganas de ver (como «ESTE TRIÁNGULO NO ES DE ADORNO» o «SI TE QUEMAS
  COCINANDO...»). Debe decir lo mismo que la primera frase, no otra cosa.
- "grafico" (opcional, en 2 o 3 escenas como máximo): una tarjeta con datos que aparece en
  pantalla. Tipos: {{"tipo": "barras", "items": [{{"etiqueta": "un panel", "valor": 450, "unidad": "W"}}, ...]}}
  (2 a 4 barras), {{"tipo": "mitos", "items": ["hielo", "pasta", "mantequilla"]}} (se tachan con
  una X roja), {{"tipo": "contador", "valor": 1839, "etiqueta": "año"}}. Usa solo datos verificados.
{"- Incluye la versión B del gancho: otra primera escena con un tipo de gancho distinto." if p.get("ab_gancho") else ""}
- Define una dirección de arte común: el mismo protagonista y el mismo mundo visual en todas
  las escenas.
- Plano continuo o cortes: por defecto el video es UN solo plano continuo (la cámara se mueve
  dentro del mismo mundo). Pero si el tema lo pide, marca "corte": true en la escena que empieza
  con un cambio de plano: otro lugar (de la cocina al interior de la pared), otra escala (del
  objeto a lo microscópico), un antes y después, un recuerdo o flashback, una comparación lado a
  lado o un detalle de cerca. Nunca en la primera escena, como mucho 3 cortes por video, y solo
  cuando el cambio ayude a entender o a sorprender (no por adornar). Si no hace falta, todo en
  "corte": false.

Devuelve JSON:
{{
 "titulo": "título corto para Facebook (máx. 60 caracteres)",
 "descripcion": "descripción de 1 a 2 frases que invite a ver",
 "portada": "TÍTULO DE 3 A 6 PALABRAS",
 "pregunta_comentarios": "pregunta corta para el texto de la publicación que invite a comentar (por ejemplo, ¿tú también lo hacías?)",
 "hashtags": ["3 a 5 hashtags específicos del tema, en español, sin genéricos"],
 "escenas": [
   {{"voz": "texto narrado", "visual": "descripción detallada de la ilustración y su animación",
     "rotulo": "0 a 3 palabras o vacío", "palabra_clave": "palabra de la voz donde ocurre el momento visual principal",
     "concepto": "1 a 4 palabras dichas tal cual en la voz", "mundo": "cómo queda el mundo al terminar esta escena (qué piezas hay, en qué estado)", "corte": false,
     "grafico": null,
     "datos": [{{"afirmacion": "...", "fuente": "url o referencia"}}]}}
 ],
{' "gancho_b": {"voz": "...", "visual": "...", "rotulo": "...", "palabra_clave": "...", "tipo": "..."},' if p.get("ab_gancho") else ""}
 "direccion_arte": {{
   "protagonista": "aspecto exacto del personaje o objeto que guía el video (forma, colores, ropa, rasgos) para dibujarlo igual en todas las escenas",
   "secundarios": "otros personajes u objetos que se repiten, con su aspecto",
   "ambiente": "el único lugar donde pasa todo el video (si es grande, como maqueta en corte)",
   "escenario": "cielo | exterior | interior | oscuro | estudio (el que mejor va con ESTE tema; cielo: cosas que vuelan o al aire libre con pasto; exterior: fachada, azotea, calle, de día; interior: dentro de un cuarto, la cocina, el baño, una oficina; oscuro: el cuerpo, la mente, sistemas por dentro, la noche o el suspenso; estudio: objetos pequeños sobre un fondo limpio). Los colores los pone la página: tú solo eliges el lugar",
   "partes": "las piezas del protagonista que se agregan, cambian o se señalan, con su aspecto",
   "metafora": "la metáfora visual central que explica el tema",
   "tono_visual": "uno de: {", ".join(_estilos(cfg).keys()) or "libre"} (el tratamiento visual que mejor va con ESTE tema{(": " + tema['tono_visual']) if tema.get('tono_visual') else ""})"
 }}
}}"""
    guion = claude.json(system, usuario, max_tokens=6000, web=True)
    # El tono visual elegido viaja con su descripción a cada escena (va en la dirección de arte).
    arte = guion.get("direccion_arte")
    estilos = _estilos(cfg)
    if isinstance(arte, dict) and estilos:
        clave = str(arte.get("tono_visual") or tema.get("tono_visual") or "").split(":")[0].strip().lower()
        if clave in estilos:
            arte["tono_visual"] = f"{clave}: {estilos[clave]}"
    return guion


def pulir_gancho(claude: Claude, cfg: dict, guion: dict) -> dict:
    """Escribe varios arranques posibles, los puntúa y se queda con el más fuerte.

    El primer segundo decide si la gente se detiene: se juzga la imagen inicial (que también
    es la miniatura), el título de portada y la primera frase que se oye.
    """
    system = (profesional("editor_ganchos") + "Eres editor de Reels virales en español. Sabes que el 70 % de la gente decide en el "
              "primer segundo si se queda. Juzgas ganchos con frialdad, por lo que hace detenerse "
              "a alguien que está haciendo scroll con el sonido apagado o encendido.")
    usuario = f"""Guion actual (JSON):
{json.dumps(guion, ensure_ascii=False)}

{aprendizaje.texto_lecciones()}
Escribe 6 arranques alternativos para la PRIMERA escena (distintos entre sí: negación de lo
obvio, advertencia directa, número imposible, pregunta que duele, imagen absurda, error común).
Cada uno con: "voz" (primera frase, 6 a 12 palabras, que encaje con la escena 2 del guion),
"portada" (3 a 6 palabras en mayúsculas, dice lo mismo que la voz), "visual" (qué se VE en el
fotograma 0 y qué pasa en el primer segundo: algo grande, raro o a punto de romperse; nunca una
pantalla tranquila, y en el mismo mundo del resto del guion), "palabra_clave" (palabra de la voz
del golpe visual), "rotulo" y "concepto" (1 a 4 palabras dichas tal cual en la voz).

Reglas que separan un gancho que retiene de uno que se salta (datos de 2026):
- No da la respuesta: promete algo que solo se cobra viendo hasta el final.
- Habla de "tú", no de "yo". Empieza por la acción o el error, sin introducción.
- La imagen arranca en plena acción, con lo que es parte de la historia (el objeto, o la persona
  que vive la situación).

Puntúa cada uno de 1 a 10 en: imagen que detiene el scroll en silencio, curiosidad que solo se
cierra viendo hasta el final, claridad en menos de un segundo, emoción (sorpresa, miedo a
equivocarse, risa) y ganas de enviárselo a alguien. Elige el de mejor suma. Si el arranque
actual es mejor, elígelo.

Devuelve JSON: {{"candidatos": [{{"voz": "...", "portada": "...", "visual": "...", "palabra_clave": "...",
"rotulo": "...", "concepto": "...", "notas": {{"imagen": n, "curiosidad": n, "claridad": n, "emocion": n, "compartir": n}}}}],
"elegido": 0}}"""
    try:
        datos = claude.json(system, usuario, max_tokens=4000)
        mejor = datos["candidatos"][int(datos.get("elegido", 0))]
    except Exception as e:  # noqa: BLE001  (si falla, se queda el gancho original)
        print("No se pudo pulir el gancho:", e)
        return guion
    primera = guion["escenas"][0]
    for clave in ("voz", "visual", "palabra_clave", "rotulo", "concepto"):
        if mejor.get(clave):
            primera[clave] = mejor[clave]
    if mejor.get("portada"):
        guion["portada"] = mejor["portada"]
    print("Gancho elegido:", primera["voz"])
    return guion


def verificar_guion(claude: Claude, guion: dict) -> dict:
    """Revisa cada afirmación. Corrige o elimina lo que no se pueda sostener."""
    system = (
        profesional("verificador") + "Eres verificador de datos. Revisas guiones de divulgación antes de publicarse. "
        "Compruebas cada afirmación con fuentes confiables y corriges lo exagerado o falso, "
        "manteniendo el mismo tono, ritmo y longitud aproximada."
    )
    usuario = (
        "Revisa este guion. Si una afirmación es falsa, dudosa o exagerada, reescribe esa parte "
        "de la voz para que sea correcta. No cambies lo que ya es correcto. Devuelve el guion "
        "completo con la misma estructura JSON, añadiendo el campo \"verificacion\": "
        "{\"cambios\": [\"...\"], \"confianza\": \"alta|media|baja\"}.\n\n"
        + json.dumps(guion, ensure_ascii=False, indent=1)
    )
    revisado = claude.json(system, usuario, max_tokens=7000, web=True)
    if not revisado.get("escenas") or len(revisado["escenas"]) != len(guion["escenas"]):
        return guion
    # Conserva lo que el verificador no debía tocar.
    for clave in ("titulo", "descripcion", "portada", "pregunta_comentarios", "hashtags", "serie", "gancho_b", "direccion_arte"):
        if not revisado.get(clave) and guion.get(clave):
            revisado[clave] = guion[clave]
    for nueva, vieja in zip(revisado["escenas"], guion["escenas"]):
        for clave in ("grafico", "concepto", "mundo"):
            if vieja.get(clave) and not nueva.get(clave):
                nueva[clave] = vieja[clave]
    return revisado
