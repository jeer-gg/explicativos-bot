// Pensan2 (psicología oscura): "El truco del mesero de Berlín" (efecto Zeigarnik)
import {armar, conCamara, capaFija, pj, pinta, rr, sombra, tramo, salida, resorte, azar, documento, pantalla, mezclarHex} from './engine.js';

const TINTA = '#0A0506';
const P = {fondo: '#1A0A0C', claro: '#F2E8DC', rojo: '#8E1B23', teal: '#2F4F56', oro: '#D9A441', terra: '#C46A5A', vino: '#2A1618'};
const MESERO = {pelo: 'corto', colorPelo: '#2A1A14', ropa: '#F2E8DC', pantalon: '#1A1214', accesorio: 'bigote', piel: '#E9B892'};
const LEWIN = {pelo: 'corto', colorPelo: '#4A3428', ropa: P.teal, pantalon: '#1E2A2D', accesorio: 'lentes', piel: '#E6B48C'};
const BLUMA = {pelo: 'mono', colorPelo: '#1B1212', ropa: P.rojo, pantalon: '#2A1618', piel: '#EDC3A0'};
const TU = {pelo: 'puntas', colorPelo: '#1B1212', ropa: P.teal, pantalon: '#1E2A2D', piel: '#C98E62'};

// fondo propio: café de Berlín de los años 20, de noche
function cafe(g, w, h) {
  g.fillStyle = '#3A1418';
  g.fillRect(0, 0, w, h);
  // papel tapiz con rayas
  for (let x = 0; x < w; x += 60) {
    g.fillStyle = x % 120 ? 'rgba(0,0,0,0.12)' : 'rgba(255,255,255,0.03)';
    g.fillRect(x, 0, 30, 1150);
  }
  // zócalo de madera
  const mad = g.createLinearGradient(0, 820, 0, 1180);
  mad.addColorStop(0, '#5A2E22');
  mad.addColorStop(1, '#3A1C14');
  g.fillStyle = mad;
  g.fillRect(0, 820, w, 360);
  for (let x = 30; x < w; x += 180) {
    rr(g, x, 860, 140, 260, 8);
    g.strokeStyle = 'rgba(0,0,0,0.35)';
    g.lineWidth = 5;
    g.stroke();
  }
  // ventana con farol de la calle
  rr(g, 640, 200, 340, 560, 150);
  pinta(g, '#0E1A2A', TINTA, 10);
  const farol = g.createRadialGradient(820, 400, 5, 820, 400, 260);
  farol.addColorStop(0, 'rgba(255,214,140,0.9)');
  farol.addColorStop(1, 'rgba(255,214,140,0)');
  g.fillStyle = farol;
  g.fillRect(640, 200, 340, 560);
  g.fillStyle = '#1A1214';
  g.fillRect(812, 420, 14, 340);
  g.strokeStyle = '#5A2E22';
  g.lineWidth = 10;
  g.beginPath();
  g.moveTo(810, 200);
  g.lineTo(810, 760);
  g.moveTo(640, 470);
  g.lineTo(980, 470);
  g.stroke();
  // espejo con marco dorado y letrero
  rr(g, 120, 260, 360, 420, 14);
  pinta(g, '#4A2A2C', P.oro, 12);
  g.fillStyle = 'rgba(255,255,255,0.06)';
  g.beginPath();
  g.moveTo(150, 640);
  g.lineTo(300, 290);
  g.lineTo(360, 290);
  g.lineTo(210, 640);
  g.fill();
  g.font = '900 58px "Inter Display"';
  g.fillStyle = P.oro;
  g.textAlign = 'center';
  g.fillText('CAFÉ', 300, 200);
  // lámparas colgantes
  [300, 760].forEach((x) => {
    g.strokeStyle = TINTA;
    g.lineWidth = 4;
    g.beginPath();
    g.moveTo(x, 0);
    g.lineTo(x, 120);
    g.stroke();
    g.beginPath();
    g.moveTo(x - 70, 190);
    g.quadraticCurveTo(x, 90, x + 70, 190);
    g.closePath();
    pinta(g, P.oro, TINTA, 5);
    const l = g.createRadialGradient(x, 200, 5, x, 260, 520);
    l.addColorStop(0, 'rgba(255,200,120,0.45)');
    l.addColorStop(1, 'rgba(255,200,120,0)');
    g.fillStyle = l;
    g.fillRect(0, 0, w, h);
  });
  // piso a cuadros
  g.fillStyle = '#2A1214';
  g.fillRect(0, 1180, w, h - 1180);
  for (let j = 0; j < 9; j++)
    for (let i = -6; i < 14; i++) {
      if ((i + j) % 2) continue;
      const y0 = 1180 + j * j * 10 + j * 50, y1 = 1180 + (j + 1) * (j + 1) * 10 + (j + 1) * 50;
      const k0 = 1 + j * 0.3, k1 = 1 + (j + 1) * 0.3;
      g.beginPath();
      g.moveTo(540 + (i * 90 - 540) * k0 + 540 - 540, y0);
      g.lineTo(540 + ((i + 1) * 90 - 540) * k0, y0);
      g.lineTo(540 + ((i + 1) * 90 - 540) * k1, y1);
      g.lineTo(540 + (i * 90 - 540) * k1, y1);
      g.fillStyle = '#4A2226';
      g.fill();
    }
  const v = g.createRadialGradient(w / 2, h * 0.5, w * 0.25, w / 2, h * 0.5, w * 1.05);
  v.addColorStop(0, 'rgba(0,0,0,0)');
  v.addColorStop(1, 'rgba(0,0,0,0.55)');
  g.fillStyle = v;
  g.fillRect(0, 0, w, h);
}

function mesa(g, x, y, s = 1) {
  g.save();
  g.translate(x, y);
  g.scale(s, s);
  sombra(g, 0, 190, 170);
  g.fillStyle = '#2A1214';
  g.fillRect(-14, 0, 28, 190);
  g.beginPath();
  g.ellipse(0, 0, 170, 40, 0, 0, 7);
  pinta(g, '#F2E8DC', TINTA, 6);
  // tazas
  [-70, 60].forEach((dx) => {
    rr(g, dx - 26, -60, 52, 48, 10);
    pinta(g, '#FFFFFF', TINTA, 5);
  });
  g.restore();
}

function bandeja(g, x, y) {
  g.beginPath();
  g.ellipse(x, y, 120, 26, 0, 0, 7);
  pinta(g, '#C9C2B6', TINTA, 6);
  rr(g, x - 70, y - 70, 48, 54, 10);
  pinta(g, '#FFFFFF', TINTA, 5);
  rr(g, x + 10, y - 90, 40, 74, 8);
  pinta(g, '#D9A441', TINTA, 5);
}

const enCafe = (cam, actua) => (g, t, tl, p) => {
  const f = capaFija('cafe', 1080, 1920, cafe);
  conCamara(g, cam(p), 0.5, (c) => c.drawImage(f, 0, 0, 1080, 1920));
  conCamara(g, cam(p), 1, (c) => actua(c, t, tl, p));
};
const empuje = (x, y, z, k = 0.1) => (p) => ({x, y, z: z * (1 + k * salida(p))});

function burbuja(g, x, y, r, t, vacia) {
  [[x - r * 0.9, y + r * 1.1, r * 0.12], [x - r * 0.6, y + r * 0.8, r * 0.2]].forEach(([a, b, rr2]) => {
    g.beginPath();
    g.arc(a, b, rr2, 0, 7);
    pinta(g, '#F2E8DC', TINTA, 5);
  });
  g.beginPath();
  g.ellipse(x, y, r * 1.2, r, 0, 0, 7);
  pinta(g, '#F2E8DC', TINTA, 6);
  if (!vacia) {
    ['2 cafés', 'strudel', 'mesa 4'].forEach((l, i) => {
      g.font = '800 34px "Inter Display"';
      g.fillStyle = '#2A1618';
      g.textAlign = 'center';
      g.fillText(l, x, y - 30 + i * 42);
    });
  } else {
    g.font = '900 120px "Inter Display"';
    g.fillStyle = P.rojo;
    g.textAlign = 'center';
    g.fillText('?', x, y + 40 + Math.sin(t * 5) * 6);
  }
}

function tareas(g, t, tl) {
  g.fillStyle = P.fondo;
  g.fillRect(0, 0, 1080, 1920);
  const v = g.createRadialGradient(540, 900, 50, 540, 900, 900);
  v.addColorStop(0, '#3A1418');
  v.addColorStop(1, '#0A0506');
  g.fillStyle = v;
  g.fillRect(0, 0, 1080, 1920);
  // tarea terminada: se apaga
  const a = 1 - tramo(tl, 0.6, 1.6) * 0.75;
  g.globalAlpha = a;
  rr(g, 140, 700, 360, 460, 24);
  pinta(g, '#F2E8DC', TINTA, 7);
  g.lineWidth = 22;
  g.strokeStyle = '#4C9F70';
  g.beginPath();
  g.moveTo(230, 930);
  g.lineTo(300, 1010);
  g.lineTo(420, 850);
  g.stroke();
  g.font = '900 40px "Inter Display"';
  g.fillStyle = '#2A1618';
  g.textAlign = 'center';
  g.fillText('TERMINADA', 320, 1110);
  g.globalAlpha = 1;
  // tarea a medias: brilla y late
  const late = 1 + 0.04 * Math.sin(t * 6);
  g.save();
  g.translate(760, 930);
  g.scale(late, late);
  const halo = g.createRadialGradient(0, 0, 50, 0, 0, 420);
  halo.addColorStop(0, 'rgba(200,40,50,0.55)');
  halo.addColorStop(1, 'rgba(200,40,50,0)');
  g.fillStyle = halo;
  g.fillRect(-420, -420, 840, 840);
  rr(g, -180, -230, 360, 460, 24);
  pinta(g, '#F2E8DC', TINTA, 7);
  rr(g, -130, -40, 260, 50, 25);
  pinta(g, '#D9C8B8', TINTA, 5);
  rr(g, -130, -40, 130 * tramo(tl, 0.2, 0.9), 50, 25);
  g.fillStyle = P.rojo;
  g.fill();
  g.font = '900 40px "Inter Display"';
  g.fillStyle = '#2A1618';
  g.textAlign = 'center';
  g.fillText('A MEDIAS', 0, 180);
  g.font = '900 64px "Inter Display"';
  g.fillText('50 %', 0, -100);
  g.restore();
}

function cuarto(g, t, tl) {
  g.fillStyle = '#0D0A14';
  g.fillRect(0, 0, 1080, 1920);
  // ventana con luna
  rr(g, 640, 300, 300, 380, 10);
  pinta(g, '#18223A', TINTA, 8);
  g.beginPath();
  g.arc(800, 430, 50, 0, 7);
  g.fillStyle = '#F2E8DC';
  g.fill();
  const luz = g.createLinearGradient(640, 680, 300, 1500);
  luz.addColorStop(0, 'rgba(160,180,255,0.18)');
  luz.addColorStop(1, 'rgba(160,180,255,0)');
  g.fillStyle = luz;
  g.beginPath();
  g.moveTo(640, 680);
  g.lineTo(940, 680);
  g.lineTo(700, 1500);
  g.lineTo(160, 1500);
  g.fill();
  // cama
  rr(g, 120, 1060, 840, 300, 30);
  pinta(g, '#3A1C24', TINTA, 7);
  // sentada en la cama, sin poder dormir: almohada, persona y cobija hasta la cintura
  rr(g, 300, 900, 300, 120, 50);
  pinta(g, '#F2E8DC', TINTA, 6);
  pj(g, 470, 1330, 600, {...TU, expresion: 'asustado', pose: 'parado', mira: 0.8}, t);
  g.beginPath();
  g.moveTo(140, 1150);
  g.quadraticCurveTo(540, 1090, 960, 1150);
  g.lineTo(960, 1330);
  g.lineTo(140, 1330);
  g.closePath();
  pinta(g, P.rojo, TINTA, 7);
  // el celular que brilla en la mesa
  rr(g, 840, 900, 70, 110, 12);
  pinta(g, '#111', TINTA, 4);
  g.fillStyle = `rgba(150,210,255,${0.5 + 0.4 * Math.sin(t * 4)})`;
  g.fillRect(848, 910, 54, 88);
}

function sofaTele(g, t, tl, cara) {
  g.fillStyle = '#140A0E';
  g.fillRect(0, 0, 1080, 1920);
  // tele
  rr(g, 160, 360, 760, 480, 24);
  pinta(g, '#0A0A0A', TINTA, 8);
  const corte = tl > 0.5;
  g.fillStyle = corte ? '#050505' : '#2F4F56';
  g.fillRect(190, 390, 700, 420);
  if (!corte) {
    pj(g, 540, 800, 380, {...BLUMA, expresion: 'asustado', pose: 'saluda'}, t);
  } else {
    g.font = '900 64px "Inter Display"';
    g.fillStyle = '#F2E8DC';
    g.textAlign = 'center';
    g.fillText('CONTINUARÁ…', 540, 620);
  }
  const brillo = g.createRadialGradient(540, 620, 50, 540, 900, 900);
  brillo.addColorStop(0, corte ? 'rgba(255,255,255,0.05)' : 'rgba(120,200,210,0.25)');
  brillo.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = brillo;
  g.fillRect(0, 0, 1080, 1920);
  // sofá y espectador de espaldas
  pj(g, 540, 1700, 560, {...TU, expresion: cara, pose: 'parado'}, t);
  rr(g, 80, 1380, 920, 340, 60);
  pinta(g, P.rojo, TINTA, 8);
}

const frases = [
  'Cuenta la historia que un mesero en Berlín recordaba cada pedido sin anotar nada.',
  'Pero cuando le pagaban, lo olvidaba todo.',
  'El psicólogo Kurt Lewin lo notó, y su alumna Bluma Zeigarnik lo probó en 1927.',
  'Recordamos mucho mejor lo que dejamos a medias.',
  'Por eso esa conversación sin cerrar no te deja dormir.',
  'Y por eso las series cortan justo en lo mejor.',
];

const tomas = [
  {t: 0, ficha: ['Berlín', 'un café, años 20'], dibujar: enCafe(empuje(540, 1150, 1.05, 0.08), (c, t) => {
    mesa(c, 250, 1420, 0.9);
    mesa(c, 860, 1450, 0.9);
    pj(c, 560, 1620, 660, {...MESERO, expresion: 'serio', pose: 'parado', mira: 0}, t);
    bandeja(c, 700, 1180);
  }), luz: 'misterio'},
  {desde: 'mesero', dibujar: enCafe(empuje(560, 1250, 1.8), (c, t) => {
    pj(c, 560, 1620, 660, {...MESERO, expresion: 'picaro', pose: 'parado', mira: -0.5}, t);
    bandeja(c, 700, 1180);
  })},
  {desde: 'pedido', dibujar: (g, t, tl) => documento(g, {tipo: 'cuenta', titulo: 'MESA 4', lineas: ['2 cafés con leche', '1 strudel de manzana', '1 agua mineral', 'Total: 3,40 marcos']}, tl, P.fondo)},
  {desde: 'sin', dibujar: enCafe(empuje(600, 1000, 1.8), (c, t, tl) => {
    pj(c, 470, 1620, 660, {...MESERO, expresion: 'feliz', pose: 'piensa', mira: 0.5}, t);
    burbuja(c, 790, 880, 125 * Math.min(1, resorte(tl, 1.2)), t, false);
  })},
  {desde: 'pagaban', sello: 'PAGADO', colorSello: '#4C9F70', dibujar: (g, t, tl) => documento(g, {tipo: 'cuenta', titulo: 'MESA 4', lineas: ['2 cafés con leche', '1 strudel de manzana', '1 agua mineral', 'Total: 3,40 marcos']}, tl + 3, P.fondo)},
  {desde: 'olvidaba', dibujar: enCafe(empuje(600, 1000, 2.0), (c, t, tl) => {
    pj(c, 470, 1620, 660, {...MESERO, expresion: 'pensativo', pose: 'piensa', mira: 0.5}, t);
    burbuja(c, 790, 880, 125, t, true);
  }), luz: 'misterio'},
  {desde: 'psicólogo', ficha: ['Kurt Lewin', 'psicólogo'], dibujar: enCafe(empuje(400, 1200, 1.7), (c, t) => {
    mesa(c, 620, 1420, 1);
    pj(c, 400, 1620, 640, {...LEWIN, expresion: 'pensativo', pose: 'piensa', mira: 1}, t);
  })},
  {desde: 'bluma', ficha: ['Bluma Zeigarnik', 'su alumna · psicóloga'], dibujar: enCafe(empuje(560, 1180, 1.7), (c, t) => {
    pj(c, 560, 1620, 640, {...BLUMA, expresion: 'picaro', pose: 'senala', mira: 1}, t);
  })},
  {desde: '1927', dibujar: (g, t, tl) => documento(g, {tipo: 'registro', encabezado: 'PSYCHOLOGISCHE FORSCHUNG · 1927', titulo: 'Tareas\nsin terminar',
    lineas: ['Por Bluma Zeigarnik', 'Las tareas interrumpidas', 'se recuerdan mejor.'], firma: 'B. Zeigarnik'}, tl, P.fondo)},
  {desde: 'recordamos', dibujar: (g, t, tl) => conCamara(g, {x: 540, y: 960, z: 1 + 0.06 * tl}, 1, (c) => tareas(c, t, tl))},
  {desde: 'medias', dibujar: (g, t, tl) => conCamara(g, {x: 760, y: 930, z: 1.7 + 0.08 * tl}, 1, (c) => tareas(c, t, 3)), luz: 'misterio', sello: 'SIN TERMINAR'},
  {desde: 'conversación', dibujar: (g, t, tl) => pantalla(g, {titulo: 'Ana', lineas: ['Tenemos que hablar.', '¿De qué?', '…mañana te digo.'], mios: [false, true, false], escribiendo: true}, tl, P.fondo, P.rojo)},
  {desde: 'dormir', dibujar: (g, t, tl) => conCamara(g, {x: 520, y: 1100, z: 1.2 + 0.1 * tl}, 1, (c) => cuarto(c, t, tl)), luz: 'noche'},
  {desde: 'series', dibujar: (g, t, tl) => conCamara(g, {x: 540, y: 900, z: 1.05 + 0.06 * tl}, 1, (c) => sofaTele(c, t, tl, 'sorprendido'))},
  {desde: 'mejor', sello: 'CONTINUARÁ', dibujar: (g, t, tl) => conCamara(g, {x: 540, y: 620, z: 1.6}, 1, (c) => sofaTele(c, t, 2, 'enojado'))},
];

export default armar({duracion: 30, frases, tomas, subtitulos: {resalte: '#D9A441'}});
