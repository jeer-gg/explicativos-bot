// Curioso (casa): "Lo más sucio de tu cocina es la esponja"
import {armar, conCamara, capaFija, pj, pinta, rr, sombra, tramo, salida, resorte, azar, calendario, contador, mezclarHex} from './engine.js';

const TINTA = '#3A2A1E';
const K = {fondo: '#F1E4CF', tinta: '#2B241D', naranja: '#F28C28', azul: '#2FA4E7', amarillo: '#F2C94C', madera: '#C89B6D'};
const ROSA = {pelo: 'cola', colorPelo: '#2A1A14', ropa: K.naranja, pantalon: '#3A4A63', piel: '#C98E62'};

// fondo propio: cocina de casa con ventana, azulejos y matas
function cocina(g, w, h) {
  const gr = g.createLinearGradient(0, 0, 0, h);
  gr.addColorStop(0, '#F6E9D2');
  gr.addColorStop(0.6, '#EED9B8');
  g.fillStyle = gr;
  g.fillRect(0, 0, w, h);
  // ventana con sol y matas
  rr(g, 300, 230, 480, 420, 12);
  pinta(g, '#A9D8F0', TINTA, 8);
  g.beginPath();
  g.arc(660, 330, 60, 0, 7);
  g.fillStyle = '#FFF1B8';
  g.fill();
  g.fillStyle = '#8FC07A';
  g.beginPath();
  g.ellipse(420, 650, 140, 120, 0, Math.PI, 0);
  g.fill();
  g.strokeStyle = TINTA;
  g.lineWidth = 8;
  g.beginPath();
  g.moveTo(540, 230);
  g.lineTo(540, 650);
  g.stroke();
  [[360, 640], [700, 640]].forEach(([x, y]) => {
    rr(g, x - 40, y - 10, 80, 70, 10);
    pinta(g, '#C9563F', TINTA, 5);
    for (let k = 0; k < 5; k++) {
      g.save();
      g.translate(x, y - 10);
      g.rotate(-Math.PI / 2 + (k - 2) * 0.45);
      g.beginPath();
      g.ellipse(50, 0, 55, 16, 0, 0, 7);
      pinta(g, '#4E8F45', TINTA, 4);
      g.restore();
    }
  });
  // azulejos
  g.fillStyle = '#FBF4E8';
  g.fillRect(0, 700, w, 480);
  g.strokeStyle = 'rgba(58,42,30,0.15)';
  g.lineWidth = 3;
  for (let x = 0; x <= w; x += 80) {
    g.beginPath();
    g.moveTo(x, 700);
    g.lineTo(x, 1180);
    g.stroke();
  }
  for (let y = 700; y <= 1180; y += 80) {
    g.beginPath();
    g.moveTo(0, y);
    g.lineTo(w, y);
    g.stroke();
  }
  // gabinetes de arriba
  rr(g, 20, 90, 240, 520, 14);
  pinta(g, K.madera, TINTA, 7);
  rr(g, 820, 90, 240, 520, 14);
  pinta(g, K.madera, TINTA, 7);
  // tope, fregadero y gabinetes de abajo
  rr(g, -20, 1180, w + 40, 60, 8);
  pinta(g, '#E9E1D3', TINTA, 7);
  g.fillStyle = K.madera;
  g.fillRect(0, 1240, w, h - 1240);
  for (let x = 30; x < w; x += 260) {
    rr(g, x, 1290, 220, 400, 14);
    g.strokeStyle = TINTA;
    g.lineWidth = 6;
    g.stroke();
  }
  rr(g, 360, 1180, 360, 50, 10);
  pinta(g, '#B7C2C8', TINTA, 6);
  // grifo
  g.strokeStyle = '#9AA3A8';
  g.lineWidth = 26;
  g.lineCap = 'round';
  g.beginPath();
  g.moveTo(540, 1180);
  g.lineTo(540, 1040);
  g.quadraticCurveTo(540, 990, 600, 1000);
  g.stroke();
  const v = g.createRadialGradient(w / 2, h * 0.5, w * 0.35, w / 2, h * 0.5, w * 1.1);
  v.addColorStop(0, 'rgba(0,0,0,0)');
  v.addColorStop(1, 'rgba(60,30,10,0.28)');
  g.fillStyle = v;
  g.fillRect(0, 0, w, h);
}

function esponja(g, x, y, s, sucia, t, nueva = false) {
  g.save();
  g.translate(x, y);
  g.scale(s, s);
  g.rotate(-0.08);
  sombra(g, 0, 70, 130);
  rr(g, -120, -10, 240, 70, 14);
  pinta(g, nueva ? '#F2C94C' : mezclarHex('#F2C94C', '#8A7A3A', sucia), TINTA, 6);
  rr(g, -120, -50, 240, 44, 12);
  pinta(g, nueva ? '#3E9A5A' : mezclarHex('#3E9A5A', '#3A4A30', sucia), TINTA, 6);
  // poros
  const r = azar(9);
  for (let i = 0; i < 26; i++) {
    g.beginPath();
    g.ellipse(-105 + r() * 210, 4 + r() * 46, 5 + r() * 6, 3 + r() * 4, 0, 0, 7);
    g.fillStyle = `rgba(80,60,20,${0.25 + sucia * 0.4})`;
    g.fill();
  }
  if (sucia > 0.3) {
    for (let i = 0; i < 6; i++) {
      g.beginPath();
      g.arc(-90 + i * 36, 62 + ((t * 40 + i * 13) % 40), 6, 0, 7);
      g.fillStyle = 'rgba(120,150,90,0.6)';
      g.fill();
    }
  }
  g.restore();
}

function microscopio(g, x, y, s) {
  g.save();
  g.translate(x, y);
  g.scale(s, s);
  sombra(g, 0, 210, 170);
  rr(g, -150, 170, 300, 50, 14);
  pinta(g, '#3A4150', TINTA, 6);
  g.lineWidth = 50;
  g.strokeStyle = '#3A4150';
  g.lineCap = 'round';
  g.beginPath();
  g.moveTo(70, 180);
  g.quadraticCurveTo(130, 20, 40, -120);
  g.stroke();
  g.save();
  g.rotate(-0.45);
  rr(g, -60, -280, 64, 240, 14);
  pinta(g, '#E9E1D3', TINTA, 6);
  rr(g, -70, -300, 84, 40, 10);
  pinta(g, '#3A4150', TINTA, 5);
  g.restore();
  rr(g, -110, 60, 220, 22, 6);
  pinta(g, '#9AA3A8', TINTA, 5);
  g.restore();
}

function bacterias(g, t, rojas, n = 40) {
  const gr = g.createRadialGradient(540, 960, 60, 540, 960, 1100);
  gr.addColorStop(0, mezclarHex('#E6D58A', '#E6A08A', rojas * 0.5));
  gr.addColorStop(1, mezclarHex('#7A6A2A', '#6A2A2A', rojas * 0.6));
  g.fillStyle = gr;
  g.fillRect(0, 0, 1080, 1920);
  // fibras de la esponja
  const r = azar(21);
  for (let i = 0; i < 14; i++) {
    g.strokeStyle = 'rgba(255,240,190,0.5)';
    g.lineWidth = 30 + r() * 30;
    g.lineCap = 'round';
    g.beginPath();
    const x = r() * 1080, y = r() * 1920;
    g.moveTo(x, y);
    g.bezierCurveTo(x + 300 * (r() - 0.5), y + 400 * (r() - 0.5), x + 600 * (r() - 0.5), y + 300 * (r() - 0.5), x + 500 * (r() - 0.5), y + 700 * (r() - 0.5));
    g.stroke();
  }
  for (let i = 0; i < n; i++) {
    const x = r() * 1080 + Math.sin(t * 1.5 + i) * 18, y = 300 + r() * 1500 + Math.cos(t * 1.2 + i) * 18;
    const peligrosa = i < n * rojas;
    g.save();
    g.translate(x, y);
    g.rotate(i + t * 0.4 * (i % 2 ? 1 : -1));
    if (i % 3) {
      rr(g, -46, -18, 92, 36, 18);
      pinta(g, peligrosa ? '#D9534F' : ['#7BC67B', '#5FB0D9', '#C59BE0'][i % 3], TINTA, 5);
    } else {
      g.beginPath();
      g.arc(0, 0, 26, 0, 7);
      pinta(g, peligrosa ? '#D9534F' : '#F2C94C', TINTA, 5);
    }
    g.restore();
  }
}

function microondas(g, x, y, s, t) {
  g.save();
  g.translate(x, y);
  g.scale(s, s);
  rr(g, -280, -180, 560, 360, 30);
  pinta(g, '#3A3F47', TINTA, 7);
  rr(g, -250, -150, 360, 300, 18);
  g.fillStyle = `rgba(255,200,110,${0.6 + 0.2 * Math.sin(t * 6)})`;
  g.fill();
  g.strokeStyle = TINTA;
  g.lineWidth = 6;
  g.stroke();
  esponja(g, -70, 60, 0.9, 0.7, t);
  g.fillStyle = '#8EF0A0';
  g.font = '800 44px "Inter Display"';
  g.fillText('1:00', 150, -100);
  g.restore();
}

const frases = [
  'Tu esponja de cocina puede tener tantas bacterias como una muestra de heces.',
  'En 2017, científicos alemanes pusieron 14 esponjas usadas bajo el microscopio.',
  'Encontraron 362 tipos de bacterias, y en algunas partes, más de 50 mil millones por centímetro cúbico.',
  'Y ojo: las que se lavaban o se metían al microondas tenían más bacterias de riesgo.',
  'Los investigadores recomiendan cambiarla cada semana.',
];

const enCocina = (cam, actua) => (g, t, tl, p) => {
  const f = capaFija('cocina', 1080, 1920, cocina);
  conCamara(g, cam(p), 0.5, (c) => c.drawImage(f, 0, 0, 1080, 1920));
  conCamara(g, cam(p), 1, (c) => actua(c, t, tl, p));
};
const empuje = (x, y, z, k = 0.1) => (p) => ({x, y, z: z * (1 + k * salida(p))});

const iconoEsponja = (g, x, y) => {
  rr(g, x - 26, y - 6, 52, 18, 5);
  pinta(g, '#F2C94C', TINTA, 3);
  rr(g, x - 26, y - 16, 52, 11, 4);
  pinta(g, '#3E9A5A', TINTA, 3);
};

const tomas = [
  {t: 0, dibujar: enCocina(empuje(540, 1180, 3.0, 0.12), (c, t) => esponja(c, 470, 1170, 1, 0.9, t))},
  {desde: 'bacterias', dibujar: (g, t, tl) => conCamara(g, {x: 540, y: 960, z: 1.5 - 0.35 * salida(tl / 1.5)}, 1, (c) => bacterias(c, t, 0.15))},
  {desde: 'muestra', dibujar: enCocina(empuje(540, 1150, 1.7), (c, t) => {
    pj(c, 540, 1560, 660, {...ROSA, expresion: 'asustado', pose: 'parado', mira: 0.7}, t);
    esponja(c, 760, 1190, 0.6, 0.9, t);
  })},
  {desde: '2017', ficha: ['Universidad de Furtwangen', 'Alemania · 2017'], dibujar: (g, t, tl) => conCamara(g, {x: 540, y: 1100, z: 1.2 + 0.08 * tl}, 1, (c) => {
    const f = capaFija('lab2', 1080, 1920, (x, w, h) => {
      const gr = x.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, '#E4EEF3');
      gr.addColorStop(1, '#B8CCD8');
      x.fillStyle = gr;
      x.fillRect(0, 0, w, h);
      for (let k = 0; k < 3; k++) {
        rr(x, 60, 300 + k * 220, 960, 20, 6);
        pinta(x, '#7E9BB0', TINTA, 5);
        for (let i = 0; i < 8; i++) {
          rr(x, 90 + i * 118, 220 + k * 220, 60, 80, 14);
          pinta(x, ['#9FD8C9', '#F4C27A', '#C9B5E8', '#9CC8EE'][(i + k) % 4], TINTA, 4);
        }
      }
      x.fillStyle = '#9DB6C6';
      x.fillRect(0, 1240, w, h);
    });
    c.drawImage(f, 0, 0, 1080, 1920);
    rr(c, 120, 1240, 840, 40, 8);
    pinta(c, '#E9E1D3', TINTA, 6);
    microscopio(c, 700, 1020, 1);
    pj(c, 330, 1620, 600, {pelo: 'corto', colorPelo: '#C9A24A', ropa: '#F4F1EA', pantalon: '#3A4A63', accesorio: 'lentes', expresion: 'pensativo', pose: 'piensa', mira: 1}, t);
  })},
  {desde: '14', dibujar: (g, t, tl) => contador(g, {desde: 0, hasta: 14, dur: 0.9, etiqueta: 'esponjas usadas', iconos: 14, tam: 200, icono: (c, x, y) => iconoEsponja(c, x, y)}, tl, '#5A4632')},
  {desde: 'microscopio', dibujar: (g, t, tl) => conCamara(g, {x: 540, y: 960, z: 1.8 - 0.5 * salida(tl / 1.4)}, 1, (c) => bacterias(c, t, 0.1, 30))},
  {desde: '362', dibujar: (g, t, tl) => contador(g, {desde: 0, hasta: 362, dur: 1.2, etiqueta: 'tipos de bacterias', iconos: 40, tam: 200,
    icono: (c, x, y, tt, i) => { c.beginPath(); c.roundRect(x - 24, y - 10, 48, 20, 10); pinta(c, ['#7BC67B', '#5FB0D9', '#C59BE0', '#F2C94C'][i % 4], TINTA, 3); }}, tl, '#5A4632')},
  {desde: 'más', dibujar: (g, t, tl) => contador(g, {desde: 0, hasta: 50, dur: 1.2, tam: 92, formato: (v) => '+' + v, sufijo: ' mil millones', etiqueta: 'por centímetro cúbico'}, tl, '#6A2A2A'), ficha: ['Scientific Reports', 'estudio de 2017']},
  {desde: 'ojo', dibujar: enCocina(empuje(540, 1100, 1.9), (c, t) => {
    pj(c, 470, 1560, 660, {...ROSA, expresion: 'picaro', pose: 'senala', mira: 1}, t);
    esponja(c, 800, 1170, 0.6, 0.6, t);
  })},
  {desde: 'microondas', dibujar: enCocina(empuje(540, 1000, 1.6), (c, t) => microondas(c, 540, 1000, 1.2, t))},
  {desde: 'riesgo', dibujar: (g, t, tl) => conCamara(g, {x: 540, y: 960, z: 1.3}, 1, (c) => bacterias(c, t, 0.15 + tramo(tl, 0, 1.4) * 0.5)), luz: 'peligro', sello: 'MÁS RIESGO'},
  {desde: 'investigadores', dibujar: (g, t, tl) => calendario(g, {mes: 'CADA SEMANA', desde: 1, numero: 7, texto: 'ESPONJA NUEVA', tachar: false}, tl, '#C89B6D')},
  {desde: 'semana', dibujar: enCocina(empuje(540, 1120, 1.6), (c, t) => {
    pj(c, 470, 1560, 660, {...ROSA, expresion: 'feliz', pose: 'manos_cadera', mira: 1}, t);
    esponja(c, 800, 1170, 0.6, 0, t, true);
  }), luz: 'calida'},
];

export default armar({duracion: 30, frases, tomas, subtitulos: {resalte: '#F2C94C'}});
