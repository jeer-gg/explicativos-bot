// C MAMUD (explicativos): "El microondas nació de un dulce derretido"
import {escena3d, caja, cilindro, torno, esfera, tubo} from './tres.js';
import {armar, conCamara, capaFija, pj, pinta, rr, sombra, tramo, salida, resorte, azar, documento, calendario, mezclarHex} from './engine.js';

const C = {fondo: '#D3CEC6', tinta: '#1B1B1F', rojo: '#D2452F', claro: '#E9E4DB', verde: '#A3D92B', oro: '#E0A526', gris: '#C2BBAF'};
const TINTA = '#1B1B1F';
const PERCY = {pelo: 'corto', colorPelo: '#4A3A30', ropa: '#F4F1EA', pantalon: '#3B3F4A', accesorio: 'lentes', piel: '#E6B48C'};

// Fondo propio de este video: laboratorio de radares de Raytheon, 1945
function fondoLab(g, w, h) {
  const gr = g.createLinearGradient(0, 0, 0, h);
  gr.addColorStop(0, '#B9C3C4');
  gr.addColorStop(0.62, '#9FAAAC');
  gr.addColorStop(0.62, '#6E6A63');
  gr.addColorStop(1, '#575249');
  g.fillStyle = gr;
  g.fillRect(0, 0, w, h);
  // ventana con la luz de la tarde
  rr(g, 90, 260, 360, 520, 8);
  pinta(g, '#E9E2C8', TINTA, 6);
  const luzV = g.createLinearGradient(90, 260, 450, 780);
  luzV.addColorStop(0, '#FFF3D1');
  luzV.addColorStop(1, '#D9C79A');
  g.fillStyle = luzV;
  g.fillRect(100, 270, 340, 500);
  g.fillStyle = '#9FA6A0';
  [[110, 560, 70, 210], [190, 500, 60, 270], [260, 600, 90, 170], [360, 540, 70, 230]].forEach(([x, y, a, b]) => g.fillRect(x, y, a, b));
  g.strokeStyle = TINTA;
  g.lineWidth = 6;
  g.beginPath();
  g.moveTo(270, 260);
  g.lineTo(270, 780);
  g.moveTo(90, 520);
  g.lineTo(450, 520);
  g.stroke();
  // haz de luz sobre el piso
  g.save();
  g.globalAlpha = 0.18;
  g.fillStyle = '#FFF3D1';
  g.beginPath();
  g.moveTo(100, 780);
  g.lineTo(440, 780);
  g.lineTo(720, 1500);
  g.lineTo(260, 1500);
  g.closePath();
  g.fill();
  g.restore();
  // paneles de instrumentos con medidores
  for (let k = 0; k < 2; k++) {
    const x = 560 + k * 250;
    rr(g, x, 300, 220, 560, 10);
    pinta(g, '#7F8B8E', TINTA, 6);
    for (let j = 0; j < 3; j++) {
      g.beginPath();
      g.arc(x + 70, 390 + j * 150, 44, 0, 7);
      pinta(g, '#EDE6D2', TINTA, 5);
      g.strokeStyle = C.rojo;
      g.lineWidth = 5;
      g.beginPath();
      g.moveTo(x + 70, 390 + j * 150);
      g.lineTo(x + 70 + Math.cos(-2.2 + j) * 34, 390 + j * 150 + Math.sin(-2.2 + j) * 34);
      g.stroke();
      for (let i = 0; i < 3; i++) {
        g.beginPath();
        g.arc(x + 150 + (i % 2) * 34, 360 + j * 150 + i * 28, 9, 0, 7);
        pinta(g, ['#E0A526', '#A3D92B', '#D2452F'][(i + j) % 3], TINTA, 3);
      }
    }
  }
  // cables que cuelgan
  g.strokeStyle = '#2F3336';
  g.lineWidth = 9;
  [[540, 180, 980, 260], [620, 140, 1060, 330]].forEach(([a, b, c, d]) => {
    g.beginPath();
    g.moveTo(a, b);
    g.quadraticCurveTo((a + c) / 2, d + 140, c, d);
    g.stroke();
  });
  // zócalo y baldosas del piso
  g.fillStyle = '#4A463F';
  g.fillRect(0, 1180, w, 22);
  g.strokeStyle = 'rgba(0,0,0,0.18)';
  g.lineWidth = 3;
  for (let i = -10; i < 20; i++) {
    g.beginPath();
    g.moveTo(540 + i * 120, 1200);
    g.lineTo(540 + i * 330, h);
    g.stroke();
  }
  for (let y = 1260; y < h; y += 90 + (y - 1200) * 0.25) {
    g.beginPath();
    g.moveTo(0, y);
    g.lineTo(w, y);
    g.stroke();
  }
  const v = g.createRadialGradient(w / 2, h * 0.5, w * 0.3, w / 2, h * 0.5, w * 1.05);
  v.addColorStop(0, 'rgba(0,0,0,0)');
  v.addColorStop(1, 'rgba(0,0,0,0.35)');
  g.fillStyle = v;
  g.fillRect(0, 0, w, h);
}

function polvo(g, t) {
  const r = azar(11);
  for (let i = 0; i < 30; i++) {
    const x = r() * 1080, y = r() * 1300 + 300;
    g.fillStyle = `rgba(255,245,215,${0.25 + 0.3 * Math.abs(Math.sin(t * 0.8 + i))})`;
    g.beginPath();
    g.arc(x + Math.sin(t * 0.4 + i) * 14, y + Math.cos(t * 0.3 + i) * 10, 3 + (i % 3), 0, 7);
    g.fill();
  }
}

function magnetron(g, x, y, s, t, brillo = 1) {
  g.save();
  g.translate(x, y);
  g.scale(s, s);
  sombra(g, 0, 250, 190, 40);
  // mesa
  rr(g, -200, 150, 400, 40, 8);
  pinta(g, '#6B4A2E', TINTA, 6);
  g.fillStyle = '#5A3D25';
  g.fillRect(-180, 190, 26, 70);
  g.fillRect(154, 190, 26, 70);
  // cuerpo con aletas
  rr(g, -130, -60, 260, 210, 18);
  pinta(g, '#9AA3A8', TINTA, 7);
  for (let i = 0; i < 6; i++) {
    rr(g, -150, -40 + i * 30, 300, 14, 6);
    pinta(g, '#B9C1C5', TINTA, 4);
  }
  // núcleo que brilla
  const n = 0.6 + 0.4 * Math.sin(t * 8);
  const gr = g.createRadialGradient(0, 45, 5, 0, 45, 120);
  gr.addColorStop(0, `rgba(255,190,90,${0.9 * brillo * n})`);
  gr.addColorStop(1, 'rgba(255,120,40,0)');
  g.fillStyle = gr;
  g.beginPath();
  g.arc(0, 45, 120, 0, 7);
  g.fill();
  g.beginPath();
  g.arc(0, 45, 38, 0, 7);
  pinta(g, '#E36B2C', TINTA, 6);
  g.beginPath();
  g.arc(0, 45, 18, 0, 7);
  g.fillStyle = '#FFD27A';
  g.fill();
  // antena tipo bocina
  g.beginPath();
  g.moveTo(-40, -60);
  g.lineTo(-90, -190);
  g.lineTo(90, -190);
  g.lineTo(40, -60);
  g.closePath();
  pinta(g, '#7F8B8E', TINTA, 7);
  g.restore();
}

function ondas(g, x, y, t, color = 'rgba(255,210,122,', n = 4, rmax = 420) {
  for (let i = 0; i < n; i++) {
    const r = ((t * 160 + (i * rmax) / n) % rmax) + 20;
    g.strokeStyle = color + (0.7 * (1 - r / rmax)).toFixed(2) + ')';
    g.lineWidth = 8;
    g.beginPath();
    g.arc(x, y, r, -0.6, 0.6);
    g.stroke();
    g.beginPath();
    g.arc(x, y, r, Math.PI - 0.6, Math.PI + 0.6);
    g.stroke();
  }
}

function dulce(g, x, y, s, derretido, t) {
  g.save();
  g.translate(x, y);
  g.scale(s, s);
  g.rotate(-0.12);
  // envoltorio
  rr(g, -150, -50, 300, 100, 12);
  pinta(g, '#C0392B', TINTA, 6);
  g.fillStyle = '#F4D35E';
  g.fillRect(-60, -50, 40, 100);
  // chocolate que se derrite por el extremo abierto
  const caida = derretido * 140;
  g.beginPath();
  g.moveTo(150, -46);
  g.lineTo(190, -46);
  g.quadraticCurveTo(205, 0, 196, 40 + caida * 0.3);
  g.quadraticCurveTo(190, 60 + caida, 178, 70 + caida);
  g.quadraticCurveTo(166, 60 + caida * 0.6, 160, 50);
  g.lineTo(150, 46);
  g.closePath();
  pinta(g, '#6B3A1E', TINTA, 6);
  if (derretido > 0.2) {
    for (let k = 0; k < 2; k++) {
      const dy = ((t * 120 + k * 90) % 200) * derretido;
      g.beginPath();
      g.ellipse(170 + k * 14, 90 + caida + dy, 10, 16, 0, 0, 7);
      pinta(g, '#6B3A1E', TINTA, 4);
    }
  }
  g.restore();
}

function bolsilloPrimerPlano(g, t, derretido) {
  // bata blanca enorme, el bolsillo en el centro
  g.fillStyle = '#E9E4DB';
  g.fillRect(0, 0, 1080, 1920);
  g.strokeStyle = 'rgba(0,0,0,0.08)';
  g.lineWidth = 3;
  for (let i = 0; i < 12; i++) {
    g.beginPath();
    g.moveTo(i * 100, 0);
    g.quadraticCurveTo(i * 100 + 40, 960, i * 100 - 20, 1920);
    g.stroke();
  }
  dulce(g, 560, 860, 1.9, derretido, t);
  rr(g, 250, 900, 580, 520, 30);
  pinta(g, '#F4F1EA', TINTA, 9);
  g.strokeStyle = TINTA;
  g.lineWidth = 5;
  g.setLineDash([18, 14]);
  rr(g, 280, 930, 520, 460, 22);
  g.stroke();
  g.setLineDash([]);
  // mancha que crece
  g.save();
  g.globalAlpha = 0.85;
  g.beginPath();
  g.ellipse(700, 1000 + derretido * 60, 40 + derretido * 90, 20 + derretido * 70, 0.2, 0, 7);
  g.fillStyle = '#6B3A1E';
  g.fill();
  g.restore();
  // lápiz en el bolsillo
  rr(g, 330, 760, 34, 220, 10);
  pinta(g, '#E0A526', TINTA, 5);
}

function moleculas(g, t, calor) {
  const gr = g.createRadialGradient(540, 960, 50, 540, 960, 1100);
  gr.addColorStop(0, mezclarHex('#103F45', '#E36B2C', calor * 0.6));
  gr.addColorStop(1, '#071C24');
  g.fillStyle = gr;
  g.fillRect(0, 0, 1080, 1920);
  // onda que pasa
  g.strokeStyle = 'rgba(255,210,122,0.55)';
  g.lineWidth = 10;
  g.beginPath();
  for (let x = 0; x <= 1080; x += 12) {
    const y = 600 + Math.sin(x / 70 - t * 10) * 60;
    x ? g.lineTo(x, y) : g.moveTo(x, y);
  }
  g.stroke();
  const r = azar(5);
  for (let i = 0; i < 9; i++) {
    const cx = 170 + (i % 3) * 370 + r() * 60, cy = 820 + Math.floor(i / 3) * 330 + r() * 60;
    const giro = Math.sin(t * 22 + i) * (0.6 + calor * 0.9) + i;
    g.save();
    g.translate(cx + Math.sin(t * 9 + i) * 10 * calor, cy);
    g.rotate(giro);
    // brillo de calor
    if (calor > 0.1) {
      const h = g.createRadialGradient(0, 0, 10, 0, 0, 150);
      h.addColorStop(0, `rgba(255,140,60,${0.45 * calor})`);
      h.addColorStop(1, 'rgba(255,140,60,0)');
      g.fillStyle = h;
      g.beginPath();
      g.arc(0, 0, 150, 0, 7);
      g.fill();
    }
    [[-62, 44], [62, 44]].forEach(([hx, hy]) => {
      g.strokeStyle = TINTA;
      g.lineWidth = 16;
      g.beginPath();
      g.moveTo(0, 0);
      g.lineTo(hx, hy);
      g.stroke();
      g.beginPath();
      g.arc(hx, hy, 34, 0, 7);
      pinta(g, '#F2F2F2', TINTA, 6);
    });
    g.beginPath();
    g.arc(0, 0, 56, 0, 7);
    pinta(g, C.rojo, TINTA, 7);
    g.beginPath();
    g.arc(-16, -18, 14, 0, 7);
    g.fillStyle = 'rgba(255,255,255,0.5)';
    g.fill();
    g.restore();
  }
}

function palomitas(g, t0, t) {
  const r = azar(77);
  for (let i = 0; i < 36; i++) {
    const nace = r() * 1.2;
    const vida = t - nace;
    if (vida < 0) continue;
    const a = -Math.PI / 2 + (r() - 0.5) * 2.6, v = 700 + r() * 600;
    const x = 760 + Math.cos(a) * v * vida, y = 1120 + Math.sin(a) * v * vida + 1400 * vida * vida;
    if (y > 1600) continue;
    g.save();
    g.translate(x, y);
    g.rotate(vida * 8 + i);
    for (let k = 0; k < 4; k++) {
      g.beginPath();
      g.arc(Math.cos(k * 1.6) * 14, Math.sin(k * 1.6) * 14, 18, 0, 7);
      pinta(g, '#FFF6DC', TINTA, 4);
    }
    g.restore();
  }
}

function cocinaFinal(g, t) {
  const gr = g.createLinearGradient(0, 0, 0, 1920);
  gr.addColorStop(0, '#F6E6CC');
  gr.addColorStop(0.6, '#E9D2AE');
  gr.addColorStop(0.6, '#C89B6D');
  gr.addColorStop(1, '#A57E58');
  g.fillStyle = gr;
  g.fillRect(0, 0, 1080, 1920);
  g.strokeStyle = 'rgba(255,255,255,0.45)';
  g.lineWidth = 3;
  for (let x = 0; x < 1080; x += 90) {
    g.beginPath();
    g.moveTo(x, 700);
    g.lineTo(x, 1150);
    g.stroke();
  }
  for (let y = 700; y < 1150; y += 90) {
    g.beginPath();
    g.moveTo(0, y);
    g.lineTo(1080, y);
    g.stroke();
  }
  rr(g, -20, 1150, 1120, 60, 10);
  pinta(g, '#8A6544', TINTA, 6);
  // microondas moderno
  rr(g, 520, 820, 460, 300, 26);
  pinta(g, '#3A3F47', TINTA, 7);
  rr(g, 550, 850, 300, 240, 16);
  const luzM = 0.6 + 0.2 * Math.sin(t * 6);
  g.fillStyle = `rgba(255,200,110,${luzM})`;
  g.fill();
  g.lineWidth = 6;
  g.strokeStyle = TINTA;
  g.stroke();
  g.fillStyle = '#8EF0A0';
  g.font = '800 34px Inter';
  g.fillText('0:30', 870, 900);
  // taza que gira adentro
  g.save();
  g.translate(700, 1040);
  const giro = Math.sin(t * 2.4) * 0.5;
  g.scale(Math.cos(giro), 1);
  rr(g, -60, -90, 120, 110, 16);
  pinta(g, '#F4F1EA', TINTA, 6);
  g.restore();
  // vapor
  for (let k = 0; k < 3; k++) {
    g.strokeStyle = `rgba(255,255,255,${0.5 - k * 0.12})`;
    g.lineWidth = 10;
    g.beginPath();
    for (let y = 0; y < 160; y += 8) g.lineTo(670 + k * 30 + Math.sin(y / 25 + t * 4 + k) * 14, 930 - y);
    g.stroke();
  }
}

const frases = [
  'En 1945, un ingeniero notó algo raro: el dulce de su bolsillo se había derretido… sin fuego.',
  'Se llamaba Percy Spencer y estaba frente a un magnetrón, la pieza que hace funcionar los radares.',
  'Probó con maíz. Las palomitas reventaron por todo el laboratorio.',
  '¿La razón? Las microondas sacuden las moléculas de agua miles de millones de veces por segundo, y ese roce es calor.',
  'Raytheon pidió la patente el 8 de octubre de 1945.',
  'Acuérdate de ese dulce la próxima vez que calientes tu café.',
];

function laboratorio(cam, extra) {
  return (g, t, tl, p) => {
    const lejos = capaFija('lab', 1080, 1920, fondoLab);
    conCamara(g, cam(p), 0.55, (c) => c.drawImage(lejos, 0, 0, 1080, 1920));
    conCamara(g, cam(p), 1, (c) => {
      polvo(c, t);
      extra(c, t, tl, p);
    });
  };
}
const empuje = (x, y, z, k = 0.1) => (p) => ({x, y, z: z * (1 + k * salida(p))});

const tomas = [
  {t: 0, dibujar: (g, t, tl) => conCamara(g, {x: 560, y: 960, z: 1 + 0.08 * tl}, 1, (c) => bolsilloPrimerPlano(c, t, tramo(tl, 0.2, 2.5))), luz: 'calida'},
  {desde: 'ingeniero', dibujar: laboratorio(empuje(420, 1180, 1.55), (c, t, tl) => {
    magnetron(c, 790, 1260, 1, t);
    pj(c, 400, 1520, 640, {...PERCY, expresion: 'pensativo', pose: 'piensa', mira: 0.6}, t);
  })},
  {desde: 'dulce', dibujar: (g, t, tl) => conCamara(g, {x: 640, y: 900, z: 1.25 + 0.1 * tl}, 1, (c) => bolsilloPrimerPlano(c, t, 0.5 + tramo(tl, 0, 1.4) * 0.5)), luz: 'calida'},
  {desde: 'sin', dibujar: laboratorio(empuje(400, 960, 2.6), (c, t) => {
    pj(c, 400, 1520, 640, {...PERCY, expresion: 'sorprendido', pose: 'parado', mira: 0}, t);
  })},
  {desde: 'se', ficha: ['Percy Spencer', 'ingeniero de Raytheon · 1945'], dibujar: laboratorio(empuje(560, 1080, 1.0, 0.06), (c, t) => {
    magnetron(c, 790, 1260, 1, t);
    ondas(c, 790, 1300, t, 'rgba(255,210,122,', 3, 380);
    pj(c, 400, 1520, 640, {...PERCY, expresion: 'serio', pose: 'parado', mira: 0.8}, t);
  })},
  // Toma EN 3D: el magnetrón gira para que se vea su volumen; las ondas y el fondo siguen en 2D
  {desde: 'magnetrón', dibujar: (g, t, tl, p) => {
    const lejos = capaFija('lab', 1080, 1920, fondoLab);
    const cam = {x: 540, y: 1150, z: 1.25 * (1 + 0.08 * salida(p))};
    conCamara(g, cam, 0.55, (c) => c.drawImage(lejos, 0, 0, 1080, 1920));
    conCamara(g, cam, 1, (c) => {
      ondas(c, 540, 1080, t * 1.4, 'rgba(255,210,122,', 4, 420);
      const brillo = 0.5 + 0.4 * Math.sin(t * 8);
      escena3d(c, {x: 540, y: 1240, escala: 190, contorno: TINTA, suelo: null,
        camara: {giro: 0.4 + tl * 0.5, alto: 0.32, dist: 7, mira: [0, 1.0, 0]}}, [
        {geo: caja(3.4, 0.25, 1.8), color: '#6B4A2E', pos: [0, 0.12, 0], sombra: 1.8},
        {geo: caja(1.8, 1.3, 1.2), color: '#9AA3A8', pos: [0, 0.9, 0]},
        ...[0, 1, 2, 3, 4].map((i) => ({geo: caja(2.1, 0.08, 1.4), color: '#B9C1C5', pos: [0, 0.4 + i * 0.25, 0]})),
        {geo: cilindro(0.38, 0.2), color: '#E36B2C', pos: [0, 0.9, 0.7], rot: [Math.PI / 2, 0, 0], brillo},
        {geo: esfera(0.18), color: '#FFD27A', pos: [0, 0.9, 0.82], brillo},
        {geo: torno([[0.25, 0], [0.7, 0.9]], 4), color: '#7F8B8E', pos: [0, 1.55, 0]},
        {geo: tubo([-0.9, 0.6, -0.5], [-1.6, 0.25, -0.7], 0.06), color: '#2F3336'},
      ]);
    });
  }, luz: 'calida'},
  {desde: 'probó', dibujar: laboratorio(empuje(600, 1120, 1.45), (c, t, tl) => {
    magnetron(c, 790, 1260, 1, t);
    pj(c, 420, 1520, 640, {...PERCY, expresion: 'picaro', pose: 'senala', mira: 1}, t);
    // bolsa de maíz junto al aparato
    rr(c, 640, 1060, 110, 150, 16);
    pinta(c, '#F4D35E', '#1B1B1F', 6);
    c.font = '900 30px Inter';
    c.fillStyle = '#1B1B1F';
    c.fillText('MAÍZ', 652, 1150);
  })},
  {desde: 'palomitas', dibujar: laboratorio(empuje(640, 1120, 1.25, 0.04), (c, t, tl) => {
    magnetron(c, 790, 1260, 1, t, 1.3);
    pj(c, 380, 1520, 640, {...PERCY, expresion: 'asustado', pose: 'saluda', mira: 1}, t);
    palomitas(c, 0, tl);
  })},
  {desde: 'razón', dibujar: (g, t, tl) => conCamara(g, {x: 540, y: 1000, z: 1.25 - 0.15 * salida(tl / 2)}, 1, (c) => moleculas(c, t, 0.15))},
  {desde: 'miles', dibujar: (g, t, tl) => conCamara(g, {x: 400, y: 1050, z: 1.8 + 0.1 * tl}, 1, (c) => moleculas(c, t * 1.6, 0.4 + tramo(tl, 0, 2) * 0.4))},
  {desde: 'roce', dibujar: (g, t, tl) => conCamara(g, {x: 540, y: 1150, z: 1.5}, 1, (c) => moleculas(c, t * 2, 1)), luz: 'calida', sello: 'CALOR', colorSello: '#E36B2C'},
  {desde: 'raytheon', dibujar: (g, t, tl) => documento(g, {tipo: 'registro', encabezado: 'OFICINA DE PATENTES · EE. UU.', titulo: 'Método para\ntratar alimentos',
    lineas: ['Patente n.º 2.495.429', 'Inventor: Percy L. Spencer', 'Empresa: Raytheon'], firma: 'P. L. Spencer'}, tl, C.fondo),
    ficha: ['Patente del microondas', 'pedida en 1945']},
  {desde: '8', dibujar: (g, t, tl) => calendario(g, {mes: 'OCTUBRE 1945', desde: 7, numero: 8, texto: 'SE PATENTA'}, tl, C.fondo)},
  {desde: 'acuérdate', dibujar: (g, t, tl) => conCamara(g, {x: 600, y: 1000, z: 1.12 + 0.08 * tl}, 1, (c) => {
    cocinaFinal(c, t);
    pj(c, 330, 1500, 620, {pelo: 'rizado', colorPelo: '#2A1E1A', ropa: C.rojo, piel: '#A86B45', expresion: 'feliz', pose: 'parado', mira: 1}, t);
  }), luz: 'calida'},
];

export default armar({duracion: 30, frases, tomas, subtitulos: {resalte: '#FFD23F'}});
