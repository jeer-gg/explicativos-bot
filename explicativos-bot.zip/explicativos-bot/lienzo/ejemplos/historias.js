// History Time: "La mujer que sobrevivió a tres barcos gemelos" (Violet Jessop)
import {armar, conCamara, capaFija, pj, pinta, rr, sombra, tramo, salida, resorte, azar, calendario, mapa, contador, mezclarHex} from './engine.js';

const TINTA = '#0E0F14';
const VIOLET = {pelo: 'mono', colorPelo: '#3B2A20', ropa: '#2E3A55', pantalon: '#1F2433', piel: '#EDC3A0'};

function cielo(g, w, h, dia) {
  const gr = g.createLinearGradient(0, 0, 0, h * 0.62);
  if (dia) {
    gr.addColorStop(0, '#7FA7C9');
    gr.addColorStop(1, '#D9E3E6');
  } else {
    gr.addColorStop(0, '#070A1A');
    gr.addColorStop(1, '#1E2746');
  }
  g.fillStyle = gr;
  g.fillRect(0, 0, w, h);
  if (!dia) {
    const r = azar(3);
    for (let i = 0; i < 140; i++) {
      g.fillStyle = `rgba(255,255,255,${0.3 + r() * 0.6})`;
      g.beginPath();
      g.arc(r() * w, r() * h * 0.58, r() * 2.6 + 0.6, 0, 7);
      g.fill();
    }
  }
}

function mar(g, w, h, t, dia, y0 = 1150) {
  const gr = g.createLinearGradient(0, y0, 0, h);
  gr.addColorStop(0, dia ? '#4F7FA3' : '#1B2C4A');
  gr.addColorStop(1, dia ? '#24476A' : '#070D1C');
  g.fillStyle = gr;
  g.fillRect(0, y0, w, h - y0);
  g.strokeStyle = dia ? 'rgba(255,255,255,0.35)' : 'rgba(170,200,255,0.25)';
  g.lineWidth = 5;
  for (let k = 0; k < 9; k++) {
    const y = y0 + 40 + k * k * 9 + k * 30;
    g.beginPath();
    for (let x = -40; x <= w + 40; x += 30) {
      const yy = y + Math.sin(x / 60 + t * 1.6 + k) * (4 + k);
      x === -40 ? g.moveTo(x, yy) : g.lineTo(x, yy);
    }
    g.stroke();
  }
}

// transatlántico clase Olympic (casco oscuro, superestructura blanca, 4 chimeneas)
function barco(g, x, y, s, o = {}) {
  g.save();
  g.translate(x, y);
  g.scale(s, s);
  g.rotate(o.inclina || 0);
  const hospital = o.tipo === 'hospital';
  // casco
  g.beginPath();
  g.moveTo(-430, -40);
  g.lineTo(440, -40);
  g.lineTo(400, 90);
  g.lineTo(-380, 90);
  g.closePath();
  pinta(g, hospital ? '#F2EFE9' : '#1A1B22', TINTA, 6);
  g.fillStyle = hospital ? '#2E8B57' : '#B7372B';
  g.fillRect(-382, 70, 782, 18);
  if (hospital) {
    g.fillStyle = '#D2452F';
    g.fillRect(-60, -30, 60, 20);
    g.fillRect(-40, -50, 20, 60);
  }
  // superestructura
  rr(g, -330, -110, 640, 72, 6);
  pinta(g, '#F2EFE9', TINTA, 5);
  for (let i = 0; i < 18; i++) {
    g.beginPath();
    g.arc(-300 + i * 34, -74, 7, 0, 7);
    g.fillStyle = o.luces ? '#FFD98A' : '#3A4150';
    g.fill();
  }
  // chimeneas
  for (let i = 0; i < 4; i++) {
    const cx = -230 + i * 140;
    g.beginPath();
    g.moveTo(cx - 34, -110);
    g.lineTo(cx - 24, -250);
    g.lineTo(cx + 34, -250);
    g.lineTo(cx + 40, -110);
    g.closePath();
    pinta(g, hospital ? '#E7C37A' : '#D9A441', TINTA, 5);
    g.fillStyle = '#16171C';
    g.fillRect(cx - 25, -250, 59, 34);
    if (o.humo) {
      for (let k = 0; k < 3; k++) {
        g.beginPath();
        g.arc(cx + 30 + k * 40 + Math.sin((o.t || 0) * 2 + k) * 6, -290 - k * 34, 26 + k * 12, 0, 7);
        g.fillStyle = `rgba(80,80,90,${0.45 - k * 0.12})`;
        g.fill();
      }
    }
  }
  // mástiles
  g.strokeStyle = TINTA;
  g.lineWidth = 6;
  g.beginPath();
  g.moveTo(-400, -40);
  g.lineTo(-390, -330);
  g.moveTo(410, -40);
  g.lineTo(400, -300);
  g.stroke();
  g.restore();
}

function crucero(g, x, y, s, t) {
  g.save();
  g.translate(x, y);
  g.scale(s, s);
  g.beginPath();
  g.moveTo(-320, -20);
  g.lineTo(250, -20);
  g.lineTo(330, 20);
  g.lineTo(220, 70);
  g.lineTo(-300, 70);
  g.closePath();
  pinta(g, '#7D8590', TINTA, 6);
  rr(g, -160, -90, 220, 70, 6);
  pinta(g, '#9AA2AC', TINTA, 5);
  for (let i = 0; i < 2; i++) {
    rr(g, -130 + i * 110, -170, 50, 80, 4);
    pinta(g, '#5E6670', TINTA, 5);
  }
  g.restore();
}

// fondo propio: cubierta de paseo de un transatlántico de noche
function cubierta(g, w, h) {
  cielo(g, w, h, false);
  g.fillStyle = '#1B2C4A';
  g.fillRect(0, 1000, w, 200);
  // bote salvavidas colgado de sus pescantes
  g.strokeStyle = TINTA;
  g.lineWidth = 12;
  g.beginPath();
  g.moveTo(140, 1180);
  g.quadraticCurveTo(140, 560, 300, 560);
  g.moveTo(860, 1180);
  g.quadraticCurveTo(860, 560, 700, 560);
  g.stroke();
  g.beginPath();
  g.moveTo(220, 700);
  g.quadraticCurveTo(500, 820, 780, 700);
  g.lineTo(740, 640);
  g.lineTo(260, 640);
  g.closePath();
  pinta(g, '#F2EFE9', TINTA, 7);
  g.fillStyle = '#8C5A34';
  g.fillRect(270, 640, 460, 18);
  // chimenea al fondo
  g.beginPath();
  g.moveTo(820, 0);
  g.lineTo(840, 520);
  g.lineTo(1080, 520);
  g.lineTo(1080, 0);
  g.closePath();
  pinta(g, '#D9A441', TINTA, 7);
  g.fillStyle = '#16171C';
  g.fillRect(835, 0, 245, 90);
  // piso de madera y barandal
  const pis = g.createLinearGradient(0, 1180, 0, h);
  pis.addColorStop(0, '#6B4A2E');
  pis.addColorStop(1, '#3A2818');
  g.fillStyle = pis;
  g.fillRect(0, 1180, w, h - 1180);
  g.strokeStyle = 'rgba(0,0,0,0.3)';
  g.lineWidth = 3;
  for (let i = -8; i < 16; i++) {
    g.beginPath();
    g.moveTo(540 + i * 90, 1180);
    g.lineTo(540 + i * 260, h);
    g.stroke();
  }
  g.fillStyle = '#E9E4DB';
  g.fillRect(0, 1050, w, 16);
  for (let x = 20; x < w; x += 70) g.fillRect(x, 1050, 10, 130);
  // farol
  const luz = g.createRadialGradient(540, 470, 10, 540, 470, 420);
  luz.addColorStop(0, 'rgba(255,214,140,0.55)');
  luz.addColorStop(1, 'rgba(255,214,140,0)');
  g.fillStyle = luz;
  g.fillRect(0, 0, w, h);
  g.beginPath();
  g.arc(540, 470, 26, 0, 7);
  pinta(g, '#FFE3A3', TINTA, 5);
}

const frases = [
  'Violet Jessop subió a tres barcos gemelos… y los tres sufrieron un desastre.',
  '20 de septiembre de 1911: el Olympic choca con el crucero Hawke. Ella sale ilesa.',
  'En abril de 1912 la mandan al Titanic. Esa noche baja en un bote salvavidas.',
  'Cuatro años después, en el Britannic, una mina abre el casco. Salta al agua y se golpea la cabeza.',
  'Sobrevivió a los tres. La apodaron Miss Insumergible.',
];

const enCubierta = (cam, actua) => (g, t, tl, p) => {
  const fondo = capaFija('cubierta', 1080, 1920, cubierta);
  conCamara(g, cam(p), 0.5, (c) => c.drawImage(fondo, 0, 0, 1080, 1920));
  conCamara(g, cam(p), 1, (c) => actua(c, t, tl, p));
};
const empuje = (x, y, z, k = 0.1) => (p) => ({x, y, z: z * (1 + k * salida(p))});
const escenaMar = (dia, cam, actua) => (g, t, tl, p) => conCamara(g, cam(p), 1, (c) => {
  cielo(c, 1080, 1920, dia);
  mar(c, 1080, 1920, t, dia);
  actua(c, t, tl, p);
});

const barcoIcono = (g, x, y) => {
  g.save();
  g.translate(x, y);
  g.scale(0.17, 0.17);
  barco(g, 0, 0, 1, {});
  g.restore();
};

const tomas = [
  {t: 0, ficha: ['Violet Jessop', 'azafata · nació en 1887'], dibujar: enCubierta(empuje(540, 1240, 1.3), (c, t) => {
    pj(c, 540, 1560, 640, {...VIOLET, expresion: 'serio', pose: 'parado', mira: 0}, t);
  })},
  {desde: 'tres', dibujar: escenaMar(false, (p) => ({x: 540, y: 1050, z: 1.05 + 0.08 * p}), (c, t, tl) => {
    [0, 1, 2].forEach((i) => {
      const a = Math.min(1, resorte(tl - i * 0.25, 1));
      if (a > 0) barco(c, 540, 820 + i * 260, 0.62 * a, {luces: true, t, humo: true});
    });
  })},
  {desde: 'desastre', sello: '3 DESASTRES', dibujar: escenaMar(false, (p) => ({x: 540, y: 1050, z: 1.15}), (c, t, tl) => {
    [0, 1, 2].forEach((i) => barco(c, 540, 820 + i * 260, 0.62, {luces: true, inclina: tramo(tl, 0, 1) * (i - 1) * 0.08}));
  }), luz: 'peligro'},
  {desde: '20', dibujar: (g, t, tl) => calendario(g, {mes: 'SEPTIEMBRE 1911', desde: 19, numero: 20, texto: 'OLYMPIC'}, tl, '#121318')},
  {desde: 'olympic', ficha: ['Olympic vs. HMS Hawke', '20 de septiembre de 1911'], dibujar: escenaMar(true, (p) => ({x: 560, y: 1080, z: 1.25 + 0.1 * p}), (c, t, tl) => {
    barco(c, 430, 1080, 0.9, {humo: true, t});
    const x = 1000 - 380 * salida(tl / 1.2);
    crucero(c, x, 1150, 0.75, t);
    if (tl > 1.1) {
      for (let k = 0; k < 10; k++) {
        c.beginPath();
        c.arc(640 + Math.cos(k) * (tl - 1.1) * 220, 1110 + Math.sin(k * 2) * (tl - 1.1) * 160, 14, 0, 7);
        c.fillStyle = '#F2EFE9';
        c.fill();
      }
    }
  })},
  {desde: 'ella', sello: 'ILESA', colorSello: '#4C9F70', dibujar: enCubierta(empuje(540, 1020, 2.4), (c, t) => {
    pj(c, 540, 1560, 640, {...VIOLET, expresion: 'aburrido', pose: 'brazos_cruzados', mira: 0}, t);
  })},
  {desde: 'abril', dibujar: (g, t, tl) => calendario(g, {mes: 'ABRIL 1912', desde: 10, numero: 14, texto: 'TITANIC'}, tl, '#121318')},
  {desde: 'titanic', ficha: ['RMS Titanic', '14 de abril de 1912'], dibujar: escenaMar(false, (p) => ({x: 540, y: 1080, z: 1.1 + 0.12 * p}), (c, t, tl) => {
    barco(c, 420, 1060, 0.9, {luces: true, inclina: -0.04 - tramo(tl, 0, 3) * 0.12});
    c.beginPath();
    c.moveTo(860, 1170);
    c.lineTo(930, 900);
    c.lineTo(990, 980);
    c.lineTo(1060, 1170);
    c.closePath();
    pinta(c, '#DDEAF2', TINTA, 6);
  }), luz: 'noche'},
  {desde: 'bote', dibujar: escenaMar(false, (p) => ({x: 540, y: 1250, z: 1.6 + 0.1 * p}), (c, t, tl) => {
    barco(c, 240, 1000, 0.45, {luces: true, inclina: -0.2});
    const y = 1290 + Math.sin(t * 2) * 10;
    pj(c, 600, y, 420, {...VIOLET, expresion: 'asustado', pose: 'parado', mira: -1}, t);
    c.beginPath();
    c.moveTo(380, y - 120);
    c.lineTo(820, y - 120);
    c.lineTo(770, y + 20);
    c.lineTo(430, y + 20);
    c.closePath();
    pinta(c, '#F2EFE9', TINTA, 7);
  }), luz: 'noche'},
  {desde: 'cuatro', dibujar: (g, t, tl) => mapa(g, {
    tierras: [[[60, 300], [380, 260], [420, 520], [260, 640], [90, 560]], [[430, 700], [690, 640], [700, 900], [520, 1000], [440, 860]], [[150, 980], [380, 940], [420, 1150], [160, 1200]]],
    puntos: [{x: 240, y: 560, nombre: 'Southampton'}, {x: 560, y: 1080, nombre: 'Mar Egeo · 1916'}]}, tl),
    ficha: ['HMHS Britannic', 'barco hospital · 21 nov 1916']},
  {desde: 'mina', dibujar: escenaMar(true, (p) => ({x: 540, y: 1100, z: 1.3 + 0.1 * p}), (c, t, tl) => {
    barco(c, 520, 1080, 0.9, {tipo: 'hospital', inclina: tramo(tl, 0.3, 2) * 0.1});
    if (tl > 0.15) {
      const k = Math.min(1, (tl - 0.15) / 0.5);
      const gr = c.createRadialGradient(640, 1120, 10, 640, 1120, 420 * k);
      gr.addColorStop(0, 'rgba(255,240,180,0.95)');
      gr.addColorStop(0.5, 'rgba(255,130,40,0.8)');
      gr.addColorStop(1, 'rgba(255,90,30,0)');
      c.fillStyle = gr;
      c.beginPath();
      c.arc(640, 1120, 420 * k, 0, 7);
      c.fill();
    }
  }), luz: 'peligro'},
  {desde: 'salta', dibujar: escenaMar(true, (p) => ({x: 540, y: 1150, z: 1.7}), (c, t, tl) => {
    const y = 900 + 900 * Math.pow(Math.min(1, tl / 0.9), 2);
    if (y < 1300) pj(c, 540, y, 460, {...VIOLET, expresion: 'asustado', pose: 'saluda', mira: 0}, t);
    else {
      for (let k = 0; k < 14; k++) {
        const a = -Math.PI * (k / 13);
        c.beginPath();
        c.arc(540 + Math.cos(a) * 160 * Math.min(1, tl - 0.9), 1290 + Math.sin(a) * 200 * Math.min(1, tl - 0.9), 20, 0, 7);
        c.fillStyle = '#E8F4FF';
        c.fill();
      }
    }
  })},
  {desde: 'golpea', dibujar: escenaMar(true, (p) => ({x: 540, y: 1150, z: 2.6}), (c, t, tl) => {
    pj(c, 540, 1500, 600, {...VIOLET, expresion: 'triste', pose: 'piensa', mira: 0}, t);
    c.fillStyle = 'rgba(36,71,106,0.85)';
    c.fillRect(0, 1330, 1080, 600);
  })},
  {desde: 'sobrevivió', dibujar: (g, t, tl) => contador(g, {desde: 0, hasta: 3, dur: 1.2, etiqueta: 'desastres sobrevividos', tam: 260, iconos: 3,
    icono: (c, x, y, tt, i) => barcoIcono(c, 180 + i * 180, 900)}, tl, '#121318')},
  {desde: 'apodaron', ficha: ['«Miss Insumergible»', 'murió en 1971, a los 83 años'], dibujar: enCubierta(empuje(540, 1150, 1.6), (c, t) => {
    pj(c, 540, 1560, 640, {...VIOLET, expresion: 'feliz', pose: 'manos_cadera', mira: 0}, t);
  }), luz: 'dorada'},
];

export default armar({duracion: 30, frases, tomas, subtitulos: {resalte: '#F0B44C'}});
