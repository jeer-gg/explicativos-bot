// Partes 3D dentro del video de lienzo: piezas con volumen, sombreado de caricatura (3 tonos),
// contorno y sombra en el suelo, con una cámara que gira alrededor. Para lo que gana con volumen:
// máquinas, motores, engranajes, aparatos que se abren, edificios, planetas, moléculas, cortes.
// Se dibuja dentro del cuadro actual (respeta la cámara 2D), así se mezcla con el resto del video.

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a) => {
  const l = Math.hypot(a[0], a[1], a[2]) || 1;
  return [a[0] / l, a[1] / l, a[2] / l];
};
const hex = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const rgb = (c, k, a = 1) => `rgba(${Math.min(255, c[0] * k) | 0},${Math.min(255, c[1] * k) | 0},${Math.min(255, c[2] * k) | 0},${a})`;
const LUZ = norm([-0.55, 0.85, 0.65]);

// ---------- geometrías (unidades libres; y hacia arriba) ----------
export function caja(w, h, d) {
  const x = w / 2, y = h / 2, z = d / 2;
  return {v: [[-x, -y, -z], [x, -y, -z], [x, y, -z], [-x, y, -z], [-x, -y, z], [x, -y, z], [x, y, z], [-x, y, z]],
    f: [[0, 1, 2, 3], [4, 5, 6, 7], [0, 4, 7, 3], [1, 5, 6, 2], [3, 2, 6, 7], [0, 1, 5, 4]]};
}
/** Sólido de revolución: perfil [[radio, y], ...] de abajo hacia arriba. */
export function torno(perfil, seg = 28, tapas = true) {
  const v = [], f = [];
  perfil.forEach(([r, y]) => {
    for (let i = 0; i < seg; i++) {
      const a = (i / seg) * Math.PI * 2;
      v.push([Math.cos(a) * r, y, Math.sin(a) * r]);
    }
  });
  for (let j = 0; j < perfil.length - 1; j++)
    for (let i = 0; i < seg; i++) {
      const a = j * seg + i, b = j * seg + ((i + 1) % seg);
      f.push([a, b, b + seg, a + seg]);
    }
  if (tapas) {
    const top = perfil.length - 1;
    f.push([...Array(seg).keys()].map((i) => top * seg + i));
    f.push([...Array(seg).keys()].map((i) => i));
  }
  return {v, f};
}
export const cilindro = (r, h, seg = 28) => torno([[r, -h / 2], [r, h / 2]], seg);
export const cono = (r1, r2, h, seg = 28) => torno([[r1, -h / 2], [r2, h / 2]], seg);
export function esfera(r, la = 12, lo = 20) {
  const p = [];
  for (let i = 0; i <= la; i++) {
    const a = -Math.PI / 2 + (i / la) * Math.PI;
    p.push([Math.max(0.0001, Math.cos(a) * r), Math.sin(a) * r]);
  }
  return torno(p, lo);
}
export function engranaje(dientes, R, grosor) {
  const pts = [], ri = R * 0.8, paso = (Math.PI * 2) / dientes;
  for (let i = 0; i < dientes; i++) {
    const a = i * paso;
    for (const [r, k] of [[ri, 0], [R, 0.15], [R, 0.45], [ri, 0.6]]) pts.push([Math.cos(a + paso * k) * r, Math.sin(a + paso * k) * r]);
  }
  const n = pts.length, z = grosor / 2, v = [];
  pts.forEach(([x, y]) => v.push([x, y, z]));
  pts.forEach(([x, y]) => v.push([x, y, -z]));
  const f = [[...Array(n).keys()], [...Array(n).keys()].map((i) => n + (n - 1 - i))];
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    f.push([i, j, n + j, n + i]);
  }
  return {v, f};
}
/** Tubo recto entre dos puntos (cables, ejes, tuberías, enlaces de moléculas). */
export function tubo(desde, hasta, r = 0.05, seg = 12) {
  const d = sub(hasta, desde), largo = Math.hypot(d[0], d[1], d[2]) || 1e-6;
  const g = cilindro(r, largo, seg);
  const y = norm(d);
  const x = norm(Math.abs(y[1]) < 0.95 ? cross(y, [0, 1, 0]) : cross(y, [1, 0, 0]));
  const z = cross(x, y);
  const m = [(desde[0] + hasta[0]) / 2, (desde[1] + hasta[1]) / 2, (desde[2] + hasta[2]) / 2];
  g.v = g.v.map(([a, b, c]) => [m[0] + x[0] * a + y[0] * b + z[0] * c, m[1] + x[1] * a + y[1] * b + z[1] * c, m[2] + x[2] * a + y[2] * b + z[2] * c]);
  return g;
}

// ---------- transformaciones ----------
function rotar(p, rot) {
  let [x, y, z] = p;
  const [rx, ry, rz] = rot;
  let t;
  t = y * Math.cos(rx) - z * Math.sin(rx); z = y * Math.sin(rx) + z * Math.cos(rx); y = t;
  t = x * Math.cos(ry) + z * Math.sin(ry); z = -x * Math.sin(ry) + z * Math.cos(ry); x = t;
  t = x * Math.cos(rz) - y * Math.sin(rz); y = x * Math.sin(rz) + y * Math.cos(rz); x = t;
  return [x, y, z];
}
function transformar(p, cadena) {
  let q = p;
  for (const o of cadena) {
    const e = typeof o.esc === 'number' ? [o.esc, o.esc, o.esc] : o.esc || [1, 1, 1];
    q = rotar([q[0] * e[0], q[1] * e[1], q[2] * e[2]], o.rot || [0, 0, 0]);
    const pos = o.pos || [0, 0, 0];
    q = [q[0] + pos[0], q[1] + pos[1], q[2] + pos[2]];
  }
  return q;
}
function aplanar(piezas, cadena = [], salida = []) {
  for (const p of piezas || []) {
    if (!p || p.visible === false) continue;
    const c = [p, ...cadena];
    if (p.hijos) aplanar(p.hijos, c, salida);
    if (p.geo) salida.push({p, cadena: c});
  }
  return salida;
}

/**
 * Dibuja piezas 3D en el cuadro actual.
 * o = {x, y: centro en pantalla/mundo, escala: px por unidad (≈ 220 a 320), contorno: '#color',
 *      camara: {giro (radianes alrededor del eje vertical), alto (radianes hacia arriba, 0,2 a 0,6),
 *               dist (5 a 9), mira: [x, y, z]}, suelo: '#color' | null, sombras: true}
 * piezas = [{geo, color, pos, rot, esc, brillo (0..1), alfa, sombra (radio en el suelo), borde (true)},
 *           {pos, rot, esc, hijos: [...]}]   (los grupos mueven a sus hijos juntos)
 */
export function escena3d(g, o, piezas) {
  const cam = o.camara || {};
  const giro = cam.giro ?? 0.6, alto = cam.alto ?? 0.35, dist = cam.dist ?? 7;
  const mira = cam.mira || [0, 0.8, 0];
  const CP = [mira[0] + Math.sin(giro) * Math.cos(alto) * dist, mira[1] + Math.sin(alto) * dist, mira[2] + Math.cos(giro) * Math.cos(alto) * dist];
  const FW = norm(sub(mira, CP)), CR = norm(cross(FW, [0, 1, 0])), CU = cross(CR, FW);
  const F = (o.escala ?? 260) * dist;
  const cx = o.x ?? 540, cy = o.y ?? 960;
  const proy = (p) => {
    const d = sub(p, CP);
    const z = dot(d, FW);
    return [cx + (dot(d, CR) / z) * F, cy - (dot(d, CU) / z) * F, z];
  };
  const poli = (pts, fill, stroke, lw) => {
    g.beginPath();
    pts.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])));
    g.closePath();
    if (fill) {
      g.fillStyle = fill;
      g.fill();
    }
    if (stroke) {
      g.strokeStyle = stroke;
      g.lineWidth = lw;
      g.lineJoin = 'round';
      g.stroke();
    }
  };
  const contorno = o.contorno || '#1B1B1F';
  // suelo y sombras
  if (o.suelo) {
    const t = o.tamSuelo ?? 6;
    poli([[-t, 0, -t], [t, 0, -t], [t, 0, t], [-t, 0, t]].map((p) => proy([p[0] + mira[0], 0, p[2] + mira[2]])), o.suelo);
  }
  const lista = aplanar(piezas);
  if (o.sombras !== false) {
    for (const {p, cadena} of lista) {
      if (!p.sombra) continue;
      const c = transformar([0, 0, 0], cadena);
      for (let k = 0; k < 5; k++) {
        const r = p.sombra * (1 - k * 0.15);
        const pts = [];
        for (let i = 0; i < 28; i++) {
          const a = (i / 28) * Math.PI * 2;
          pts.push(proy([c[0] + Math.cos(a) * r, 0.003, c[2] + Math.sin(a) * r * 0.8]));
        }
        poli(pts, `rgba(20,14,10,${0.06 + k * 0.016})`);
      }
    }
  }
  // caras: sombreado de caricatura + contorno por casco invertido
  const capas = [];
  for (const {p, cadena} of lista) {
    const geo = p.geo;
    const V = geo.v.map((v) => transformar(v, cadena));
    const centro = V.reduce((a, v) => [a[0] + v[0] / V.length, a[1] + v[1] / V.length, a[2] + v[2] / V.length], [0, 0, 0]);
    const tam = Math.max(...V.map((v) => Math.hypot(v[0] - centro[0], v[1] - centro[1], v[2] - centro[2]))) || 1;
    const borde = p.borde === false ? 0 : (p.grosorBorde ?? 0.03);
    const factor = 1 + borde / Math.max(0.05, tam);
    const color = hex(p.color || '#CCCCCC');
    const b = p.brillo || 0;
    const col = [color[0] + (255 - color[0]) * b, color[1] + (255 - color[1]) * b * 0.7, color[2] + (255 - color[2]) * b * 0.3];
    for (const f of geo.f) {
      const P = f.map((i) => V[i]);
      const cen = P.reduce((a, q) => [a[0] + q[0] / P.length, a[1] + q[1] / P.length, a[2] + q[2] / P.length], [0, 0, 0]);
      let n = norm(cross(sub(P[1], P[0]), sub(P[2], P[0])));
      if (Number.isNaN(n[0])) n = norm(cross(sub(P[2], P[0]), sub(P[3] || P[1], P[0])));
      if (dot(n, sub(cen, centro)) < 0) n = n.map((x) => -x);
      const pr = P.map(proy);
      if (pr.some((q) => q[2] < 0.1)) continue;
      const z = pr.reduce((a, q) => a + q[2], 0) / pr.length;
      if (dot(n, sub(CP, cen)) > 0) {
        const l = dot(n, LUZ);
        const k = l > 0.5 ? 1.0 : l > 0.1 ? 0.86 : 0.7;
        capas.push({z, f: () => poli(pr, rgb(col, k, p.alfa ?? 1), rgb(col, k, p.alfa ?? 1), 1.2)});
      } else if (borde > 0) {
        const C = f.map((i) => proy(centro.map((c0, j) => c0 + (V[i][j] - c0) * factor)));
        capas.push({z: z + 0.002, f: () => poli(C, contorno, contorno, 1)});
      }
    }
  }
  capas.sort((a, b) => b.z - a.z);
  for (const c of capas) c.f();
  return {proy};
}
