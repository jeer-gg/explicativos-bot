// Motor de prueba: imita el video que arma el bot (montaje por tomas, personajes con cara,
// fondos del tema en capas, insertos, fichas, sellos, luz por toma y subtítulos) en canvas 2D.
import {personaje} from './personajes2d.js';

export const W = 720, H = 1280;
export const FUENTE = '"Inter Display", "Inter", "DejaVu Sans", sans-serif';

// ---------- utilidades ----------
export const suave = (p) => (p <= 0 ? 0 : p >= 1 ? 1 : p * p * (3 - 2 * p));
export const tramo = (t, a, b) => suave((t - a) / (b - a));
export const salida = (p) => 1 - Math.pow(1 - Math.max(0, Math.min(1, p)), 3);
export const resorte = (t, k = 1) => {
  if (t <= 0) return 0;
  return 1 - Math.exp(-7 * t * k) * Math.cos(13 * t * k);
};
export const azar = (s) => () => ((s = (s * 16807) % 2147483647) / 2147483647);
export function mezclarHex(a, b, k) {
  const p = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const x = p(a), y = p(b);
  return '#' + x.map((v, i) => Math.round(v + (y[i] - v) * k).toString(16).padStart(2, '0')).join('');
}

export function pinta(g, color, contorno, lw = 5) {
  g.fillStyle = color;
  g.fill();
  if (contorno && lw > 0) {
    g.lineWidth = lw;
    g.strokeStyle = contorno;
    g.lineJoin = 'round';
    g.lineCap = 'round';
    g.stroke();
  }
}
export function rr(g, x, y, w, h, r) {
  g.beginPath();
  g.roundRect(x, y, w, h, r);
}
export function sombra(g, x, y, rx, ry = rx * 0.22, a = 0.28) {
  const gr = g.createRadialGradient(x, y, 0, x, y, rx);
  gr.addColorStop(0, `rgba(0,0,0,${a})`);
  gr.addColorStop(1, 'rgba(0,0,0,0)');
  g.save();
  g.translate(x, y);
  g.scale(1, ry / rx);
  g.fillStyle = gr;
  g.beginPath();
  g.arc(0, 0, rx, 0, Math.PI * 2);
  g.fill();
  g.restore();
}

// ---------- personajes (los del bot) ----------
const lienzoPj = document.createElement('canvas');
lienzoPj.width = 558;
lienzoPj.height = 900;
export function pj(g, x, ySuelo, alto, rasgos, t, contorno = '#1B1B1F', espejo = false) {
  const c = lienzoPj.getContext('2d');
  c.clearRect(0, 0, 558, 900);
  personaje(c, 558, 900, {t, c: {piel: rasgos.piel || '#E8B68E', ropa: '#2F4F9E', contorno}, contorno: true, ...rasgos});
  const ancho = alto * 0.62;
  sombra(g, x, ySuelo, ancho * 0.55);
  g.save();
  g.translate(x, ySuelo - alto);
  if (espejo) {
    g.scale(-1, 1);
    g.drawImage(lienzoPj, -ancho / 2, 0, ancho, alto);
  } else g.drawImage(lienzoPj, -ancho / 2, 0, ancho, alto);
  g.restore();
}

// ---------- capas de fondo (con parallax) ----------
const cacheFondo = new Map();
export function capaFija(clave, ancho, alto, dibujar) {
  // Se pinta al doble de resolución para que siga nítido en los primeros planos.
  // Dibújalo con c.drawImage(fondo, 0, 0, ancho, alto).
  if (!cacheFondo.has(clave)) {
    const c = document.createElement('canvas');
    c.width = ancho * 2;
    c.height = alto * 2;
    const g = c.getContext('2d');
    g.scale(2, 2);
    dibujar(g, ancho, alto);
    cacheFondo.set(clave, c);
  }
  return cacheFondo.get(clave);
}

// La cámara: foco (x, y) en el mundo (1080 x 1920) y zoom; las capas lejanas se mueven menos
export function conCamara(g, cam, factor, fn) {
  g.save();
  const z = 1 + (cam.z - 1) * factor;
  const fx = 540 + (cam.x - 540) * factor, fy = 960 + (cam.y - 960) * factor;
  g.translate(W / 2, H / 2);
  g.scale((z * W) / 1080, (z * W) / 1080);
  g.translate(-fx, -fy);
  fn(g);
  g.restore();
}

// ---------- subtítulos (palabra actual resaltada) ----------
export function tiemposVoz(frases, total) {
  const palabras = [];
  let t = 0.15;
  frases.forEach((f, k) => {
    f.split(' ').forEach((w) => {
      const dur = 0.2 + w.length * 0.035;
      palabras.push({w, t, d: dur, frase: k});
      t += dur + (/[.!?…]$/.test(w) ? 0.42 : /[,:;]$/.test(w) ? 0.2 : 0.04);
    });
  });
  const k = (total - 0.6) / t;
  palabras.forEach((p) => {
    p.t *= k;
    p.d *= k;
  });
  return palabras;
}

export function subtitulos(g, palabras, t, estilo) {
  const actual = palabras.filter((p) => p.t <= t + 0.02).pop();
  if (!actual) return;
  const frase = palabras.filter((p) => p.frase === actual.frase);
  const i = frase.indexOf(actual);
  const ini = Math.floor(i / 6) * 6;
  const ventana = frase.slice(ini, ini + 6);
  g.save();
  // franja oscura suave detrás del texto para que se lea sobre cualquier fondo
  const banda = g.createLinearGradient(0, 120, 0, 360);
  banda.addColorStop(0, 'rgba(0,0,0,0)');
  banda.addColorStop(0.35, 'rgba(0,0,0,0.28)');
  banda.addColorStop(0.7, 'rgba(0,0,0,0.28)');
  banda.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = banda;
  g.fillRect(0, 120, W, 240);
  const ESP = 22;
  g.font = `800 42px ${FUENTE}`;
  g.textBaseline = 'middle';
  g.textAlign = 'center';
  const lineas = [[]];
  let ancho = 0;
  ventana.forEach((p) => {
    const w = g.measureText(p.w).width;
    if (ancho + w > 600 && lineas[lineas.length - 1].length) {
      lineas.push([]);
      ancho = 0;
    }
    lineas[lineas.length - 1].push({...p, ancho: w});
    ancho += w + ESP;
  });
  lineas.forEach((l, k) => {
    const total = l.reduce((s, p) => s + p.ancho, 0) + ESP * (l.length - 1);
    let x = W / 2 - total / 2;
    const y = 205 + k * 58;
    l.forEach((p) => {
      const dicha = p.t <= t + 0.02;
      const esta = p.t === actual.t;
      const pop = esta ? 1 + 0.12 * Math.max(0, 1 - (t - p.t) / 0.15) : 1;
      g.save();
      g.translate(x + p.ancho / 2, y);
      g.scale(pop, pop);
      g.lineWidth = 7;
      g.strokeStyle = 'rgba(0,0,0,0.8)';
      g.lineJoin = 'round';
      g.strokeText(p.w, 0, 0);
      g.fillStyle = esta ? (estilo?.resalte || '#FFD23F') : dicha ? '#FFFFFF' : 'rgba(255,255,255,0.5)';
      g.fillText(p.w, 0, 0);
      g.restore();
      x += p.ancho + ESP;
    });
  });
  g.restore();
}

// ---------- capas del montaje ----------
export function luz(g, tipo) {
  const capas = {
    calida: [['soft-light', '#FF9F43', 0.35]],
    fria: [['soft-light', '#4A7BD0', 0.4]],
    noche: [['multiply', '#14204A', 0.45], ['vin', 'rgba(0,0,10,0.55)']],
    peligro: [['soft-light', '#C0392B', 0.45], ['vin', 'rgba(60,0,0,0.6)']],
    dorada: [['soft-light', '#FFC857', 0.4]],
    misterio: [['vin', 'rgba(0,0,0,0.7)']],
  }[tipo];
  if (!capas) return;
  capas.forEach(([modo, color, a]) => {
    g.save();
    if (modo === 'vin') {
      const v = g.createRadialGradient(W / 2, H * 0.45, W * 0.25, W / 2, H * 0.45, W * 0.95);
      v.addColorStop(0, 'rgba(0,0,0,0)');
      v.addColorStop(1, color);
      g.fillStyle = v;
    } else {
      g.globalCompositeOperation = modo;
      g.globalAlpha = a;
      g.fillStyle = color;
    }
    g.fillRect(0, 0, W, H);
    g.restore();
  });
}

export function ficha(g, titulo, sub, tl) {
  const e = resorte(tl - 0.08, 1.2);
  if (e <= 0) return;
  g.save();
  g.translate((1 - e) * -480, 0);
  g.font = `900 34px ${FUENTE}`;
  const w = Math.max(g.measureText(titulo).width, (g.font = `700 22px ${FUENTE}`, g.measureText(sub || '').width)) + 48;
  rr(g, 56, 352, w + 10, sub ? 92 : 62, 10);
  g.fillStyle = 'rgba(20,20,24,0.93)';
  g.fill();
  g.fillStyle = '#E23B3B';
  g.fillRect(56, 352, 7, sub ? 92 : 62);
  g.fillStyle = '#FFFFFF';
  g.font = `900 34px ${FUENTE}`;
  g.textBaseline = 'top';
  g.fillText(titulo, 82, 364);
  if (sub) {
    g.fillStyle = 'rgba(255,255,255,0.75)';
    g.font = `700 22px ${FUENTE}`;
    g.fillText(sub, 82, 406);
  }
  g.restore();
}

export function sello(g, texto, tl, color = '#D7263D') {
  const f = tl - 0.25;
  if (f < 0) return;
  const e = f < 0.17 ? 2.4 - (1.4 * f) / 0.17 : 1;
  const tiembla = f > 0.14 && f < 0.35 ? Math.sin(f * 90) * 4 : 0;
  g.save();
  g.translate(W / 2 + tiembla, 600);
  g.rotate(-0.21);
  g.scale(e, e);
  g.globalAlpha = Math.min(1, f / 0.06);
  g.font = `900 78px ${FUENTE}`;
  const w = g.measureText(texto).width + 50;
  rr(g, -w / 2, -54, w, 108, 14);
  g.lineWidth = 10;
  g.strokeStyle = color;
  g.stroke();
  g.fillStyle = color;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillText(texto, 0, 4);
  g.restore();
}

// ---------- insertos ----------
function mesa(g, base, tl) {
  const claro = mezclarHex(base, '#FFFFFF', 0.18), osc = mezclarHex(base, '#000000', 0.45);
  const gr = g.createRadialGradient(W / 2, H * 0.45, 40, W / 2, H * 0.45, W * 1.1);
  gr.addColorStop(0, claro);
  gr.addColorStop(0.55, base);
  gr.addColorStop(1, osc);
  g.fillStyle = gr;
  g.fillRect(0, 0, W, H);
  g.save();
  g.globalAlpha = 0.07;
  g.strokeStyle = '#FFFFFF';
  g.lineWidth = 2;
  for (let i = -H; i < W + H; i += 22) {
    g.beginPath();
    g.moveTo(i, 0);
    g.lineTo(i - H * 0.45, H);
    g.stroke();
  }
  g.restore();
  const z = 1 + 0.06 * Math.min(1, tl / 3);
  g.translate(W / 2, H * 0.48);
  g.scale(z, z);
  g.translate(-W / 2, -H * 0.48);
}

function texto(g, s, x, y, tam, peso = 800, color = '#2B2420', alinear = 'left', anchoMax = 0) {
  g.font = `${peso} ${tam}px ${FUENTE}`;
  // si no cabe, se achica (nunca se corta el texto)
  if (anchoMax > 0) {
    const w = g.measureText(s).width;
    if (w > anchoMax) g.font = `${peso} ${Math.floor((tam * anchoMax) / w)}px ${FUENTE}`;
  }
  g.fillStyle = color;
  g.textAlign = alinear;
  g.textBaseline = 'top';
  g.fillText(s, x, y);
}

export function documento(g, d, tl, base) {
  g.save();
  mesa(g, base, tl);
  const e = resorte(tl, 0.9);
  g.translate(W / 2, 650 + (1 - Math.min(1, e)) * 600);
  g.rotate(((-12 + 9.5 * Math.min(1, e)) * Math.PI) / 180);
  const papel = d.tipo === 'nota' ? '#FFE98A' : d.tipo === 'cuenta' ? '#FFFDF6' : '#FBF7EE';
  g.shadowColor = 'rgba(0,0,0,0.45)';
  g.shadowBlur = 50;
  g.shadowOffsetY = 24;
  rr(g, -255, -300, 510, 600, d.tipo === 'nota' ? 4 : 10);
  g.fillStyle = papel;
  g.fill();
  g.shadowColor = 'transparent';
  let y = -255;
  if (d.encabezado) {
    texto(g, d.encabezado, 0, y, 22, 800, '#7A6A5C', 'center');
    y += 44;
  }
  if (d.titulo) {
    const lineasT = d.titulo.split('\n');
    lineasT.forEach((l) => {
      texto(g, l, 0, y, 46, 900, '#2B2420', 'center', 450);
      y += 54;
    });
    y += 16;
  }
  (d.lineas || []).forEach((l, i) => {
    const desde = 0.35 + i * 0.32;
    const n = Math.floor(l.length * Math.max(0, Math.min(1, (tl - desde) / (0.03 * l.length + 0.15))));
    texto(g, l.slice(0, n), -215, y, 30, 700, '#2B2420', 'left', 430);
    if (d.tipo === 'carta' || d.tipo === 'cuenta') {
      g.fillStyle = 'rgba(0,0,0,0.08)';
      g.fillRect(-215, y + 42, 430, 2);
    }
    y += 54;
  });
  if (d.firma && tl > 1.2) texto(g, '— ' + d.firma, 215, y + 20, 26, 700, '#5A4A3C', 'right');
  g.restore();
}

export function pantalla(g, d, tl, base, acento = '#1E8E5A') {
  g.save();
  mesa(g, base, tl);
  const e = resorte(tl, 0.8);
  g.translate(W / 2, 640 + (1 - Math.min(1, e)) * 700);
  g.rotate(((6 - 7.5 * Math.min(1, e)) * Math.PI) / 180);
  g.shadowColor = 'rgba(0,0,0,0.5)';
  g.shadowBlur = 60;
  g.shadowOffsetY = 30;
  rr(g, -220, -420, 440, 840, 58);
  g.fillStyle = '#111';
  g.fill();
  g.shadowColor = 'transparent';
  rr(g, -205, -405, 410, 810, 46);
  g.fillStyle = '#F2F3F6';
  g.fill();
  g.save();
  g.clip();
  g.fillStyle = acento;
  g.fillRect(-205, -405, 410, 120);
  texto(g, d.titulo || 'Mensajes', -170, -340, 30, 900, '#FFFFFF');
  rr(g, -55, -396, 110, 26, 13);
  g.fillStyle = '#111';
  g.fill();
  let y = -250;
  (d.lineas || []).forEach((l, i) => {
    const a = resorte(tl - 0.25 - i * 0.45, 1.2);
    if (a <= 0) return;
    const mio = d.mios ? d.mios[i] : i % 2 === 1;
    g.font = `700 25px ${FUENTE}`;
    const w = Math.min(300, g.measureText(l).width + 40);
    g.save();
    g.translate(mio ? 185 - w : -185, y);
    g.scale(a, a);
    rr(g, 0, 0, w, 60, 26);
    g.fillStyle = mio ? acento : '#FFFFFF';
    g.fill();
    texto(g, l, 20, 16, 25, 700, mio ? '#FFFFFF' : '#111');
    g.restore();
    y += 80;
  });
  if (d.escribiendo && tl > 0.6) {
    rr(g, -185, y, 110, 54, 26);
    g.fillStyle = '#FFFFFF';
    g.fill();
    for (let k = 0; k < 3; k++) {
      g.beginPath();
      g.arc(-155 + k * 24, y + 27 + Math.sin(tl * 9 - k) * 4, 7, 0, 7);
      g.fillStyle = '#999';
      g.fill();
    }
  }
  g.restore();
  g.restore();
}

export function mapa(g, d, tl) {
  g.save();
  const gr = g.createRadialGradient(W / 2, H * 0.45, 30, W / 2, H * 0.45, W * 1.1);
  gr.addColorStop(0, '#3E8DBD');
  gr.addColorStop(1, '#0C3352');
  g.fillStyle = gr;
  g.fillRect(0, 0, W, H);
  const z = 1.25 - 0.25 * salida(tl / 1.2);
  g.translate(W / 2, H / 2);
  g.scale(z, z);
  g.translate(-W / 2, -H / 2);
  (d.tierras || []).forEach((poli) => {
    // costa suave: curvas por los puntos medios
    g.beginPath();
    const n = poli.length;
    const medio = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    let m0 = medio(poli[n - 1], poli[0]);
    g.moveTo(m0[0], m0[1]);
    poli.forEach((pt, i) => {
      const m = medio(pt, poli[(i + 1) % n]);
      g.quadraticCurveTo(pt[0], pt[1], m[0], m[1]);
    });
    g.closePath();
    g.save();
    g.translate(0, 6);
    g.fillStyle = '#5E8F4C';
    g.fill();
    g.restore();
    pinta(g, '#86B86F', '#2E4A2A', 3);
  });
  const pts = d.puntos;
  const av = Math.max(0, Math.min(1, (tl - 0.3) / (0.7 * Math.max(1, pts.length - 1))));
  let largo = 0;
  const seg = pts.slice(1).map((p, i) => {
    const l = Math.hypot(p.x - pts[i].x, p.y - pts[i].y);
    largo += l;
    return l;
  });
  g.save();
  g.setLineDash([16, 12]);
  g.strokeStyle = '#FFFFFF';
  g.lineWidth = 6;
  g.lineCap = 'round';
  let resto = largo * av;
  g.beginPath();
  g.moveTo(pts[0].x, pts[0].y);
  seg.forEach((l, i) => {
    if (resto <= 0) return;
    const k = Math.min(1, resto / l);
    g.lineTo(pts[i].x + (pts[i + 1].x - pts[i].x) * k, pts[i].y + (pts[i + 1].y - pts[i].y) * k);
    resto -= l;
  });
  g.stroke();
  g.restore();
  let acum = 0;
  pts.forEach((p, i) => {
    if (i) acum += seg[i - 1];
    if (largo * av + 1 < acum) return;
    const pulso = 1 + 0.25 * Math.sin(tl * 6);
    g.beginPath();
    g.arc(p.x, p.y, 22 * pulso, 0, 7);
    g.fillStyle = 'rgba(226,59,59,0.3)';
    g.fill();
    g.beginPath();
    g.arc(p.x, p.y, 12, 0, 7);
    pinta(g, '#E23B3B', '#FFFFFF', 4);
    g.font = `900 26px ${FUENTE}`;
    const w = g.measureText(p.nombre).width + 30;
    const lx = Math.min(W - w - 20, p.x + 22);
    rr(g, lx, p.y - 52, w, 40, 8);
    g.fillStyle = '#1B1B1F';
    g.fill();
    g.fillStyle = '#E23B3B';
    g.fillRect(lx, p.y - 52, 5, 40);
    texto(g, p.nombre, lx + 16, p.y - 45, 26, 900, '#FFFFFF');
  });
  g.restore();
}

export function calendario(g, d, tl, base) {
  g.save();
  mesa(g, base, tl);
  const e = Math.min(1, resorte(tl, 0.9));
  g.translate(W / 2, 640);
  g.scale(0.7 + 0.3 * e, 0.7 + 0.3 * e);
  g.rotate(((1 - e) * -6 * Math.PI) / 180);
  g.shadowColor = 'rgba(0,0,0,0.45)';
  g.shadowBlur = 50;
  g.shadowOffsetY = 26;
  rr(g, -230, -290, 460, 580, 20);
  g.fillStyle = '#FBF7EE';
  g.fill();
  g.shadowColor = 'transparent';
  g.save();
  g.clip();
  g.fillStyle = '#C8382E';
  g.fillRect(-230, -290, 460, 110);
  texto(g, d.mes, 0, -262, 52, 900, '#FFFFFF', 'center', 420);
  const cambio = d.desde != null ? tramo(tl, 0.45, 0.8) : 1;
  if (d.desde != null && cambio < 1) {
    g.save();
    g.globalAlpha = 1 - cambio;
    g.translate(0, -cambio * 300);
    texto(g, String(d.desde), 0, -150, 230, 900, '#222', 'center');
    g.restore();
  }
  g.globalAlpha = cambio;
  texto(g, String(d.numero), 0, -150, 230, 900, '#222', 'center');
  g.globalAlpha = 1;
  if (d.texto) texto(g, d.texto, 0, 165, 46, 900, '#C8382E', 'center', 420);
  g.restore();
  if (d.tachar) {
    const k = tramo(tl, 1.0, 1.35);
    g.strokeStyle = '#C8382E';
    g.lineWidth = 22;
    g.lineCap = 'round';
    g.beginPath();
    g.moveTo(-150, -140);
    g.lineTo(-150 + 300 * Math.min(1, k * 2), -140 + 260 * Math.min(1, k * 2));
    if (k > 0.5) {
      g.moveTo(150, -140);
      g.lineTo(150 - 300 * (k - 0.5) * 2, -140 + 260 * (k - 0.5) * 2);
    }
    g.stroke();
  }
  g.restore();
}

export function contador(g, d, tl, base, color = '#E23B3B') {
  g.save();
  const gr = g.createRadialGradient(W / 2, H * 0.4, 30, W / 2, H * 0.4, W);
  gr.addColorStop(0, mezclarHex(base, '#000000', 0.15));
  gr.addColorStop(1, mezclarHex(base, '#000000', 0.7));
  g.fillStyle = gr;
  g.fillRect(0, 0, W, H);
  const k = salida(Math.min(1, (tl - 0.1) / (d.dur || 1.6)));
  const v = Math.round((d.desde || 0) + (d.hasta - (d.desde || 0)) * k);
  const txt = (d.formato ? d.formato(v) : v.toLocaleString('es')) + (d.sufijo || '');
  g.save();
  g.translate(W / 2, 560);
  const s = 1 + (k < 1 ? 0.04 * Math.sin(tl * 40) : 0);
  g.scale(s, s);
  g.shadowColor = 'rgba(0,0,0,0.5)';
  g.shadowBlur = 20;
  texto(g, txt, 0, -110, d.tam || 170, 900, '#FFFFFF', 'center');
  g.restore();
  if (d.etiqueta) texto(g, d.etiqueta, W / 2, 700, 36, 800, 'rgba(255,255,255,0.85)', 'center', 640);
  const n = Math.min(40, Math.round((d.iconos || 0) * k));
  for (let i = 0; i < n; i++) {
    const x = 120 + (i % 8) * 68, y = 820 + Math.floor(i / 8) * 76;
    d.icono ? d.icono(g, x, y, tl, i) : (g.beginPath(), g.arc(x, y, 18, 0, 7), (g.fillStyle = color), g.fill());
  }
  g.restore();
}

// ---------- reproducción ----------
export const ERRORES = [];

const normal = (w) => String(w).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9ñ]/g, '');

export function armar(spec) {
  // En el bot, la voz real (Gemini) manda: palabras con su tiempo y la duración total
  const datos = typeof window !== 'undefined' && window.DATOS ? window.DATOS : null;
  const duracion = datos ? datos.duracion : spec.duracion;
  const palabras = datos ? datos.palabras : tiemposVoz(spec.frases, spec.duracion);
  spec.duracion = duracion;
  // Cada toma se ancla a la palabra de la voz donde empieza ({desde: 'palabra'})
  let previa = -1;
  spec.tomas.forEach((tm, i) => {
    if (i === 0) {
      tm.t = 0;
      previa = 0;
      return;
    }
    if (tm.desde != null) {
      const buscada = normal(String(tm.desde).split(' ')[0]);
      const ix = palabras.findIndex((p) => p.t > previa + 0.3 && normal(p.w).startsWith(buscada));
      tm.t = ix >= 0 ? Math.max(0, palabras[ix].t - 0.08) : undefined;
    }
    if (typeof tm.t !== 'number' || !(tm.t > previa)) tm.t = Math.min(duracion - 0.8, previa + 1.6);
    previa = tm.t;
  });
  spec.palabras = palabras;
  let ultimaBuena = 0;
  const fn = (g, t) => {
    let k = 0;
    spec.tomas.forEach((tm, i) => {
      if (t >= tm.t) k = i;
    });
    const dibujarToma = (j) => {
      const tm = spec.tomas[j];
      const fin = j + 1 < spec.tomas.length ? spec.tomas[j + 1].t : duracion;
      const tl = t - tm.t, p = Math.min(1, tl / Math.max(0.1, fin - tm.t));
      g.save();
      g.clearRect(0, 0, W, H);
      tm.dibujar(g, t, tl, p, tm);
      g.restore();
      return {tm, tl};
    };
    let r;
    try {
      r = dibujarToma(k);
      ultimaBuena = k;
    } catch (e) {
      // una toma rota no tumba el video: se repite la última que funcionó
      ERRORES.push(`toma ${k} (t=${t.toFixed(2)}): ${e && e.message}`);
      g.restore();
      try {
        r = dibujarToma(ultimaBuena);
      } catch (e2) {
        g.fillStyle = '#111';
        g.fillRect(0, 0, W, H);
        r = {tm: spec.tomas[k], tl: t - spec.tomas[k].t};
      }
    }
    const {tm, tl} = r;
    if (tm.luz) luz(g, tm.luz);
    if (tm.ficha) ficha(g, tm.ficha[0], tm.ficha[1], tl);
    if (tm.sello) sello(g, tm.sello, tl, tm.colorSello);
    subtitulos(g, palabras, t, spec.subtitulos);
    if (tl < 0.06 && k > 0) {
      g.fillStyle = `rgba(255,255,255,${0.18 * (1 - tl / 0.06)})`;
      g.fillRect(0, 0, W, H);
    }
  };
  fn.tomas = spec.tomas.map((x) => ({t: x.t, sello: !!x.sello}));
  return fn;
}
