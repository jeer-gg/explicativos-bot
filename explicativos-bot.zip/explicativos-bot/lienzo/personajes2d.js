const BASE_W = 400;
const BASE_H = 645;
const oscuro = (hex, k) => {
    const n = parseInt((hex || '#888888').replace('#', '').padEnd(6, '0'), 16);
    const c = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => Math.max(0, Math.min(255, Math.round(v * k))));
    return '#' + c.map((v) => v.toString(16).padStart(2, '0')).join('');
};
export function personaje(x, w, h, o) {
    const s = Math.min(w / BASE_W, h / BASE_H);
    x.save();
    x.translate((w - BASE_W * s) / 2, h - BASE_H * s);
    x.scale(s, s);
    const t = o.t || 0;
    const linea = o.contorno ? 9 : 0;
    const tinta = o.c.contorno;
    const piel = o.piel || o.c.piel;
    const ropa = o.ropa || o.color || o.c.ropa;
    const pantalon = o.pantalon || '#2E3440';
    const pelo = o.colorPelo || '#2A1E1A';
    const expr = (o.expresion || 'serio').toLowerCase();
    const pose = (o.pose || 'parado').toLowerCase();
    const respira = Math.sin(t * 2.2) * 2.5;
    const relleno = (color, grosor = linea) => {
        x.fillStyle = color;
        x.fill();
        if (grosor) {
            x.lineWidth = grosor;
            x.strokeStyle = tinta;
            x.lineJoin = 'round';
            x.lineCap = 'round';
            x.stroke();
        }
    };
    const brazo = (puntos, color, ancho = 44) => {
        x.beginPath();
        x.moveTo(puntos[0][0], puntos[0][1]);
        for (let i = 1; i < puntos.length; i++)
            x.lineTo(puntos[i][0], puntos[i][1]);
        x.lineCap = 'round';
        x.lineJoin = 'round';
        if (linea) {
            x.strokeStyle = tinta;
            x.lineWidth = ancho + linea * 2;
            x.stroke();
        }
        x.strokeStyle = color;
        x.lineWidth = ancho;
        x.stroke();
        const [mx, my] = puntos[puntos.length - 1];
        x.beginPath();
        x.arc(mx, my, ancho * 0.48, 0, Math.PI * 2);
        relleno(piel);
    };
    // ---------- piernas y zapatos ----------
    const paso = pose === 'camina' ? Math.sin(t * 7) : 0;
    [-1, 1].forEach((lado) => {
        const dx = lado * 42 + (lado * paso * 18);
        x.beginPath();
        x.roundRect(200 + dx - 26, 470, 52, 140, 18);
        relleno(pantalon);
        x.beginPath();
        x.ellipse(200 + dx + lado * 8, 618, 40, 20, 0, 0, Math.PI * 2);
        relleno('#1C1C22');
    });
    // ---------- brazos de atrás (según la pose) ----------
    const hombroI = [118, 352 + respira];
    const hombroD = [282, 352 + respira];
    const mangas = oscuro(ropa, 0.9);
    if (pose === 'senala')
        brazo([hombroD, [355, 330], [392, 300]], mangas);
    else if (pose === 'saluda')
        brazo([hombroD, [330, 280], [345, 200 + Math.sin(t * 10) * 12]], mangas);
    else if (pose === 'manos_cadera')
        brazo([hombroD, [322, 420], [282, 452]], mangas);
    else if (pose !== 'celular' && pose !== 'brazos_cruzados' && pose !== 'piensa')
        brazo([hombroD, [300, 420 + paso * 10], [296, 480]], mangas);
    if (pose === 'manos_cadera')
        brazo([hombroI, [78, 420], [118, 452]], mangas);
    else if (pose !== 'celular' && pose !== 'brazos_cruzados')
        brazo([hombroI, [100, 420 - paso * 10], [104, 480]], mangas);
    // ---------- torso (sudadera) ----------
    x.beginPath();
    x.moveTo(120, 340 + respira);
    x.quadraticCurveTo(200, 318 + respira, 280, 340 + respira);
    x.quadraticCurveTo(306, 420, 296, 492);
    x.quadraticCurveTo(200, 506, 104, 492);
    x.quadraticCurveTo(94, 420, 120, 340 + respira);
    relleno(ropa);
    x.beginPath();
    x.roundRect(150, 430, 100, 44, 14);
    relleno(oscuro(ropa, 0.85), linea * 0.6);
    // ---------- brazos de adelante ----------
    if (pose === 'celular') {
        brazo([hombroI, [130, 440], [176, 412]], mangas);
        brazo([hombroD, [270, 440], [224, 412]], mangas);
        x.beginPath();
        x.roundRect(170, 352, 60, 96, 10);
        relleno('#15151A');
        x.fillStyle = `rgba(150,210,255,${0.55 + 0.25 * Math.sin(t * 3)})`;
        x.fillRect(177, 360, 46, 78);
    }
    else if (pose === 'brazos_cruzados') {
        brazo([hombroI, [150, 420], [262, 410]], mangas);
        brazo([hombroD, [250, 430], [138, 418]], mangas);
    }
    else if (pose === 'piensa') {
        brazo([hombroI, [100, 430], [104, 480]], mangas);
        brazo([hombroD, [276, 420], [236, 300]], mangas);
    }
    // ---------- cabeza ----------
    const cy = 190 + respira * 0.6;
    const inclina = expr === 'pensativo' ? -0.06 : expr === 'triste' ? 0.05 : 0;
    x.save();
    x.translate(200, cy);
    x.rotate(inclina);
    x.translate(-200, -cy);
    // pelo de atrás (largo, cola)
    if (o.pelo === 'largo') {
        x.beginPath();
        x.roundRect(62, cy - 60, 276, 250, 70);
        relleno(pelo);
    }
    else if (o.pelo === 'cola') {
        x.beginPath();
        x.ellipse(330, cy - 10 + Math.sin(t * 3) * 4, 40, 90, 0.5, 0, Math.PI * 2);
        relleno(pelo);
    }
    // cara
    x.beginPath();
    x.ellipse(200, cy, 140, 132, 0, 0, Math.PI * 2);
    relleno(piel);
    x.save();
    x.beginPath();
    x.ellipse(200, cy, 140, 132, 0, 0, Math.PI * 2);
    x.clip();
    x.fillStyle = 'rgba(0,0,0,0.07)';
    x.beginPath();
    x.ellipse(200, cy + 120, 170, 70, 0, 0, Math.PI * 2);
    x.fill();
    x.restore();
    // orejas
    [-1, 1].forEach((l) => {
        x.beginPath();
        x.ellipse(200 + l * 140, cy + 8, 20, 28, 0, 0, Math.PI * 2);
        relleno(piel, linea * 0.8);
    });
    // ojos
    const mira = Math.max(-1, Math.min(1, o.mira ?? 0)) * 8;
    const parpadeo = expr !== 'feliz' && (t % 3.4) > 3.27;
    const ojoR = expr === 'sorprendido' || expr === 'asustado' ? 22 : 17;
    [-1, 1].forEach((l) => {
        const ox = 200 + l * 52;
        const oy = cy + 4;
        if (expr === 'feliz' || expr === 'picaro' && l === 1) {
            x.beginPath();
            x.arc(ox, oy + 6, 18, Math.PI * 1.1, Math.PI * 1.9);
            x.lineWidth = 9;
            x.strokeStyle = '#1B1414';
            x.lineCap = 'round';
            x.stroke();
            return;
        }
        if (parpadeo) {
            x.beginPath();
            x.moveTo(ox - 18, oy);
            x.lineTo(ox + 18, oy);
            x.lineWidth = 8;
            x.strokeStyle = '#1B1414';
            x.stroke();
            return;
        }
        x.beginPath();
        x.ellipse(ox + mira, oy, ojoR * 0.8, ojoR * (expr === 'asustado' ? 1.25 : 1.1), 0, 0, Math.PI * 2);
        x.fillStyle = '#1B1414';
        x.fill();
        x.beginPath();
        x.arc(ox + mira - 5, oy - 7, ojoR * 0.3, 0, Math.PI * 2);
        x.fillStyle = '#FFFFFF';
        x.fill();
        // párpados (serio, aburrido, enojado, pícaro)
        const tapa = expr === 'aburrido' ? 0.55 : expr === 'serio' ? 0.32 : expr === 'enojado' ? 0.38 : expr === 'picaro' ? 0.4 : 0;
        if (tapa > 0) {
            x.beginPath();
            x.rect(ox - 26, oy - 30, 52, 30 * tapa * 1.9);
            x.fillStyle = piel;
            x.fill();
            x.beginPath();
            x.moveTo(ox - 22, oy - 30 + 30 * tapa * 1.9);
            x.lineTo(ox + 22, oy - 30 + 30 * tapa * 1.9);
            x.lineWidth = 6;
            x.strokeStyle = '#1B1414';
            x.stroke();
        }
    });
    // cejas
    const ceja = (l) => {
        const bx = 200 + l * 52;
        const by = cy - 36 - (expr === 'sorprendido' || expr === 'asustado' ? 16 : 0);
        // d > 0: la punta de adentro baja (enojo); d < 0: sube (tristeza, miedo)
        const d = expr === 'enojado' ? 11 : expr === 'triste' || expr === 'asustado' ? -10 : expr === 'pensativo' && l === 1 ? -9 : expr === 'picaro' && l === -1 ? 6 : 0;
        const adentro = bx - l * 24;
        const afuera = bx + l * 24;
        x.beginPath();
        x.moveTo(afuera, by - d * 0.5);
        x.lineTo(adentro, by + d * 0.5);
        x.lineWidth = 10;
        x.strokeStyle = oscuro(pelo, 0.9);
        x.lineCap = 'round';
        x.stroke();
    };
    ceja(-1);
    ceja(1);
    // mejillas
    if (expr === 'feliz' || expr === 'picaro') {
        [-1, 1].forEach((l) => {
            x.beginPath();
            x.ellipse(200 + l * 82, cy + 44, 22, 12, 0, 0, Math.PI * 2);
            x.fillStyle = 'rgba(235,110,110,0.35)';
            x.fill();
        });
    }
    // boca
    const my = cy + 62;
    const abierta = o.habla ? Math.max(0, Math.sin(t * 15) * 0.5 + Math.sin(t * 9.3) * 0.5) : 0;
    x.lineWidth = 8;
    x.strokeStyle = '#1B1414';
    x.lineCap = 'round';
    x.beginPath();
    if (abierta > 0.15 || expr === 'sorprendido' || expr === 'asustado') {
        const alto = expr === 'sorprendido' ? 22 : 8 + abierta * 20;
        x.ellipse(200, my, expr === 'asustado' ? 26 : 18, alto, 0, 0, Math.PI * 2);
        x.fillStyle = '#5A1F22';
        x.fill();
        x.stroke();
    }
    else if (expr === 'feliz' || expr === 'picaro') {
        x.arc(200, my - 12, 30, Math.PI * 0.15, Math.PI * 0.85);
        x.stroke();
    }
    else if (expr === 'triste' || expr === 'enojado') {
        x.arc(200, my + 20, 24, Math.PI * 1.2, Math.PI * 1.8);
        x.stroke();
    }
    else if (expr === 'pensativo') {
        x.moveTo(186, my + 2);
        x.lineTo(214, my - 4);
        x.stroke();
    }
    else {
        x.moveTo(184, my);
        x.lineTo(216, my);
        x.stroke();
    }
    // accesorios de cara
    if (o.accesorio === 'barba') {
        x.beginPath();
        x.ellipse(200, cy + 92, 92, 52, 0, 0, Math.PI);
        relleno(pelo, linea * 0.6);
    }
    else if (o.accesorio === 'bigote') {
        x.beginPath();
        x.ellipse(200, my - 16, 40, 12, 0, 0, Math.PI * 2);
        x.fillStyle = pelo;
        x.fill();
    }
    else if (o.accesorio === 'lentes') {
        [-1, 1].forEach((l) => {
            x.beginPath();
            x.arc(200 + l * 52, cy + 4, 30, 0, Math.PI * 2);
            x.lineWidth = 7;
            x.strokeStyle = '#1B1414';
            x.stroke();
        });
        x.beginPath();
        x.moveTo(178, cy + 2);
        x.lineTo(222, cy + 2);
        x.stroke();
    }
    // pelo de arriba
    const tipoPelo = o.pelo || 'corto';
    x.beginPath();
    if (tipoPelo === 'puntas') {
        x.moveTo(58, cy - 10);
        const picos = 9;
        for (let i = 0; i <= picos; i++) {
            const a = Math.PI + (i / picos) * Math.PI;
            const r = i % 2 ? 160 : 130;
            x.lineTo(200 + Math.cos(a) * r * 1.02, cy - 8 + Math.sin(a) * r * 0.98);
        }
        x.lineTo(342, cy - 10);
        x.quadraticCurveTo(200, cy - 70, 58, cy - 10);
        relleno(pelo);
    }
    else if (tipoPelo === 'rizado') {
        for (let i = 0; i < 9; i++) {
            const a = Math.PI * 1.02 + (i / 8) * Math.PI * 0.96;
            x.moveTo(200 + Math.cos(a) * 128 + 34, cy - 20 + Math.sin(a) * 118);
            x.arc(200 + Math.cos(a) * 128, cy - 20 + Math.sin(a) * 118, 34, 0, Math.PI * 2);
        }
        relleno(pelo);
    }
    else if (tipoPelo === 'gorra') {
        x.ellipse(200, cy - 52, 146, 92, 0, Math.PI, 0);
        x.closePath();
        relleno(o.ropa ? oscuro(ropa, 0.7) : '#C8382E');
        x.beginPath();
        x.ellipse(250, cy - 50, 120, 22, 0, 0, Math.PI * 2);
        relleno(o.ropa ? oscuro(ropa, 0.6) : '#A82B23');
    }
    else if (tipoPelo !== 'calvo') {
        // corto, largo, cola, mono: casquete con flequillo
        x.moveTo(60, cy + 10);
        x.quadraticCurveTo(54, cy - 150, 200, cy - 142);
        x.quadraticCurveTo(346, cy - 150, 340, cy + 10);
        x.quadraticCurveTo(300, cy - 70, 230, cy - 74);
        x.quadraticCurveTo(160, cy - 40, 96, cy - 52);
        x.quadraticCurveTo(70, cy - 30, 60, cy + 10);
        relleno(pelo);
        if (tipoPelo === 'mono') {
            x.beginPath();
            x.arc(200, cy - 158, 46, 0, Math.PI * 2);
            relleno(pelo);
        }
    }
    if (o.accesorio === 'casco' || o.accesorio === 'sombrero') {
        x.beginPath();
        x.ellipse(200, cy - 60, 150, 100, 0, Math.PI, 0);
        x.closePath();
        relleno(o.accesorio === 'casco' ? '#5E6B3A' : '#6B4A2E');
        x.beginPath();
        x.ellipse(200, cy - 60, o.accesorio === 'sombrero' ? 200 : 160, 24, 0, 0, Math.PI * 2);
        relleno(o.accesorio === 'casco' ? '#4E5A2F' : '#5A3D25');
    }
    x.restore();
    x.restore();
}
