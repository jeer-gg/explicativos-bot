// Insertos del montaje: las tomas de detalle que hacen que una historia se entienda sin audio
// (el documento, la pantalla del celular, el mapa con la ruta, el calendario, el reloj, el
// contador) y lo que se pone encima de cualquier toma (ficha con nombre/fecha, sello, luz).
// Plantillas fijas y cuidadas: el guion solo da los datos.
import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring} from 'remotion';
import {fuente} from './fuente';
import {Paleta} from './lib';

export type DatosInserto = {[k: string]: any};
export type Toma = {
  inicio: number;
  tipo: string;
  encuadre: string;
  luz?: string;
  ve?: string;
  inserto?: DatosInserto;
  ficha?: {titulo: string; sub?: string};
  sello?: string;
  resalta?: string;
};

const F = fuente.fontFamily;
const SUAVE = Easing.bezier(0.22, 1, 0.36, 1);
const entra = (f: number, fps: number, retraso = 0, rigidez = 140) =>
  spring({frame: f - retraso, fps, config: {damping: 14, stiffness: rigidez, mass: 0.7}});
const prog = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: SUAVE});
const txt = (v: any, n = 80) => (v == null ? '' : String(v)).slice(0, n);
const lista = (v: any): string[] => (Array.isArray(v) ? v.map((x) => txt(typeof x === 'object' ? x?.texto ?? x?.nombre ?? '' : x, 70)).filter(Boolean) : []);
const hash = (s: string) => {
  let h = 7;
  for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 100003;
  return h;
};
const azar = (semilla: number) => {
  let s = semilla || 1;
  return () => ((s = (s * 16807) % 2147483647) / 2147483647);
};
const mezclar = (a: string, b: string, k: number) => {
  const p = (h: string) => [1, 3, 5].map((i) => parseInt(h.replace('#', '').padEnd(6, '0').slice(i - 1, i + 1), 16));
  const x = p(a), y = p(b);
  return '#' + x.map((v, i) => Math.round(v + (y[i] - v) * k).toString(16).padStart(2, '0')).join('');
};

/** Fondo de las tomas de inserto: superficie con la paleta de la página, luz cenital y viñeta. */
const Mesa: React.FC<{paleta: Paleta; f: number; children?: React.ReactNode}> = ({paleta, f, children}) => {
  const base = paleta.fondo;
  const claro = mezclar(base, '#FFFFFF', 0.18);
  const oscuro = mezclar(base, '#000000', 0.45);
  const empuje = 1 + 0.06 * prog(f, 0, 90); // la cámara se sigue acercando despacio
  return (
    <AbsoluteFill style={{background: `radial-gradient(ellipse 75% 55% at 50% 45%, ${claro} 0%, ${base} 55%, ${oscuro} 100%)`}}>
      <AbsoluteFill style={{opacity: 0.08, backgroundImage: 'repeating-linear-gradient(115deg, rgba(255,255,255,0.6) 0 2px, transparent 2px 26px)'}} />
      <AbsoluteFill style={{transform: `scale(${empuje})`, transformOrigin: '50% 48%'}}>{children}</AbsoluteFill>
    </AbsoluteFill>
  );
};

// ---------- documento: nota, carta, registro oficial, periódico ----------
const Documento: React.FC<{d: DatosInserto; f: number; fps: number; paleta: Paleta}> = ({d, f, fps, paleta}) => {
  const tipo = txt(d.tipo || 'carta', 12);
  const lineas = lista(d.lineas).length ? lista(d.lineas) : [txt(d.texto, 120)].filter(Boolean);
  const e = entra(f, fps);
  const papel = tipo === 'nota' ? '#FFE98A' : tipo === 'periodico' ? '#EFE8DA' : '#FBF7EE';
  const giro = interpolate(e, [0, 1], [-14, -2.5]);
  const acento = paleta.acentos[0] || '#C0392B';
  return (
    <Mesa paleta={paleta} f={f}>
      <div style={{position: 'absolute', left: 150, top: 470 + (1 - e) * 500, width: 780, minHeight: 820, background: papel,
        transform: `rotate(${giro}deg)`, borderRadius: tipo === 'nota' ? 6 : 14, boxShadow: '0 40px 80px rgba(0,0,0,0.45), 0 6px 0 rgba(0,0,0,0.12)',
        padding: '70px 64px', fontFamily: F, color: '#2B2420', opacity: Math.min(1, e * 1.5)}}>
        {tipo === 'periodico' ? (
          <div style={{borderBottom: '6px double #2B2420', fontSize: 64, fontWeight: 900, textAlign: 'center', paddingBottom: 18, marginBottom: 30, letterSpacing: 2}}>
            {txt(d.medio || 'EL DIARIO', 24).toUpperCase()}
          </div>
        ) : null}
        {tipo === 'registro' ? (
          <div style={{fontSize: 34, fontWeight: 800, textAlign: 'center', letterSpacing: 3, color: '#6B5D50', marginBottom: 24}}>
            {txt(d.encabezado || 'REGISTRO OFICIAL', 32).toUpperCase()}
          </div>
        ) : null}
        {d.titulo ? (
          <div style={{fontSize: tipo === 'nota' ? 70 : 84, fontWeight: 900, lineHeight: 1.02, textAlign: 'center', marginBottom: 34,
            transform: `scale(${0.8 + 0.2 * entra(f, fps, 6)})`}}>{txt(d.titulo, 60)}</div>
        ) : null}
        {lineas.map((l, i) => {
          const desde = 12 + i * 10;
          const n = Math.floor(l.length * prog(f, desde, desde + Math.max(8, l.length * 0.9)));
          return (
            <div key={i} style={{fontSize: 46, fontWeight: 700, lineHeight: 1.25, marginBottom: 18, minHeight: 58,
              borderBottom: tipo === 'carta' ? '2px solid rgba(0,0,0,0.08)' : 'none'}}>{l.slice(0, n)}</div>
          );
        })}
        {d.firma ? <div style={{fontSize: 40, fontStyle: 'italic', textAlign: 'right', marginTop: 30, opacity: prog(f, 40, 55)}}>— {txt(d.firma, 40)}</div> : null}
        {d.marca ? (
          <div style={{position: 'absolute', right: 50, bottom: 60, width: 150, height: 150, borderRadius: 75, border: `8px solid ${acento}`,
            opacity: 0.75 * prog(f, 30, 38), transform: 'rotate(-14deg)'}} />
        ) : null}
      </div>
    </Mesa>
  );
};

// ---------- pantalla del celular: chat, banco, notificación, búsqueda ----------
const Pantalla: React.FC<{d: DatosInserto; f: number; fps: number; paleta: Paleta}> = ({d, f, fps, paleta}) => {
  const app = txt(d.app || 'chat', 14);
  const acento = paleta.acentos[1] || '#1E8E5A';
  const e = entra(f, fps, 0, 120);
  const lineas = lista(d.lineas);
  const escribe = txt(d.escribe, 60);
  const nEscribe = Math.floor(escribe.length * prog(f, 14, 14 + Math.max(10, escribe.length * 1.4)));
  const toque = Math.max(0, Math.min(1, (f - (20 + escribe.length * 1.4)) / 8));
  return (
    <Mesa paleta={paleta} f={f}>
      <div style={{position: 'absolute', left: 210, top: 360 + (1 - e) * 700, width: 660, height: 1260, borderRadius: 86, background: '#111',
        padding: 22, boxShadow: '0 50px 90px rgba(0,0,0,0.5)', transform: `rotate(${interpolate(e, [0, 1], [8, -2])}deg)`}}>
        <div style={{width: '100%', height: '100%', borderRadius: 66, overflow: 'hidden', background: app === 'notificacion' ? `linear-gradient(170deg, #2C2F5C, #6B3E7A)` : '#F4F5F7',
          fontFamily: F, position: 'relative'}}>
          <div style={{position: 'absolute', top: 18, left: '50%', marginLeft: -80, width: 160, height: 40, borderRadius: 20, background: '#111'}} />
          {app === 'notificacion' ? (
            <>
              <div style={{marginTop: 150, textAlign: 'center', color: 'white', fontSize: 150, fontWeight: 800}}>{txt(d.hora || '19:02', 6)}</div>
              <div style={{textAlign: 'center', color: 'rgba(255,255,255,0.8)', fontSize: 36}}>{txt(d.fecha || '', 30)}</div>
              <div style={{margin: '80px 30px 0', background: 'rgba(255,255,255,0.92)', borderRadius: 36, padding: '30px 34px',
                transform: `translateY(${(1 - entra(f, fps, 10)) * -260}px)`, opacity: prog(f, 10, 16)}}>
                <div style={{fontSize: 28, color: '#666', fontWeight: 800}}>{txt(d.titulo || 'NOTIFICACIÓN', 30).toUpperCase()}</div>
                {lineas.map((l, i) => <div key={i} style={{fontSize: 38, color: '#111', fontWeight: 800, marginTop: 8}}>{l}</div>)}
              </div>
            </>
          ) : (
            <>
              <div style={{background: acento, color: 'white', padding: '90px 40px 30px', fontSize: 44, fontWeight: 900}}>{txt(d.titulo || (app === 'banco' ? 'Tu Banco' : 'Mensajes'), 24)}</div>
              {app === 'banco' ? (
                <div style={{padding: 40}}>
                  {lineas.slice(0, 2).map((l, i) => <div key={i} style={{fontSize: 34, color: '#555', fontWeight: 700, marginBottom: 14}}>{l}</div>)}
                  <div style={{fontSize: 120, fontWeight: 900, color: '#111', margin: '20px 0', transform: `scale(${0.85 + 0.15 * entra(f, fps, 6)})`}}>{txt(d.monto || '$ 0.01', 12)}</div>
                  <div style={{border: `4px solid ${acento}`, borderRadius: 26, padding: 26, minHeight: 170, fontSize: 40, color: '#222', fontWeight: 700}}>
                    <div style={{fontSize: 26, color: '#888', marginBottom: 8}}>{txt(d.campo || 'Concepto', 20)}</div>
                    {escribe.slice(0, nEscribe)}
                    <span style={{opacity: Math.floor(f / 8) % 2 ? 1 : 0}}>|</span>
                  </div>
                  <div style={{marginTop: 40, background: acento, color: 'white', borderRadius: 50, padding: 30, textAlign: 'center', fontSize: 44, fontWeight: 900,
                    transform: `scale(${1 - 0.06 * Math.sin(toque * Math.PI)})`}}>{txt(d.boton || 'Transferir', 16)}</div>
                </div>
              ) : app === 'busqueda' ? (
                <div style={{padding: 34}}>
                  <div style={{background: 'white', borderRadius: 40, padding: '24px 30px', fontSize: 40, boxShadow: '0 4px 14px rgba(0,0,0,0.12)', fontWeight: 700}}>
                    {escribe.slice(0, nEscribe)}
                  </div>
                  {lineas.map((l, i) => (
                    <div key={i} style={{marginTop: 34, opacity: prog(f, 30 + i * 6, 36 + i * 6), fontSize: 36, fontWeight: 800, color: '#1A4FB0'}}>{l}</div>
                  ))}
                </div>
              ) : (
                <div style={{padding: '30px 28px', display: 'flex', flexDirection: 'column', gap: 22}}>
                  {lineas.map((l, i) => {
                    const mio = i % 2 === 1;
                    const a = entra(f, fps, 6 + i * 9);
                    return (
                      <div key={i} style={{alignSelf: mio ? 'flex-end' : 'flex-start', maxWidth: '78%', background: mio ? acento : 'white', color: mio ? 'white' : '#111',
                        borderRadius: 34, padding: '22px 30px', fontSize: 38, fontWeight: 700, transform: `scale(${a})`, transformOrigin: mio ? '100% 100%' : '0 100%',
                        boxShadow: '0 3px 10px rgba(0,0,0,0.1)'}}>{l}</div>
                    );
                  })}
                  {escribe ? <div style={{marginTop: 20, background: 'white', borderRadius: 40, padding: '20px 28px', fontSize: 36, color: '#333'}}>{escribe.slice(0, nEscribe)}|</div> : null}
                </div>
              )}
            </>
          )}
        </div>
      </div>
      {app === 'banco' && toque > 0 ? (
        <div style={{position: 'absolute', left: 520, top: 1380 - toque * 120, width: 140, height: 260, borderRadius: 70, background: mezclar('#C98E62', paleta.fondo, 0.15),
          border: '6px solid rgba(0,0,0,0.6)', opacity: Math.min(1, toque * 2)}} />
      ) : null}
    </Mesa>
  );
};

// ---------- mapa con ruta ----------
const Mapa: React.FC<{d: DatosInserto; f: number; fps: number; paleta: Paleta}> = ({d, f, fps, paleta}) => {
  const lugares = (Array.isArray(d.lugares) ? d.lugares : []).slice(0, 4).map((l: any) => txt(typeof l === 'object' ? l.nombre : l, 22)).filter(Boolean);
  const nombres = lugares.length ? lugares : [txt(d.titulo || 'Aquí', 22)];
  const r = azar(hash(nombres.join('|')) + 3);
  const mar = '#1D5F8C', tierra = '#7FB069', tierraOsc = '#5E8F4C';
  const islas = Array.from({length: 5}, (_, i) => ({x: 120 + r() * 840, y: 450 + r() * 1000, w: 160 + r() * 330, h: 120 + r() * 260, g: r() * 180}));
  const puntos = nombres.map((_, i) => ({x: 230 + ((i * 1.0) / Math.max(1, nombres.length - 1)) * 620 + (r() - 0.5) * 120, y: 1280 - (i / Math.max(1, nombres.length - 1)) * 640 + (r() - 0.5) * 120}));
  if (nombres.length === 1) puntos[0] = {x: 540, y: 900};
  const ruta = puntos.map((p, i) => `${i ? 'L' : 'M'}${p.x},${p.y}`).join(' ');
  const largo = puntos.reduce((s, p, i) => (i ? s + Math.hypot(p.x - puntos[i - 1].x, p.y - puntos[i - 1].y) : 0), 0) || 1;
  const avance = prog(f, 8, 8 + 22 * Math.max(1, nombres.length - 1));
  const zoom = 1.25 - 0.25 * entra(f, fps, 0, 60);
  return (
    <AbsoluteFill style={{background: mar}}>
      <svg width={1080} height={1920} style={{transform: `scale(${zoom})`, transformOrigin: '50% 50%'}}>
        <defs>
          <radialGradient id="marluz" cx="50%" cy="45%" r="70%"><stop offset="0%" stopColor="#3E8DBD" /><stop offset="100%" stopColor="#0C3352" /></radialGradient>
        </defs>
        <rect width={1080} height={1920} fill="url(#marluz)" />
        {islas.map((s, i) => (
          <g key={i} transform={`rotate(${s.g} ${s.x} ${s.y})`}>
            <ellipse cx={s.x} cy={s.y + 10} rx={s.w / 2} ry={s.h / 2} fill={tierraOsc} />
            <ellipse cx={s.x} cy={s.y} rx={s.w / 2} ry={s.h / 2} fill={tierra} stroke="#2E4A2A" strokeWidth={4} />
          </g>
        ))}
        {nombres.length > 1 ? (
          <path d={ruta} fill="none" stroke="#FFFFFF" strokeWidth={9} strokeDasharray={`${largo * avance} ${largo}`} strokeLinecap="round" />
        ) : null}
        {puntos.map((p, i) => {
          const visto = nombres.length === 1 || avance >= (i / Math.max(1, nombres.length - 1)) - 0.02;
          const pulso = 1 + 0.25 * Math.sin(f / 4);
          return visto ? (
            <g key={i}>
              <circle cx={p.x} cy={p.y} r={34 * pulso} fill="rgba(226,59,59,0.3)" />
              <circle cx={p.x} cy={p.y} r={20} fill="#E23B3B" stroke="white" strokeWidth={6} />
            </g>
          ) : null;
        })}
      </svg>
      {puntos.map((p, i) => {
        const visto = nombres.length === 1 || avance >= (i / Math.max(1, nombres.length - 1)) - 0.02;
        return visto ? (
          <div key={i} style={{position: 'absolute', left: Math.min(760, Math.max(40, p.x * zoom - (zoom - 1) * 540 + 40)), top: p.y * zoom - (zoom - 1) * 960 - 40,
            background: '#1B1B1F', color: 'white', fontFamily: F, fontWeight: 900, fontSize: 40, padding: '12px 24px', borderRadius: 14, borderLeft: '8px solid #E23B3B'}}>
            {nombres[i]}
          </div>
        ) : null;
      })}
    </AbsoluteFill>
  );
};

// ---------- calendario ----------
const Calendario: React.FC<{d: DatosInserto; f: number; fps: number; paleta: Paleta}> = ({d, f, fps, paleta}) => {
  const desde = d.desde != null ? txt(d.desde, 4) : null;
  const numero = txt(d.numero ?? d.dia ?? '1', 4);
  const cambio = desde != null ? prog(f, 10, 18) : 1;
  const e = entra(f, fps);
  const tacha = d.tachar ? prog(f, 26, 36) : 0;
  return (
    <Mesa paleta={paleta} f={f}>
      <div style={{position: 'absolute', left: 190, top: 430, width: 700, height: 860, background: '#FBF7EE', borderRadius: 30, overflow: 'hidden',
        boxShadow: '0 40px 80px rgba(0,0,0,0.45)', transform: `scale(${0.7 + 0.3 * e}) rotate(${(1 - e) * -6}deg)`, fontFamily: F}}>
        <div style={{background: '#C8382E', color: 'white', fontSize: 86, fontWeight: 900, textAlign: 'center', padding: '34px 0', letterSpacing: 4}}>{txt(d.mes || 'MARZO', 12).toUpperCase()}</div>
        <div style={{position: 'relative', height: 560}}>
          {desde != null && cambio < 1 ? (
            <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 380, fontWeight: 900, color: '#222',
              transform: `translateY(${-cambio * 500}px) rotate(${-cambio * 12}deg)`, opacity: 1 - cambio}}>{desde}</div>
          ) : null}
          <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 380, fontWeight: 900, color: '#222', opacity: cambio}}>{numero}</div>
          {tacha > 0 ? (
            <svg width={700} height={560} style={{position: 'absolute', inset: 0}}>
              <line x1={120} y1={90} x2={120 + 460 * tacha} y2={90 + 380 * tacha} stroke="#C8382E" strokeWidth={34} strokeLinecap="round" />
              {tacha > 0.5 ? <line x1={580} y1={90} x2={580 - 460 * (tacha - 0.5) * 2} y2={90 + 380 * (tacha - 0.5) * 2} stroke="#C8382E" strokeWidth={34} strokeLinecap="round" /> : null}
            </svg>
          ) : null}
        </div>
        {d.texto ? <div style={{textAlign: 'center', fontSize: 70, fontWeight: 900, color: '#C8382E'}}>{txt(d.texto, 16).toUpperCase()}</div> : null}
      </div>
    </Mesa>
  );
};

// ---------- reloj ----------
const Reloj: React.FC<{d: DatosInserto; f: number; fps: number; paleta: Paleta}> = ({d, f, fps, paleta}) => {
  const aHoras = (s: any, def: number) => {
    const m = String(s ?? '').match(/(\d{1,2})(?::(\d{2}))?/);
    return m ? (Number(m[1]) % 12) + Number(m[2] || 0) / 60 : def;
  };
  const h0 = aHoras(d.desde, 7), h1 = aHoras(d.hora, 8);
  const h = h0 + ((h1 - h0 + 12) % 12 || 12) * prog(f, 6, 40);
  const e = entra(f, fps);
  return (
    <Mesa paleta={paleta} f={f}>
      <svg width={1080} height={1920} style={{transform: `scale(${0.75 + 0.25 * e})`, transformOrigin: '50% 50%'}}>
        <circle cx={540} cy={900} r={400} fill="#FBF7EE" stroke="#2B2420" strokeWidth={26} />
        {Array.from({length: 12}, (_, i) => {
          const a = (i / 12) * Math.PI * 2;
          return <text key={i} x={540 + Math.sin(a) * 320} y={900 - Math.cos(a) * 320 + 28} fontSize={78} fontWeight={900} fill="#2B2420" textAnchor="middle" fontFamily={F}>{i || 12}</text>;
        })}
        <line x1={540} y1={900} x2={540 + Math.sin((h / 12) * Math.PI * 2) * 200} y2={900 - Math.cos((h / 12) * Math.PI * 2) * 200} stroke="#2B2420" strokeWidth={30} strokeLinecap="round" />
        <line x1={540} y1={900} x2={540 + Math.sin(h * Math.PI * 2) * 300} y2={900 - Math.cos(h * Math.PI * 2) * 300} stroke="#C8382E" strokeWidth={16} strokeLinecap="round" />
        <circle cx={540} cy={900} r={26} fill="#2B2420" />
      </svg>
    </Mesa>
  );
};

// ---------- contador ----------
const Icono: React.FC<{tipo: string; x: number; y: number; t: number; color: string}> = ({tipo, x, y, t, color}) => {
  if (tipo === 'vela')
    return (
      <g>
        <rect x={x - 14} y={y - 10} width={28} height={70} rx={6} fill="#F4EBD8" />
        <ellipse cx={x} cy={y - 28 + Math.sin(t * 9 + x) * 2} rx={12} ry={22} fill="#FFB340" />
        <ellipse cx={x} cy={y - 22} rx={5} ry={10} fill="#FFF3B0" />
      </g>
    );
  if (tipo === 'moneda') return <circle cx={x} cy={y + 20} r={30} fill="#E8B83A" stroke="#9C7413" strokeWidth={6} />;
  if (tipo === 'persona')
    return (
      <g fill={color}>
        <circle cx={x} cy={y} r={18} />
        <rect x={x - 22} y={y + 22} width={44} height={50} rx={18} />
      </g>
    );
  return <circle cx={x} cy={y + 20} r={20} fill={color} />;
};

const Contador: React.FC<{d: DatosInserto; f: number; fps: number; paleta: Paleta}> = ({d, f, fps, paleta}) => {
  const desde = Number(d.desde ?? 0) || 0;
  const hasta = Number(d.hasta ?? d.valor ?? 10) || 10;
  const k = prog(f, 4, 40);
  const valor = Math.round(desde + (hasta - desde) * k);
  const icono = txt(d.icono || 'punto', 10);
  const visibles = Math.min(60, Math.round(Math.min(60, hasta) * (Math.max(valor, 0) / Math.max(1, hasta))));
  const color = paleta.acentos[0] || '#E23B3B';
  return (
    <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 40%, ${mezclar(paleta.fondo, '#000000', 0.2)} 0%, ${mezclar(paleta.fondo, '#000000', 0.7)} 100%)`}}>
      <div style={{position: 'absolute', top: 470, width: '100%', textAlign: 'center', fontFamily: F, fontSize: 300, fontWeight: 900, color: 'white',
        transform: `scale(${1 + 0.08 * Math.sin(k * Math.PI * 6) * (1 - k)})`, textShadow: '0 10px 30px rgba(0,0,0,0.5)'}}>
        {d.prefijo ? txt(d.prefijo, 4) : ''}{valor.toLocaleString('es')}{d.sufijo ? txt(d.sufijo, 6) : ''}
      </div>
      {d.etiqueta ? <div style={{position: 'absolute', top: 820, width: '100%', textAlign: 'center', fontFamily: F, fontSize: 56, fontWeight: 900, color: 'rgba(255,255,255,0.85)'}}>{txt(d.etiqueta, 30)}</div> : null}
      <svg width={1080} height={1920} style={{position: 'absolute', inset: 0}}>
        {Array.from({length: visibles}, (_, i) => (
          <Icono key={i} tipo={icono} x={150 + (i % 10) * 87} y={1000 + Math.floor(i / 10) * 100} t={f / fps} color={color} />
        ))}
      </svg>
    </AbsoluteFill>
  );
};

export const TIPOS_INSERTO = ['documento', 'pantalla', 'mapa', 'calendario', 'contador', 'reloj'];

/** La toma de inserto que corresponde (ocupa toda la pantalla). */
export const Inserto: React.FC<{toma: Toma; f: number; fps: number; paleta: Paleta}> = ({toma, f, fps, paleta}) => {
  const d = toma.inserto || {};
  if (toma.tipo === 'documento') return <Documento d={d} f={f} fps={fps} paleta={paleta} />;
  if (toma.tipo === 'pantalla') return <Pantalla d={d} f={f} fps={fps} paleta={paleta} />;
  if (toma.tipo === 'mapa') return <Mapa d={d} f={f} fps={fps} paleta={paleta} />;
  if (toma.tipo === 'calendario') return <Calendario d={d} f={f} fps={fps} paleta={paleta} />;
  if (toma.tipo === 'reloj') return <Reloj d={d} f={f} fps={fps} paleta={paleta} />;
  if (toma.tipo === 'contador') return <Contador d={d} f={f} fps={fps} paleta={paleta} />;
  return null;
};

/** Ficha con nombre, fecha o lugar (en la franja del medio, bajo los textos de arriba). */
export const Ficha: React.FC<{titulo: string; sub?: string; f: number; fps: number}> = ({titulo, sub, f, fps}) => {
  const e = entra(f, fps, 3, 170);
  return (
    <div style={{position: 'absolute', left: 90, top: 560, transform: `translateX(${(1 - e) * -700}px)`, background: 'rgba(20,20,24,0.92)', borderRadius: 16,
      borderLeft: '10px solid #E23B3B', padding: '18px 30px', fontFamily: F, boxShadow: '0 12px 30px rgba(0,0,0,0.35)', maxWidth: 760}}>
      <div style={{color: 'white', fontSize: 50, fontWeight: 900, lineHeight: 1.05}}>{titulo}</div>
      {sub ? <div style={{color: 'rgba(255,255,255,0.72)', fontSize: 32, fontWeight: 800, marginTop: 6}}>{sub}</div> : null}
    </div>
  );
};

/** Sello que cae de golpe (FALSO, TRAMPA, BLOQUEADO...). */
export const Sello: React.FC<{texto: string; f: number; fps: number}> = ({texto, f, fps}) => {
  const g = f - Math.round(0.25 * fps);
  if (g < 0) return null;
  const e = interpolate(g, [0, 5], [2.4, 1], {extrapolateRight: 'clamp', easing: Easing.in(Easing.cubic)});
  const tiembla = g > 4 && g < 10 ? Math.sin(g * 3) * 6 : 0;
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: 820, display: 'flex', justifyContent: 'center', transform: `translateX(${tiembla}px)`}}>
      <div style={{transform: `scale(${e}) rotate(-12deg)`, border: '14px solid #D7263D', color: '#D7263D', fontFamily: F, fontWeight: 900, fontSize: 130,
        padding: '6px 40px', borderRadius: 20, letterSpacing: 6, background: 'rgba(255,255,255,0.08)', opacity: Math.min(1, g / 2)}}>{texto}</div>
    </div>
  );
};

/** La luz de la toma: cambia la emoción del plano (cálida, fría, noche, peligro, dorada, misterio). */
export const Luz: React.FC<{luz?: string}> = ({luz}) => {
  const capas: Record<string, React.CSSProperties[]> = {
    calida: [{background: '#FF9F43', mixBlendMode: 'soft-light', opacity: 0.35}],
    fria: [{background: '#4A7BD0', mixBlendMode: 'soft-light', opacity: 0.4}],
    noche: [{background: '#14204A', mixBlendMode: 'multiply', opacity: 0.45}, {background: 'radial-gradient(ellipse at 50% 40%, transparent 30%, rgba(0,0,10,0.55) 100%)'}],
    peligro: [{background: '#C0392B', mixBlendMode: 'soft-light', opacity: 0.45}, {background: 'radial-gradient(ellipse at 50% 45%, transparent 35%, rgba(60,0,0,0.6) 100%)'}],
    dorada: [{background: '#FFC857', mixBlendMode: 'soft-light', opacity: 0.4}],
    misterio: [{background: 'radial-gradient(ellipse at 50% 42%, transparent 25%, rgba(0,0,0,0.7) 100%)'}],
  };
  const lista = capas[luz || ''] || [];
  return (
    <>
      {lista.map((st, i) => (
        <AbsoluteFill key={i} style={{pointerEvents: 'none', ...st}} />
      ))}
    </>
  );
};
