// Decorados de fondo para los ambientes (laboratorio, cocina, ciudad, espacio, micro...).
// Tres capas que dan profundidad: "lejos" (el lugar), "medio" (siluetas más cercanas) y
// "particulas" (vida lenta: polvo, estrellas, burbujas, células). Funciones puras de canvas.
// El fondo siempre más apagado que el protagonista: colores suaves y poco contraste.

export type TemaDecorado =
  | 'laboratorio' | 'cocina' | 'ciudad' | 'naturaleza' | 'espacio' | 'micro'
  | 'cuerpo' | 'oceano' | 'taller' | 'antiguo' | 'aula'
  | 'selva' | 'desierto' | 'montana' | 'habitacion_noche' | 'pueblo' | 'playa';

export const TEMAS_DECORADO: TemaDecorado[] = [
  'laboratorio', 'cocina', 'ciudad', 'naturaleza', 'espacio', 'micro', 'cuerpo', 'oceano', 'taller', 'antiguo', 'aula',
  'selva', 'desierto', 'montana', 'habitacion_noche', 'pueblo', 'playa',
];

type Tonos = {cielo: [string, string]; a: string; b: string; c: string; luz: string};

const TONOS: Record<TemaDecorado, Tonos> = {
  laboratorio: {cielo: ['#E4EEF3', '#B8CCD8'], a: '#9DB6C6', b: '#7E9BB0', c: '#CFE3EC', luz: '#FFFFFF'},
  cocina: {cielo: ['#FBEEDB', '#E9CFAE'], a: '#D9B48A', b: '#B98E63', c: '#F4E1C6', luz: '#FFF6E6'},
  ciudad: {cielo: ['#9CC6E8', '#E5EEF3'], a: '#A9B8C9', b: '#8296AD', c: '#D3DEE8', luz: '#FFF4D6'},
  naturaleza: {cielo: ['#92CBEB', '#DDF0F7'], a: '#8FB98A', b: '#6E9C6A', c: '#B9D8A8', luz: '#FFF3C4'},
  espacio: {cielo: ['#070A22', '#1B1243'], a: '#2A2160', b: '#3B2D7A', c: '#6C5BC0', luz: '#FFFFFF'},
  micro: {cielo: ['#0B2533', '#0F3D44'], a: '#1C5C66', b: '#2B7A80', c: '#58B7B0', luz: '#BFF5EA'},
  cuerpo: {cielo: ['#2E0B10', '#5C1A21'], a: '#7A2630', b: '#963440', c: '#C65A63', luz: '#FFC9C2'},
  oceano: {cielo: ['#1B78A8', '#062A45'], a: '#0F4F74', b: '#0B3E5D', c: '#3A9CC2', luz: '#D9F6FF'},
  taller: {cielo: ['#EAD9C0', '#BFA07A'], a: '#A88A66', b: '#8A6C4C', c: '#D8C1A0', luz: '#FFF1D8'},
  antiguo: {cielo: ['#F2C98E', '#C98C5A'], a: '#B98457', b: '#946440', c: '#E6BE8A', luz: '#FFE7B8'},
  aula: {cielo: ['#EEF0E4', '#CBD2BC'], a: '#B4BFA2', b: '#94A183', c: '#2F4A3A', luz: '#FFFFF2'},
  selva: {cielo: ['#2E4B33', '#1A2E22'], a: '#3F6B45', b: '#2C5235', c: '#5E8F57', luz: '#D8F0B0'},
  desierto: {cielo: ['#F6C27A', '#F3E1B8'], a: '#E0A25E', b: '#C9874A', c: '#EFC48A', luz: '#FFF1C8'},
  montana: {cielo: ['#8FB8DE', '#E3EEF5'], a: '#7C8DA6', b: '#5E6E86', c: '#B6C4D6', luz: '#FFFFFF'},
  habitacion_noche: {cielo: ['#22304F', '#3A3550'], a: '#5B4A44', b: '#3E322E', c: '#F2C879', luz: '#FFD58A'},
  pueblo: {cielo: ['#A8D3EE', '#EAF1EC'], a: '#C9A27A', b: '#A57E58', c: '#E7D6BD', luz: '#FFF4D6'},
  playa: {cielo: ['#7CC6EE', '#E9F6FB'], a: '#E9D3A0', b: '#D3B27A', c: '#2E9AC4', luz: '#FFF6D8'},
};

/** Generador de números pseudoaleatorios con semilla (el mismo dibujo en cada fotograma). */
const azar = (semilla: number) => {
  let s = semilla % 2147483647 || 1;
  return () => ((s = (s * 16807) % 2147483647) / 2147483647);
};

const redondo = (x: CanvasRenderingContext2D, a: number, b: number, w: number, h: number, r: number) => {
  x.beginPath();
  x.moveTo(a + r, b);
  x.arcTo(a + w, b, a + w, b + h, r);
  x.arcTo(a + w, b + h, a, b + h, r);
  x.arcTo(a, b + h, a, b, r);
  x.arcTo(a, b, a + w, b, r);
  x.closePath();
};

const pintar = (x: CanvasRenderingContext2D, color: string, contorno?: string, grosor = 0) => {
  x.fillStyle = color;
  x.fill();
  if (contorno && grosor > 0) {
    x.strokeStyle = contorno;
    x.lineWidth = grosor;
    x.lineJoin = 'round';
    x.stroke();
  }
};

const degradado = (x: CanvasRenderingContext2D, w: number, h: number, arriba: string, abajo: string) => {
  const g = x.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, arriba);
  g.addColorStop(1, abajo);
  x.fillStyle = g;
  x.fillRect(0, 0, w, h);
};

const halo = (x: CanvasRenderingContext2D, cx: number, cy: number, r: number, color: string, fuerza = 0.6) => {
  const g = x.createRadialGradient(cx, cy, 0, cx, cy, r);
  g.addColorStop(0, color);
  g.addColorStop(1, 'rgba(0,0,0,0)');
  x.globalAlpha = fuerza;
  x.fillStyle = g;
  x.fillRect(cx - r, cy - r, r * 2, r * 2);
  x.globalAlpha = 1;
};

// ---------- capa lejana: el lugar ----------
export const decoradoLejos = (x: CanvasRenderingContext2D, w: number, h: number, tema: TemaDecorado, contorno: string, conContorno: boolean) => {
  const t = TONOS[tema] ?? TONOS.laboratorio;
  const r = azar(tema.length * 977 + 13);
  const g = conContorno ? Math.max(2, w / 260) : 0;
  const tinta = contorno + '99';
  degradado(x, w, h, t.cielo[0], t.cielo[1]);
  switch (tema) {
    case 'laboratorio': {
      x.strokeStyle = 'rgba(255,255,255,0.35)';
      x.lineWidth = w / 400;
      for (let i = 1; i < 12; i++) {
        x.beginPath(); x.moveTo((i * w) / 12, 0); x.lineTo((i * w) / 12, h * 0.62); x.stroke();
      }
      for (let k = 0; k < 2; k++) {
        const y = h * (0.28 + k * 0.2);
        redondo(x, w * 0.04, y, w * 0.92, h * 0.025, 4); pintar(x, t.b, tinta, g);
        for (let i = 0; i < 9; i++) {
          const bx = w * (0.07 + i * 0.1 + r() * 0.02), bw = w * (0.03 + r() * 0.025), bh = h * (0.06 + r() * 0.07);
          const colores = [t.c, '#9FD8C9', '#F4C27A', '#C9B5E8', '#9CC8EE'];
          x.beginPath();
          if (i % 2) redondo(x, bx, y - bh, bw, bh, bw * 0.3);
          else { x.moveTo(bx + bw * 0.35, y - bh); x.lineTo(bx + bw * 0.65, y - bh); x.lineTo(bx + bw, y); x.lineTo(bx, y); x.closePath(); }
          pintar(x, colores[i % colores.length], tinta, g);
        }
      }
      halo(x, w * 0.82, h * 0.12, w * 0.35, t.luz, 0.5);
      break;
    }
    case 'cocina': {
      const yb = h * 0.42;
      x.strokeStyle = 'rgba(255,255,255,0.5)';
      x.lineWidth = w / 500;
      for (let i = 0; i < 20; i++) { x.beginPath(); x.moveTo((i * w) / 20, yb); x.lineTo((i * w) / 20, h * 0.66); x.stroke(); }
      for (let j = 0; j < 4; j++) { x.beginPath(); x.moveTo(0, yb + j * h * 0.06); x.lineTo(w, yb + j * h * 0.06); x.stroke(); }
      for (let i = 0; i < 4; i++) {
        redondo(x, w * (0.03 + i * 0.245), h * 0.06, w * 0.22, h * 0.26, 10); pintar(x, t.c, tinta, g);
        redondo(x, w * (0.03 + i * 0.245) + w * 0.09, h * 0.27, w * 0.04, h * 0.012, 4); pintar(x, t.b);
      }
      halo(x, w * 0.2, h * 0.35, w * 0.4, t.luz, 0.45);
      break;
    }
    case 'ciudad': {
      halo(x, w * 0.75, h * 0.2, w * 0.25, t.luz, 0.8);
      for (let capa = 0; capa < 2; capa++) {
        const color = capa ? t.b : t.c;
        let a = -w * 0.02;
        while (a < w) {
          const bw = w * (0.06 + r() * 0.08), bh = h * (capa ? 0.2 + r() * 0.3 : 0.3 + r() * 0.35);
          x.beginPath(); x.rect(a, h * 0.72 - bh, bw, bh + h); pintar(x, color, capa ? tinta : undefined, g);
          if (capa) {
            x.fillStyle = 'rgba(255,240,200,0.55)';
            for (let fy = h * 0.72 - bh + h * 0.02; fy < h * 0.7; fy += h * 0.035)
              for (let fx = a + bw * 0.15; fx < a + bw * 0.85; fx += bw * 0.25) if (r() > 0.35) x.fillRect(fx, fy, bw * 0.12, h * 0.015);
          }
          a += bw + w * 0.004;
        }
      }
      break;
    }
    case 'naturaleza': {
      halo(x, w * 0.25, h * 0.18, w * 0.22, t.luz, 0.9);
      x.beginPath(); x.arc(w * 0.25, h * 0.18, w * 0.05, 0, Math.PI * 2); pintar(x, '#FFE9A8');
      [[t.c, 0.5, 0.18], [t.a, 0.6, 0.14]].forEach(([color, base, alto], k) => {
        x.beginPath(); x.moveTo(0, h);
        for (let i = 0; i <= 8; i++) x.quadraticCurveTo(((i - 0.5) * w) / 8, h * ((base as number) - (alto as number) * (0.5 + r())), (i * w) / 8, h * (base as number));
        x.lineTo(w, h); x.closePath(); pintar(x, color as string, k ? tinta : undefined, g);
      });
      for (let i = 0; i < 7; i++) {
        const cx = w * (0.05 + i * 0.15 + r() * 0.04), cy = h * 0.6, rr = w * (0.04 + r() * 0.03);
        x.beginPath(); x.arc(cx, cy - rr, rr, 0, Math.PI * 2); pintar(x, t.b, tinta, g);
      }
      break;
    }
    case 'espacio': {
      halo(x, w * 0.3, h * 0.3, w * 0.5, '#6A3FB0', 0.35);
      halo(x, w * 0.75, h * 0.6, w * 0.45, '#2D6FB8', 0.3);
      for (let i = 0; i < 160; i++) {
        x.fillStyle = `rgba(255,255,255,${0.3 + r() * 0.6})`;
        x.beginPath(); x.arc(r() * w, r() * h, r() * w * 0.0022 + 0.5, 0, Math.PI * 2); x.fill();
      }
      x.beginPath(); x.arc(w * 0.8, h * 0.22, w * 0.09, 0, Math.PI * 2); pintar(x, '#E59A5C', tinta, g);
      x.save(); x.translate(w * 0.8, h * 0.22); x.rotate(-0.35); x.scale(1, 0.25);
      x.beginPath(); x.arc(0, 0, w * 0.15, 0, Math.PI * 2); x.strokeStyle = '#F4D6A8'; x.lineWidth = w * 0.012; x.stroke(); x.restore();
      break;
    }
    case 'micro':
    case 'cuerpo': {
      for (let i = 0; i < 14; i++) {
        const cx = r() * w, cy = r() * h, rr = w * (0.05 + r() * 0.09);
        x.globalAlpha = 0.35 + r() * 0.25;
        x.beginPath(); x.ellipse(cx, cy, rr, rr * (0.7 + r() * 0.3), r() * 3, 0, Math.PI * 2); pintar(x, i % 2 ? t.a : t.b);
        x.beginPath(); x.arc(cx, cy, rr * 0.3, 0, Math.PI * 2); pintar(x, t.c);
        x.globalAlpha = 1;
      }
      if (tema === 'cuerpo') {
        x.strokeStyle = t.c + '88'; x.lineWidth = w * 0.03; x.lineCap = 'round';
        for (let k = 0; k < 3; k++) {
          x.beginPath(); x.moveTo(-w * 0.1, h * (0.2 + k * 0.3));
          x.bezierCurveTo(w * 0.3, h * (0.05 + k * 0.3), w * 0.6, h * (0.45 + k * 0.25), w * 1.1, h * (0.25 + k * 0.3)); x.stroke();
        }
      }
      halo(x, w * 0.5, h * 0.45, w * 0.6, t.luz, 0.12);
      break;
    }
    case 'oceano': {
      x.globalAlpha = 0.18; x.fillStyle = t.luz;
      for (let i = 0; i < 6; i++) {
        const a = w * (0.1 + i * 0.16);
        x.beginPath(); x.moveTo(a, 0); x.lineTo(a + w * 0.05, 0); x.lineTo(a + w * 0.18, h); x.lineTo(a + w * 0.08, h); x.closePath(); x.fill();
      }
      x.globalAlpha = 1;
      x.beginPath(); x.moveTo(0, h);
      for (let i = 0; i <= 10; i++) x.quadraticCurveTo(((i - 0.5) * w) / 10, h * (0.8 - r() * 0.08), (i * w) / 10, h * 0.84);
      x.lineTo(w, h); x.closePath(); pintar(x, t.b, tinta, g);
      break;
    }
    case 'taller': {
      for (let i = 0; i < 10; i++) { x.beginPath(); x.rect((i * w) / 10, 0, w / 10, h); pintar(x, i % 2 ? t.c : t.cielo[0], tinta, g * 0.5); }
      redondo(x, w * 0.1, h * 0.1, w * 0.8, h * 0.4, 8); pintar(x, t.a, tinta, g);
      x.fillStyle = t.b;
      for (let fy = h * 0.14; fy < h * 0.48; fy += h * 0.04) for (let fx = w * 0.13; fx < w * 0.88; fx += w * 0.04) { x.beginPath(); x.arc(fx, fy, w * 0.004, 0, Math.PI * 2); x.fill(); }
      for (let i = 0; i < 6; i++) {
        const tx = w * (0.18 + i * 0.12);
        redondo(x, tx, h * 0.16, w * 0.025, h * (0.12 + r() * 0.12), 6); pintar(x, ['#C9563F', '#4E7FB0', '#E2B84A'][i % 3], tinta, g);
      }
      break;
    }
    case 'antiguo': {
      halo(x, w * 0.5, h * 0.55, w * 0.5, t.luz, 0.6);
      for (let i = 0; i < 6; i++) {
        const cx = w * (0.08 + i * 0.17);
        x.beginPath(); x.rect(cx, h * 0.22, w * 0.06, h * 0.5); pintar(x, t.c, tinta, g);
        x.beginPath(); x.rect(cx - w * 0.012, h * 0.2, w * 0.084, h * 0.03); pintar(x, t.a, tinta, g);
      }
      x.beginPath(); x.moveTo(w * 0.02, h * 0.2); x.lineTo(w * 0.5, h * 0.06); x.lineTo(w * 0.98, h * 0.2); x.closePath(); pintar(x, t.a, tinta, g);
      break;
    }
    case 'aula': {
      redondo(x, w * 0.1, h * 0.12, w * 0.8, h * 0.4, 10); pintar(x, t.c, '#6B4A2E', w * 0.012);
      x.strokeStyle = 'rgba(255,255,255,0.55)'; x.lineWidth = w * 0.004; x.lineCap = 'round';
      for (let k = 0; k < 4; k++) {
        const y = h * (0.2 + k * 0.08);
        x.beginPath(); x.moveTo(w * 0.16, y);
        for (let i = 0; i < 12; i++) x.quadraticCurveTo(w * (0.18 + i * 0.05), y - h * 0.015 * (i % 2 ? 1 : -1), w * (0.2 + i * 0.05), y);
        x.stroke();
      }
      break;
    }
    case 'selva': {
      for (let capa = 0; capa < 3; capa++) {
        for (let i = 0; i < 14; i++) {
          const a = r() * w, ancho = w * (0.015 + r() * 0.02);
          x.beginPath(); x.rect(a, 0, ancho, h); pintar(x, [t.c, t.a, t.b][capa], capa === 2 ? tinta : undefined, g * 0.6);
        }
        for (let i = 0; i < 10; i++) {
          const cx = r() * w, cy = h * (0.2 + r() * 0.5);
          x.save(); x.translate(cx, cy); x.rotate(r() * 6.28);
          x.beginPath(); x.ellipse(0, 0, w * 0.09, w * 0.025, 0, 0, Math.PI * 2); pintar(x, [t.c, t.a, t.b][capa]); x.restore();
        }
      }
      halo(x, w * 0.5, h * 0.25, w * 0.5, t.luz, 0.25);
      break;
    }
    case 'desierto': {
      halo(x, w * 0.7, h * 0.25, w * 0.3, t.luz, 0.9);
      x.beginPath(); x.arc(w * 0.7, h * 0.25, w * 0.07, 0, Math.PI * 2); pintar(x, '#FFF0C2');
      [[t.c, 0.62], [t.a, 0.72], [t.b, 0.82]].forEach(([color, base], k) => {
        x.beginPath(); x.moveTo(0, h);
        for (let i = 0; i <= 4; i++) x.quadraticCurveTo(((i - 0.5) * w) / 4, h * ((base as number) - 0.08 - r() * 0.06), (i * w) / 4, h * (base as number));
        x.lineTo(w, h); x.closePath(); pintar(x, color as string, k === 2 ? tinta : undefined, g);
      });
      break;
    }
    case 'montana': {
      [[t.c, 0.55, 0.32], [t.a, 0.68, 0.3], [t.b, 0.8, 0.22]].forEach(([color, base, alto], k) => {
        x.beginPath(); x.moveTo(0, h);
        let a = 0;
        while (a < w) {
          const ancho = w * (0.18 + r() * 0.18), pico = h * ((base as number) - (alto as number) * (0.6 + r() * 0.4));
          x.lineTo(a + ancho / 2, pico); x.lineTo(a + ancho, h * (base as number)); a += ancho;
          if (k === 0) { x.save(); x.restore(); }
        }
        x.lineTo(w, h); x.closePath(); pintar(x, color as string, k ? tinta : undefined, g);
      });
      break;
    }
    case 'habitacion_noche': {
      // ventana con la ciudad de noche y una lámpara cálida
      redondo(x, w * 0.12, h * 0.08, w * 0.5, h * 0.52, 8); pintar(x, '#101A33', tinta, g * 1.5);
      for (let i = 0; i < 9; i++) {
        const bx = w * (0.13 + i * 0.055), bh = h * (0.12 + r() * 0.25);
        x.beginPath(); x.rect(bx, h * 0.6 - bh, w * 0.05, bh); pintar(x, '#24345C');
        x.fillStyle = 'rgba(255,214,140,0.7)';
        for (let fy = h * 0.6 - bh + 6; fy < h * 0.58; fy += h * 0.03) if (r() > 0.45) x.fillRect(bx + w * 0.01, fy, w * 0.012, h * 0.012);
      }
      x.strokeStyle = tinta; x.lineWidth = g * 1.2 || 3;
      x.beginPath(); x.moveTo(w * 0.37, h * 0.08); x.lineTo(w * 0.37, h * 0.6); x.moveTo(w * 0.12, h * 0.34); x.lineTo(w * 0.62, h * 0.34); x.stroke();
      redondo(x, w * 0.74, h * 0.18, w * 0.16, h * 0.22, 8); pintar(x, '#6E5A86', tinta, g);
      halo(x, w * 0.86, h * 0.46, w * 0.35, t.luz, 0.55);
      x.beginPath(); x.moveTo(w * 0.8, h * 0.38); x.lineTo(w * 0.92, h * 0.38); x.lineTo(w * 0.89, h * 0.3); x.lineTo(w * 0.83, h * 0.3); x.closePath(); pintar(x, t.c, tinta, g);
      break;
    }
    case 'pueblo': {
      halo(x, w * 0.2, h * 0.15, w * 0.25, t.luz, 0.8);
      for (let i = 0; i < 7; i++) {
        const bx = w * (i * 0.15 - 0.03), bw = w * 0.13, bh = h * (0.18 + r() * 0.12), base = h * 0.66;
        x.beginPath(); x.rect(bx, base - bh, bw, bh + h); pintar(x, ['#E7D6BD', '#D9B48A', '#C9A27A', '#EAD9C0'][i % 4], tinta, g);
        x.beginPath(); x.moveTo(bx - w * 0.01, base - bh); x.lineTo(bx + bw / 2, base - bh - h * 0.08); x.lineTo(bx + bw + w * 0.01, base - bh); x.closePath(); pintar(x, '#A8503A', tinta, g);
        x.beginPath(); x.rect(bx + bw * 0.35, base - bh * 0.45, bw * 0.3, bh * 0.45); pintar(x, '#6B4A2E', tinta, g * 0.6);
      }
      x.strokeStyle = tinta; x.lineWidth = g * 0.8 || 2;
      for (let i = 0; i < 4; i++) { const px = w * (0.1 + i * 0.27); x.beginPath(); x.moveTo(px, h * 0.25); x.lineTo(px, h * 0.68); x.stroke(); }
      break;
    }
    case 'playa': {
      halo(x, w * 0.75, h * 0.2, w * 0.25, t.luz, 0.9);
      x.beginPath(); x.rect(0, h * 0.5, w, h * 0.2); pintar(x, t.c);
      x.strokeStyle = 'rgba(255,255,255,0.5)'; x.lineWidth = w * 0.004;
      for (let i = 0; i < 6; i++) { x.beginPath(); x.moveTo(r() * w, h * (0.52 + r() * 0.15)); x.lineTo(r() * w, h * (0.52 + r() * 0.15)); x.stroke(); }
      x.beginPath(); x.moveTo(0, h * 0.7); x.quadraticCurveTo(w * 0.5, h * 0.64, w, h * 0.7); x.lineTo(w, h); x.lineTo(0, h); x.closePath(); pintar(x, t.a, tinta, g);
      break;
    }
  }
  // viñeta suave para que el centro respire
  const v = x.createRadialGradient(w / 2, h * 0.45, w * 0.2, w / 2, h * 0.45, w * 0.75);
  v.addColorStop(0, 'rgba(0,0,0,0)');
  v.addColorStop(1, 'rgba(0,0,0,0.22)');
  x.fillStyle = v;
  x.fillRect(0, 0, w, h);
};

// ---------- capa media: siluetas más cercanas (enmarcan por abajo y los lados) ----------
export const decoradoMedio = (x: CanvasRenderingContext2D, w: number, h: number, tema: TemaDecorado, contorno: string, conContorno: boolean) => {
  const t = TONOS[tema] ?? TONOS.laboratorio;
  const r = azar(tema.length * 331 + 7);
  const g = conContorno ? Math.max(2, w / 220) : 0;
  const color = t.b;
  x.clearRect(0, 0, w, h);
  switch (tema) {
    case 'laboratorio': case 'cocina': case 'taller': case 'aula': {
      redondo(x, -w * 0.02, h * 0.62, w * 1.04, h * 0.06, 6); pintar(x, t.a, contorno, g);
      x.beginPath(); x.rect(0, h * 0.68, w, h * 0.32); pintar(x, color, contorno, g);
      for (let i = 0; i < 5; i++) { redondo(x, w * (0.05 + i * 0.2), h * 0.74, w * 0.16, h * 0.2, 8); pintar(x, t.a, contorno, g * 0.7); }
      break;
    }
    case 'ciudad': {
      // seto, farolas y acera
      x.beginPath(); x.rect(0, h * 0.82, w, h * 0.18); pintar(x, t.a, contorno, g);
      for (let i = 0; i < 11; i++) { x.beginPath(); x.arc(w * (i / 10), h * 0.8, w * 0.06, Math.PI, 0); pintar(x, '#6F9A6A', contorno, g); }
      [0.08, 0.92].forEach((u) => {
        x.beginPath(); x.rect(w * u - w * 0.008, h * 0.25, w * 0.016, h * 0.6); pintar(x, color, contorno, g);
        x.beginPath(); x.arc(w * u, h * 0.24, w * 0.03, 0, Math.PI * 2); pintar(x, '#FFE7A8', contorno, g);
      });
      break;
    }
    case 'oceano': {
      for (let i = 0; i < 7; i++) {
        const cx = w * (i / 6 + (r() - 0.5) * 0.06), rr = w * (0.05 + r() * 0.05);
        x.beginPath(); x.ellipse(cx, h * 0.98, rr * 1.6, rr, 0, Math.PI, 0); pintar(x, t.a, contorno, g);
        const ramas = 2 + Math.floor(r() * 3);
        for (let k = 0; k < ramas; k++) {
          const bx = cx + (k - ramas / 2) * rr * 0.5, alto = h * (0.12 + r() * 0.2);
          x.beginPath(); x.moveTo(bx, h * 0.95);
          x.quadraticCurveTo(bx + rr * (r() - 0.5), h * 0.95 - alto * 0.6, bx + rr * 0.3 * (r() - 0.5), h * 0.95 - alto);
          x.strokeStyle = ['#E07A6A', '#F2B36B', '#B07AC9'][(i + k) % 3]; x.lineWidth = w * 0.012; x.lineCap = 'round'; x.stroke();
        }
      }
      break;
    }
    case 'habitacion_noche': {
      redondo(x, -w * 0.02, h * 0.62, w * 1.04, h * 0.06, 6); pintar(x, t.a, contorno, g);
      x.beginPath(); x.rect(0, h * 0.68, w, h * 0.32); pintar(x, color, contorno, g);
      redondo(x, w * 0.06, h * 0.3, w * 0.24, h * 0.34, 18); pintar(x, '#6B5A7A', contorno, g);
      break;
    }
    case 'selva': {
      for (let i = 0; i < 12; i++) {
        const cx = w * (i / 11), cy = h * (0.75 + r() * 0.2);
        for (let k = 0; k < 5; k++) {
          x.save(); x.translate(cx, cy); x.rotate(-Math.PI / 2 + (k - 2) * 0.45);
          x.beginPath(); x.ellipse(w * 0.07, 0, w * 0.08, w * 0.022, 0, 0, Math.PI * 2); pintar(x, k % 2 ? '#3E7A3F' : '#2F6233', contorno, g * 0.6); x.restore();
        }
      }
      break;
    }
    case 'desierto': case 'playa': case 'montana': {
      for (let i = 0; i < 4; i++) {
        const cx = w * (0.05 + i * 0.3 + r() * 0.08), rr = w * (0.05 + r() * 0.05);
        x.beginPath(); x.ellipse(cx, h * 0.95, rr * 1.4, rr, 0, Math.PI, 0); pintar(x, t.b, contorno, g);
      }
      if (tema === 'playa') {
        x.beginPath(); x.moveTo(w * 0.9, h); x.quadraticCurveTo(w * 0.86, h * 0.5, w * 0.8, h * 0.2); x.lineWidth = w * 0.025; x.strokeStyle = '#8A5A33'; x.stroke();
        for (let k = 0; k < 5; k++) { x.save(); x.translate(w * 0.8, h * 0.2); x.rotate(k * 1.25); x.beginPath(); x.ellipse(w * 0.08, 0, w * 0.09, w * 0.02, 0, 0, Math.PI * 2); pintar(x, '#3E8A45', contorno, g * 0.6); x.restore(); }
      }
      if (tema === 'desierto') {
        x.beginPath(); x.roundRect(w * 0.82, h * 0.35, w * 0.05, h * 0.6, w * 0.025); pintar(x, '#5E8F4C', contorno, g);
        x.beginPath(); x.roundRect(w * 0.77, h * 0.5, w * 0.04, h * 0.16, w * 0.02); pintar(x, '#5E8F4C', contorno, g);
      }
      break;
    }
    case 'pueblo': {
      x.beginPath(); x.rect(0, h * 0.8, w, h * 0.2); pintar(x, t.a, contorno, g);
      for (let i = 0; i < 3; i++) { x.beginPath(); x.arc(w * (0.1 + i * 0.4), h * 0.78, w * 0.07, Math.PI, 0); pintar(x, '#6F9A6A', contorno, g); }
      break;
    }
    case 'naturaleza': {
      for (let i = 0; i < 9; i++) {
        const a = w * (i / 8), alto = h * (0.25 + r() * 0.3);
        x.beginPath(); x.moveTo(a - w * 0.05, h);
        x.quadraticCurveTo(a - w * 0.06, h - alto, a, h - alto * 1.05);
        x.quadraticCurveTo(a + w * 0.06, h - alto, a + w * 0.05, h); x.closePath();
        pintar(x, i % 2 ? color : t.a, contorno, g);
      }
      break;
    }
    case 'antiguo': {
      x.beginPath(); x.rect(0, h * 0.7, w, h * 0.3); pintar(x, color, contorno, g);
      for (let i = 0; i < 3; i++) { x.beginPath(); x.rect(w * (0.1 + i * 0.35), h * 0.5, w * 0.08, h * 0.2); pintar(x, t.a, contorno, g); }
      break;
    }
    default: {
      // sin suelo (espacio, micro, cuerpo): formas que flotan en las esquinas
      for (let i = 0; i < 4; i++) {
        const cx = i % 2 ? w * 0.92 : w * 0.08, cy = i < 2 ? h * 0.15 : h * 0.85, rr = w * (0.08 + r() * 0.05);
        x.beginPath(); x.ellipse(cx, cy, rr, rr * 0.8, r() * 3, 0, Math.PI * 2); pintar(x, color, contorno, g);
      }
    }
  }
  // más oscuro que el centro: enmarca sin robar atención
  x.globalCompositeOperation = 'source-atop';
  x.fillStyle = 'rgba(0,0,0,0.18)';
  x.fillRect(0, 0, w, h);
  x.globalCompositeOperation = 'source-over';
};

// ---------- partículas: vida lenta del fondo ----------
export const decoradoParticulas = (x: CanvasRenderingContext2D, w: number, h: number, tema: TemaDecorado, seg: number) => {
  const r = azar(97 + tema.length);
  x.clearRect(0, 0, w, h);
  const n = tema === 'espacio' ? 40 : 26;
  for (let i = 0; i < n; i++) {
    const bx = r() * w, by = r() * h, fase = r() * 6.28, vel = 0.3 + r() * 0.7, tam = (0.002 + r() * 0.004) * w;
    if (tema === 'espacio') {
      x.fillStyle = `rgba(255,255,255,${0.25 + 0.6 * Math.abs(Math.sin(seg * vel * 1.5 + fase))})`;
      x.beginPath(); x.arc(bx, by, tam * 0.8, 0, Math.PI * 2); x.fill();
    } else if (tema === 'oceano' || tema === 'micro') {
      const y = (((by - seg * vel * h * 0.06) % h) + h) % h;
      x.strokeStyle = 'rgba(220,250,255,0.55)'; x.lineWidth = tam * 0.35;
      x.beginPath(); x.arc(bx + Math.sin(seg * 1.3 + fase) * w * 0.01, y, tam * 1.6, 0, Math.PI * 2); x.stroke();
    } else if (tema === 'cuerpo') {
      const xx = (((bx + seg * vel * w * 0.05) % w) + w) % w;
      x.fillStyle = 'rgba(214,74,84,0.75)';
      x.beginPath(); x.ellipse(xx, by + Math.sin(seg + fase) * h * 0.01, tam * 2.6, tam * 1.6, fase, 0, Math.PI * 2); x.fill();
    } else if (tema === 'naturaleza') {
      const y = (by + seg * vel * h * 0.03) % h;
      x.fillStyle = 'rgba(126,170,86,0.6)';
      x.save(); x.translate(bx + Math.sin(seg + fase) * w * 0.02, y); x.rotate(seg * vel + fase);
      x.beginPath(); x.ellipse(0, 0, tam * 2.2, tam, 0, 0, Math.PI * 2); x.fill(); x.restore();
    } else {
      // polvo en la luz
      x.fillStyle = `rgba(255,250,235,${0.2 + 0.35 * Math.abs(Math.sin(seg * 0.8 + fase))})`;
      x.beginPath(); x.arc(bx + Math.sin(seg * 0.4 * vel + fase) * w * 0.02, by + Math.cos(seg * 0.3 + fase) * h * 0.015, tam, 0, Math.PI * 2); x.fill();
    }
  }
};

export const SIN_SUELO: TemaDecorado[] = ['espacio', 'micro', 'cuerpo', 'oceano'];
