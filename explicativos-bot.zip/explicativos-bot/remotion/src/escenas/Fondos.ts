// Fondos de ESTE video. El bot reemplaza este archivo en cada video con fondos dibujados para su
// tema (los dibuja Claude). Vacío = se usan los fondos de respaldo de decorados2d.ts.
export const FONDOS: {[id: string]: any} = {};
